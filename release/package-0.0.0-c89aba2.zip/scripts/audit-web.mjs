// Static audit of the web layer. No network, no database: everything here is
// decided by reading the files in this repository.
//
// Each check exists because the same mistake was made at least once, and a
// human would not catch it on the next edit. A dead reference or a value written
// into two places does not fail a build, does not throw, and does not show up in
// the browser; it just quietly stops working weeks later, on the one page nobody
// opened. Turning it into a FAIL is the cheapest fix available.
//
//   npm run audit
//   node scripts/audit-web.mjs --root <thu-muc>   (dùng cho thư mục đã build)
//
// Exit code is non-zero when anything is wrong, so it can gate a deploy.
import { readFile, readdir } from "node:fs/promises";
import { readFileSync, existsSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { corsDiff, isFixtureHost } from "./lib/cors.mjs";
import { walkProjectFiles } from "./lib/files.mjs";
import { stripComments } from "./lib/source.mjs";

import { env } from "../src/config.js";
import { LOCALE_CODES } from "../src/i18n-registry.mjs";

const rootFlag = process.argv.indexOf("--root");
const root = rootFlag > -1
  ? path.resolve(process.argv[rootFlag + 1])
   : path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
// dotenv.config({ path: path.join(root, ".env") });

const findings = [];
const fail = (check, file, detail) => findings.push({ check, file, detail });

// Files a directory scan listed and this process then failed to open.
//
// This is not hypothetical: a scan that lists a file and crashes on it reports
// exit 1, which is the same status a real finding produces. A crash therefore
// lets a page that is supposed to FAIL pass for the wrong reason, and a page that
// is supposed to pass go red for the wrong one. Both happened here, intermittently,
// against a fixture tree being rewritten underneath the audit on a Windows host.
//
// So a vanished file is recorded and skipped, and reported at the end as its own
// finding. The gate then says what it knows — "I could not read these" — instead
// of throwing a stack trace and being read as a verdict.
const unreadable = [];
const read = async (relative) => {
  try {
    return await readFile(path.join(root, relative), "utf8");
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
    unreadable.push(relative);
    return "";
  }
};

const publicDir = path.join(root, "public");
const htmlFiles = (await readdir(publicDir)).filter((name) => name.endsWith(".html")).sort();
const scriptFiles = (await readdir(publicDir)).filter((name) => name.endsWith(".js")).sort();
const indexHtml = await read(path.join("public", "index.html"));
const storefrontSource = await read(path.join("public", "app.js"));
const serverSource = await read(path.join("src", "app.js"));
const pagesSource = await read(path.join("src", "pages.js"));
const i18nSource = await read(path.join("public", "i18n.js"));
const categoriesSource = await read(path.join("src", "lib", "categories.mjs"));

// ---------------------------------------------------------------------------
// 1. A link or an asset pointing at a file that is not there.
//    /logo.svg was named as the Organization logo on every product page while
//    only favicon.svg existed. Nothing complained: the page rendered, Google
//    just recorded a 404 for the brand's logo.
// ---------------------------------------------------------------------------
// Paths the server answers itself, with no file behind them.
//
// This list has to grow with the server, and that is the point of writing it down
// rather than loosening the check: a route added without a line here is a failing
// build, not a silently accepted 404. /llms.txt, /feed.json and the English
// product path were all missing here when they were first written, and each one
// was caught by the same check that has been catching bad links all along.
const dynamicRoute = /^(?:\/$|\/en(?:\/product\/[^/]+)?$|\/product\/[^/]+$|\/order\/[^/]+$|\/og\/[^/]+$|\/robots\.txt$|\/sitemap\.xml$|\/llms\.txt$|\/feed\.json$|\/blog\.json$|\/api\/|\/admin(?:\.js|\.html)?$|\/paypal-return(?:\.html)?$|\/lookup(?:\.html)?$|\/google[0-9a-z]+\.html$|\/ms[0-9a-z]+\.txt$|\/[0-9a-z-]{8,128}\.txt$|\/blog(?:\/[^/]+)?$|\/en\/blog(?:\/[^/]+)?$)/;
// Pages that are entry points rather than link targets: the buyer reaches them
// from an email or a PayPal redirect, and robots.txt deliberately keeps crawlers
// away from all three.
const entryPages = new Set(["order.html", "paypal-return.html", "admin.html", "lookup.html", "404.html"]);

const isRealTarget = (href) => {
  const clean = href.split("#")[0].split("?")[0];
  if (!clean) return true;
  const parts = clean.replace(/^\//, "").split("/");
  const candidates = clean.endsWith("/")
    ? [path.join(clean, "index.html")]
    : [clean, `${clean}.html`, path.join(...parts, "index.html")];
  return candidates.some((item) => existsSync(path.join(publicDir, item)));
};

// The two link lists the server renders every page's navigation from.
//
// They used to be markup in ten files, which is why this is worth naming: a set of
// links that no file on disk holds cannot be read by any check that walks files.
const chromeLinkLists = (source) =>
  [...source.matchAll(/(?:HEADER_LINKS|FOOTER_LINKS) = \[([\s\S]*?)\];/g)].map((match) => match[1]);

for (const name of htmlFiles) {
  const source = await read(path.join("public", name));
  for (const match of source.matchAll(/(?:href|src)\s*=\s*"([^"]+)"/g)) {
    const href = match[1];
    if (!href.startsWith("/") || href.startsWith("//")) continue;
    if (isRealTarget(href) || dynamicRoute.test(href)) continue;
    fail("link gãy", `public/${name}`, `"${href}" không có file tương ứng trong public/`);
  }
}
// Every HTML page must load the stylesheet directly (absolute /styles.min.css,
// the minified build of styles.css). A stylesheet that lives only inside
// <link rel="preload" ... onload="..."> depends on an inline event handler,
// which CSP blocks (script-src has no 'unsafe-inline'), so the page ends up
// with no CSS at all. This pattern is not accepted as a substitute for a real
// stylesheet, whether preload+onload or noscript-only.
for (const name of htmlFiles) {
  const source = await read(path.join("public", name));
  if (!/<link[^>]*rel=["']stylesheet["'][^>]*href=["']\/styles\.min\.css["']/.test(source)) {
    fail("missing stylesheet", `public/${name}`, "must contain <link rel=\"stylesheet\" href=\"/styles.min.css\"> directly; not only in preload+onload (blocked by CSP) or noscript-only.");
  }
}
// The HTML the server renders is held to the same rule as a file on disk.
for (const match of pagesSource.matchAll(/(?:absolute|LOGO_PATH\s*=)\(\s*"(\/[^"]*)"/g)) {
  const href = match[1];
  if (href.includes(":") || isRealTarget(href) || dynamicRoute.test(href)) continue;
  fail("link gãy", "src/pages.js", `absolute("${href}") trỏ tới file không có trong public/`);
}
// The navigation moved out of the templates and into one list in src/pages.js, so
// the links the shop offers are no longer in any file this loop above reads. Without
// this they would be exactly the blind spot section 5c documents for the header: a
// link to a page that was renamed is invisible to every check above.
for (const block of chromeLinkLists(pagesSource)) {
  for (const match of block.matchAll(/href:\s*"([^"]+)"/g)) {
    const href = match[1];
    if (href.includes(":") || isRealTarget(href) || dynamicRoute.test(href)) continue;
    fail("link gãy", "src/pages.js", `link "${href}" trong thanh điều hướng trỏ tới trang không có trong public/`);
  }
}

// ---------------------------------------------------------------------------
// 2. The same Express route registered twice.
//    Express answers with the first registration, so a second, better route is
//    dead code that reads as if it works.
// ---------------------------------------------------------------------------
const routeTally = new Map();
for (const match of serverSource.matchAll(/app\.(get|post|patch|put|delete)\(\s*"([^"]+)"/g)) {
  const route = `${match[1].toUpperCase()} ${match[2]}`;
  routeTally.set(route, (routeTally.get(route) || 0) + 1);
}
for (const [route, count] of routeTally) {
  if (count > 1) fail("route trùng", "src/app.js", `${route} đăng ký ${count} lần, chỉ route đầu chạy`);
}

// ---------------------------------------------------------------------------
// 3. A translation key nobody reads, or a language missing one.
//    i18n.js holds every customer-facing string. A key nothing renders is copy
//    that was renamed once and left behind; the two languages drift apart
//    silently precisely because both files still agree with each other.
// ---------------------------------------------------------------------------
// Reads the object literal that starts at a marker, by counting braces and
// ignoring anything inside a string. The obvious version of this — from
// "vi: {" to the next "};" — runs straight past the end of the vi block, because
// a dictionary is written `{ vi: {…}, en: {…} };` and the first thing that looks
// like its end belongs to the whole DICT two hundred keys later. Every key then
// appeared to be declared twice, and the check reported the entire file.
//
// The same rule applies at the end of the English table. Slicing from `en: {` to
// the end of the file was correct only while the dictionary was the last thing in
// i18n.js; a table declared after it is then read as English keys, and every key
// in it is reported as a key the Vietnamese half is missing.
const objectLiteralAt = (source, marker) => {
  const markerAt = source.indexOf(marker);
  if (markerAt < 0) return "";
  const open = source.indexOf("{", markerAt);
  let depth = 0;
  let quote = "";
  for (let i = open; i < source.length; i += 1) {
    const char = source[i];
    // Comments have to be skipped, and this is not a refinement. The loop tracks
    // whether it is inside a string so that a brace inside one does not count,
    // but a `//` comment is not a string — so a single double quote in a comment
    // opened a "string" that ran until the next quote hundreds of lines later,
    // swallowing the real braces and desynchronising the depth count. The
    // consequence is not a missed duplicate key: the parser reads past the end
    // of the block it was asked for, and then reports every key in the file as
    // declared twice. 209 findings, one of them an apostrophe in a Vietnamese
    // comment, and the gate that exists to prevent confusion became the thing
    // producing it.
    if (!quote && char === "/" && source[i + 1] === "/") {
      while (i < source.length && source[i] !== "\n") i += 1;
      continue;
    }
    if (!quote && char === "/" && source[i + 1] === "*") {
      i += 2;
      while (i < source.length && !(source[i] === "*" && source[i + 1] === "/")) i += 1;
      i += 1;
      continue;
    }
    if (quote) {
      if (char === "\\") { i += 1; continue; }
      if (char === quote) quote = "";
      continue;
    }
    if (char === "'" || char === '"' || char === "`") { quote = char; continue; }
    if (char === "{") depth += 1;
    else if (char === "}" && (depth -= 1) === 0) return source.slice(open, i + 1);
  }
  return "";
};

const keysOf = (section) => new Set([...section.matchAll(/'([\w.]+)':/g)].map((m) => m[1]));
const viTable = objectLiteralAt(i18nSource, "vi: {");
const enTable = objectLiteralAt(i18nSource, "en: {");
if (!viTable || !enTable) {
  fail("thiếu bản dịch", "public/i18n.js", "không đọc được hai bảng ngôn ngữ — có lẽ tên vi: { hoặc en: { đã đổi");
}
const viKeys = keysOf(viTable);
const enKeys = keysOf(enTable);
for (const key of viKeys) if (!enKeys.has(key)) fail("thiếu bản dịch", "public/i18n.js", `"${key}" có tiếng Việt, thiếu tiếng Anh`);
for (const key of enKeys) if (!viKeys.has(key)) fail("thiếu bản dịch", "public/i18n.js", `"${key}" có tiếng Anh, thiếu tiếng Việt`);

// i18n.js is excluded from the page scripts below: its own source is the
// dictionary, so every key appears in it as a literal and the check would pass
// itself. What the file does with those keys is still real usage though — the
// status map and the two labels for the switch button both live there — so the
// dictionary tables are stripped and the rest of the file is scanned.
const pageScriptSources = await Promise.all(scriptFiles.filter((name) => name !== "i18n.js").map((name) => read(path.join("public", name))));
// Everything after the dictionary closes is real code that reads those keys: the
// status map, the switch button labels, the download format. A key named only in
// the dictionary is dead copy; a key named in the code beside it is not.
const dictionaryCloses = i18nSource.indexOf("};", i18nSource.indexOf("en: {"));
const i18nCode = i18nSource.slice(dictionaryCloses > 0 ? dictionaryCloses : 0);
const htmlSources = await Promise.all(htmlFiles.map((name) => read(path.join("public", name))));
const allHtml = htmlSources.join("\n");
const usedKeys = new Set([
  // data-i18n holds the key itself; data-i18n-attr holds "attribute:key" pairs.
  // data-i18n-html is for elements that need innerHTML (contain <strong>, <a>, etc.)
  // Every page is scanned, not just the homepage: the recovery and PayPal pages
  // carry their own keys, and reading only index.html reported them all as dead.
  ...[...allHtml.matchAll(/\bdata-i18n="([^"]+)"/g)].map((m) => m[1]),
  ...[...allHtml.matchAll(/\bdata-i18n-html="([^"]+)"/g)].map((m) => m[1]),
  ...[...allHtml.matchAll(/\bdata-i18n-attr="([^"]+)"/g)].flatMap((m) => m[1].split(",").map((pair) => pair.split(":")[1]?.trim()).filter(Boolean)),
  ...pageScriptSources.flatMap((source) => [...source.matchAll(/'([a-z][\w]*(?:\.[\w]+)+)'/g)].map((m) => m[1])),
  // What i18n.js itself reads: the status map, the switch button labels, the
  // download format. A key named only in the dictionary is dead; a key named in
  // the code next to it is not.
  ...[...i18nCode.matchAll(/'([\w.]+)'/g)].map((m) => m[1]),
]);

// ---------------------------------------------------------------------------
// 3b. A key the server hands to the browser by name.
//
//     "Used" is not only "named in a page script". src/payments.js sends the
//     checkout form a labelKey and a hintKey, and the form resolves them against
//     the dictionary at render time — eleven working keys, not one character of
//     which appears in public/. Reading only the pages reported every one of them
//     as dead, which is how a correct change gets "fixed" back into a hardcode.
//
//     So the modules that produce content for the browser are read too. These
//     answer with keys and nothing else: the other modules either answer with
//     errors, which the caller decides how to present, or render the page itself,
//     in a locale of their own.
//
//     src/app.js joins them, because that changed. It used to answer with a
//     Vietnamese sentence and `error`, which is not translatable, so it was
//     excluded — correctly, at the time. It now answers through src/refuse.js,
//     carrying `code` beside the sentence, and 46 of these keys come from nowhere
//     else in the repository. Listed here or nowhere, this list is what tells the
//     dictionary which of its own entries are live, so a key added to app.js and
//     forgotten here reads as dead copy and gets deleted.
//
//     src/refuse.js is deliberately not in it. That file documents the shape with
//     a worked example — `refuse("api.err.rateLimited", …)` — and a name that
//     appears only in prose is not a key anybody sends. Including it reported
//     thirty-eight phantom usages of a string that does not exist.
//
//     src/pages.js is in it because it now names the navigation: the header and the
//     footer are rendered from one list of links, and each of those links is
//     `data-i18n="nav.…"` in the markup it writes. Excluded, every key the chrome
//     uses read as dead copy — which is the same failure the comment above this
//     list describes, in the opposite direction.
const keyProducers = [];
for (const name of ["payments.js", "reviews.js", "app.js", "pages.js"]) {
  const file = path.join("src", name);
  if (existsSync(file)) keyProducers.push([`src/${name}`, await read(file)]);
}
for (const [, source] of keyProducers) {
  // Both quote styles: src/payments.js is written in double quotes like the rest
  // of src/, and a single-quoted pattern reported every payment key as dead.
  for (const match of source.matchAll(/'([a-z][\w]*(?:\.[\w]+)+)'|"([a-z][\w]*(?:\.[\w]+)+)"/g)) {
    usedKeys.add(match[1] || match[2]);
  }
}

const orphans = [...viKeys].filter((key) => !usedKeys.has(key)).sort();
if (orphans.length) fail("khoá i18n mồ côi", "public/i18n.js", `${orphans.length} khoá không nơi nào dùng: ${orphans.join(", ")}`);

// ---------------------------------------------------------------------------
// 3a. The other direction: a key a page asks for that the dictionary does not
//     have.
//
//     Everything above asked whether the dictionary holds something nobody reads.
//     Nothing asked whether what a page reads exists at all, so the failure was
//     invisible in both directions at once.
//
//     It is not a crash. I18N.t falls back to the caller's string, and for
//     markup that fallback is the element's existing textContent — the Vietnamese
//     written into the HTML. So a missing key produces a page that renders
//     correctly in the language it was authored in and silently refuses to switch
//     to any other. public/404.html used `data-i18n="nav.home"` on both of its
//     home links; the dictionary has eleven nav.* keys and that is not one of
//     them, so an English visitor arriving from a broken link got "Về trang chủ"
//     in a language they did not choose, from the page whose entire job is to
//     help a lost visitor get somewhere else.
//
//     The specific page does not matter. The gap did: any data-i18n key with a
//     typo, or a key renamed in the dictionary and not in the pages, produced the
//     same silent bilingual leak.
// ---------------------------------------------------------------------------
const declared = viKeys.size > enKeys.size ? viKeys : enKeys;
const requested = new Set([
  ...[...allHtml.matchAll(/\bdata-i18n="([^"]+)"/g)].map((m) => m[1]),
  ...[...allHtml.matchAll(/\bdata-i18n-attr="([^"]+)"/g)]
    .flatMap((m) => m[1].split(",").map((pair) => pair.split(":")[1]?.trim()).filter(Boolean)),
]);
const undefinedKeys = [...requested].filter((key) => !declared.has(key)).sort();
if (undefinedKeys.length) {
  fail("khoá i18n chưa định nghĩa", "public/*.html",
    `${undefinedKeys.length} khoá trang dùng mà từ điển không có: ${undefinedKeys.join(", ")} — trang sẽ không đổi được ngữ`);
}

// ---------------------------------------------------------------------------
// 3e. The one word the server and the dictionary both write.
//
//     Every link in the header and the footer carries two copies of its label: the
//     `vi` string next to the key in src/pages.js, which is the Vietnamese a
//     crawler reads out of the bytes, and the data-i18n key, which the browser
//     resolves on a page that loads i18n.js. Nothing joined them, so "Điều khoản"
//     could be spelled one way in the dictionary and another there: the page would
//     switch language correctly and the pre-script fallback would quietly not
//     match it.
//
//     Both directions are visible to a reader. A key named there that the
//     dictionary does not have leaves the label showing as the raw key name; a
//     value that differs leaves the Vietnamese they saw first disagreeing with the
//     English they chose, which is the one failure a two-language site cannot have.
// ---------------------------------------------------------------------------
for (const block of chromeLinkLists(pagesSource)) {
  for (const link of block.matchAll(/key:\s*"([\w.]+)"[^}]*?vi:\s*"([^"]*)"/g)) {
    const [, key, value] = link;
    if (!declared.has(key)) {
      fail("khoá i18n chưa định nghĩa", "src/pages.js",
        `thanh điều hướng trỏ tới khoá "${key}" mà public/i18n.js không có`);
      continue;
    }
    const found = new RegExp(`'${key}':\\s*'((?:[^'\\\\]|\\\\.)*)'`).exec(viTable);
    const expected = found ? found[1].replace(/\\'/g, "'") : "";
    if (expected !== value) {
      fail("dịch lệch", "src/pages.js",
        `"${key}": "${value}" trong thanh điều hướng, "${expected}" ở từ điển`);
    }
  }
}

// ---------------------------------------------------------------------------
// 3c. The same key written twice in one dictionary.
//
//     Object literals accept it: the last one wins, silently. vi had
//     'nav.refund' twice, one of them already superseded, so correcting it changed
//     nothing and the mistake stayed invisible to every other check — including the
//     ones that read every key to decide whether it is used. Two halves of one file
//     disagreeing with each other is the same failure as a key missing from one
//     language, and it gets the same treatment.
// ---------------------------------------------------------------------------
for (const [name, label] of [["vi", "tiếng Việt"], ["en", "tiếng Anh"]]) {
  const block = objectLiteralAt(i18nSource, `${name}: {`);
  if (!block) {
    fail("khoá i18n trùng", "public/i18n.js", `không đọc được khối ${label} — có lẽ tên ${name}: { đã đổi`);
    continue;
  }
  const seen = new Set();
  for (const match of block.matchAll(/^ {4}'([\w.]+)':/gm)) {
    if (seen.has(match[1])) {
      fail("khoá i18n trùng", "public/i18n.js", `khoá "${match[1]}" khai báo hai lần trong ${label} — bản sau âm thầm ghi đè bản trước`);
    }
    seen.add(match[1]);
  }
}

// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// 3d. The category and badge translations, compared by value and not only by key.
//
//     The product page and the storefront card each translate two columns: the
//     category and the badge. The tables were added independently, so "Phổ biến",
//     "Doanh nghiệp" and "Ưu đãi sớm" were translated on the product page and not
//     on the card: the reader switched the whole shop to English, every price and
//     description followed, and the badge above them stayed Vietnamese.
//
//     It then compared key sets only. A half-finished edit that changes a value
//     on one side passes every key check there is, which is the one direction a
//     gate cannot afford to be blind in — the keys still line up, the words do
//     not, and nothing reports it. So this compares pairs, not sets.
//
//     Categories had no check at all. Half a gate reads as covered: the badge
//     half existed and the category half was simply forgotten, so a category
//     added to src/pages.js and not to the card translates on the product page
//     and leaks raw Vietnamese into the storefront grid.
// ---------------------------------------------------------------------------
{
  // "key": "value" pairs from an object-literal block. The value is what two
  // places have to agree on, so it is captured rather than inferred from the key.
  // Both quote styles count: the storefront tables are written with single quotes
  // and the page copy with double quotes, and a parser that only saw one of them
  // would read half a comparison as empty.
  const pairs = (block) => {
    const map = new Map();
    for (const match of block.matchAll(/["']([^"']+)["']\s*:\s*["']([^"']*)["']/g)) map.set(match[1], match[2]);
    return map;
  };
  // The storefront's half of the translation. It used to be two tables
  // (const CATEGORIES / const BADGES) declared inside public/app.js; the card now
  // derives its key from the value and looks it up in the dictionary, and the only
  // place a Vietnamese label is mapped to English is REPAIR_MAPS in i18n.js. That
  // is the table this check has to read, or it compares the product page against
  // nothing and passes on an empty map.
  const repairBlock = objectLiteralAt(i18nSource, "const REPAIR_MAPS");
  if (!repairBlock) {
    fail("dịch thiếu", "public/i18n.js", "không đọc được REPAIR_MAPS — không thể so sánh hai nơi dịch nhãn danh mục và badge");
  }
  const repairEn = (kind) => {
    const at = repairBlock.indexOf(`${kind}: {`);
    if (at < 0) return "";
    return objectLiteralAt(repairBlock.slice(at), "en: {");
  };
  const compare = (label, kind, pageBlocks) => {
    const onCard = pairs(repairEn(kind));
    const onPage = new Map();
    for (const block of pageBlocks) for (const [key, value] of pairs(block)) onPage.set(key, value);
    if (!onCard.size || !onPage.size) {
      fail("dịch thiếu", "public/app.js", `không đọc được bảng ${label} ở storefront hoặc ở trang sản phẩm — không thể so sánh hai nơi dịch ${label}`);
      return;
    }
    const missingOnCard = [...onPage.keys()].filter((key) => !onCard.has(key));
    const missingOnPage = [...onCard.keys()].filter((key) => !onPage.has(key));
    if (missingOnCard.length) fail("dịch thiếu", `public/app.js (${label})`, `thẻ sản phẩm chưa dịch: ${missingOnCard.join(", ")}`);
    if (missingOnPage.length) fail("dịch thiếu", `src/pages.js (${label})`, `trang sản phẩm chưa dịch: ${missingOnPage.join(", ")}`);
    // Both sides hold the key, so the key-set comparison stops here. The words
    // still have to be the same, and this is the only place that would notice.
    const wrong = [...onPage.entries()]
      .filter(([key, value]) => onCard.has(key) && onCard.get(key) !== value)
      .map(([key, value]) => `"${key}": "${value}" ở trang sản phẩm, "${onCard.get(key)}" ở thẻ`);
    if (wrong.length) {
      fail("dịch lệch", `public/app.js (${label})`, `hai nơi dịch ${label} khác nhau — ${wrong.join("; ")}`);
    }
  };

  compare("badge", "badge",
    [...pagesSource.matchAll(/badges:\s*\{([\s\S]*?)\}/g)].map((match) => match[1]));
  // The category table lives in src/lib/categories.mjs now: the catalogue's
  // raw values are mapped onto it where the catalogue is read, so the page
  // copy, the storefront cards and the store all use the same list. A gate
  // that read the table from a file that no longer holds it would compare
  // the Vietnamese identity map with the English one and report every
  // category as mistranslated.
  compare("danh mục", "category",
    [...categoriesSource.matchAll(/CATEGORY_EN\s*=\s*\{([\s\S]*?)\}/g)].map((match) => match[1]));
}

// ---------------------------------------------------------------------------
// 4. A value that belongs in config and is also written into a file.
//    The support address lives in .env, in the mail templates and in three
//    static pages. Change it in one place and the others keep sending buyers to
//    an address nobody reads.
// ---------------------------------------------------------------------------
// Read the values the audit compares against straight out of the environment,
// with no fallback.
//
// The fallback used to be the shop's own domain and support address. That is the
// one thing this check must never invent: with APP_URL unset it compared the
// files against a constant, found the constant in index.html's own JSON-LD, and
// passed. The mechanism reported itself healthy precisely when it was not
// configured. Now a missing value fails, loudly, naming itself.
const appUrlRaw = (process.env.APP_URL || "").trim();
const appUrl = (env.appUrl ?? "").trim();
const supportEmailRaw = (process.env.SUPPORT_EMAIL || "").trim();
const supportEmail = ((env.email.supportEmail ?? "").toLowerCase());
const appHost = appUrl ? new URL(appUrl).hostname.toLowerCase() : "";
const appHostRaw = appUrlRaw ? new URL(appUrlRaw).hostname.toLowerCase() : "";
// These two are what make the domain and address checks meaningful: without them the
// audit cannot tell the shop's own domain from a third party's, so it would either
// compare against a guess or skip the checks that matter.
//
// That used to be a hard failure, which is right in production and wrong everywhere
// else. A fresh clone has no .env, so `npm run audit` — the first thing anybody runs
// after cloning — failed on two lines about missing configuration, and a person who
// had just proved the suite worked on another machine was told the audit does not.
// The failure said nothing about the code.
//
// So a missing value now skips only what it makes impossible, says which, and lets
// the other groups run. In production APP_URL is set, so nothing is skipped and the
// gate is exactly as strict as before.
//
// The list is printed at the end rather than here, next to the group count. Printing
// it here meant the count on screen was the number known at this line, not the number
// that was skipped — and the R2 CORS check below adds a third reason, so a reader
// comparing the two numbers would have been told three groups ran when four did not.
const skipped = [];
if (!appUrlRaw) skipped.push("domain gõ tay (cần APP_URL)");
if (!supportEmailRaw) skipped.push("địa chỉ hỗ trợ gõ tay (cần SUPPORT_EMAIL)");

// The fonts used to be listed here: fonts.googleapis.com served the stylesheet
// and fonts.gstatic.com the woff2 files. Both are gone — the fonts are served
// from this origin (public/fonts) — and the hosts were deliberately not left in
// the list, so a page that reaches for a webfont again fails this gate instead
// of quietly adding a render-blocking request to a second origin.
const thirdParty = new Set(["www.w3.org", "schema.org", "www.sitemaps.org", "localhost", "img.vietqr.io", "resend.com", "supabase.com", "supabase.co", "paypal.com", "google.com", "cloudflare.com", "render.com", "ipapi.co", "ipwho.is", "er-api.com", "exchangerate-api.com", "indexnow.org",
  // Cloudflare Web Analytics. Both hosts are named because the match above is
  // exact rather than by suffix, and they are two different hosts: the first
  // serves the beacon script (src/pages.js), the second receives what the beacon
  // reports (the CSP connect-src in src/app.js). Neither can be reached from a
  // configuration value — Cloudflare issues the token, not the address — so
  // they are constants by nature, and the audit's real target, a hand typed
  // sonvudev.com, still fails as it should.
  "static.cloudflareinsights.com", "cloudflareinsights.com",
  // GA4 is gone from the site; the host stays out of the allow list on purpose, so
  // a page that reaches for it again fails this gate instead of quietly
  // adding a third-party script.
  ]);
// i18n.js is scanned too: brand.supportEmail is the configured default the pages
// fall back to, so letting it drift away from .env would mean an empty mailto on
// exactly the page a paying customer is reading.
//
// Tests are scanned for the production domain only, and that rule earned its place
// by failing on the first run. A test asserting on a literal shop address looks
// correct on the machine it was written on and fails everywhere else: CI sets
// APP_URL and SUPPORT_EMAIL to fixture values on purpose, so two tests failed from
// the first run and would have failed on every push from then on. A test that only
// passes with one .env is a test that does not run.
//
// The other domain and email rules stay off here. A test legitimately names a
// loopback address and a fixture mailbox, and flagging those would only teach
// people to ignore the audit.
const emailBearing = [...htmlFiles, ...scriptFiles].map((n) => path.join("public", n)).concat([path.join("src", "pages.js"), path.join("public", "i18n.js")]);
// One pattern for "the shop's own host is written out in this text", shared by all
// three scans below so they cannot disagree about what counts.
//
// The lookbehind excludes word characters and a hyphen, and nothing else. It used
// to exclude `/` as well, on the reasoning that a URL is caught by the scheme scan
// above — which is true of public/ and false of everything else: that scan reads
// only the HTML, the page scripts and src/pages.js. So in deploy/, cloudflare/,
// supabase/ and .github/ a bare `sonvudev.com` was flagged and `https://sonvudev.com`
// was not, because the character before the host in a URL is a slash. The one form
// those files are actually written in passed every time, and cloudflare/r2-cors.json
// is a file made of exactly that form.
//
// A subdomain still matches, which is correct: `www.<host>` in a config file is the
// same hardcode with one more label.
const hostPattern = (host) => new RegExp(`(?<![\\w-])${host.replace(/\./g, "\\.")}(?![\\w-])`, "gi");
const domainHits = (source, host) => [...source.matchAll(hostPattern(host))];

const testDir = path.join(root, "test");
const testFiles = existsSync(testDir) ? (await readdir(testDir)).filter((name) => name.endsWith(".js")) : [];
for (const name of testFiles) {
  // This file exists to run the audit against a fixture APP_URL, so it necessarily
  // contains a domain that the audit would flag. Skipping it by name is the only
  // honest option: a pattern meant to recognise "this is a fixture" would eventually
  // match a real hardcode written in the same shape.
  if (name === "audit.test.js") continue;
  // checks-workflow.test.js and env-contract.test.js validate that only
  // RFC 2606 reserved domains (.example, .test, .invalid, .localhost) appear
  // in the workflow/env config. They necessarily mention the fixture URL.
  if (name === "checks-workflow.test.js" || name === "env-contract.test.js") continue;
  // With no APP_URL there is no host to look for, and an empty pattern matches at
  // every position in every file. The missing-configuration failure is already
   // reported above; adding one finding per character on top of it buried the report
   // in output until the process was killed for writing too much, which is a much
   // worse way to be told the environment is unset.
   if (!appHostRaw) continue;
   const relative = path.join("test", name);
  const source = await read(relative);
  for (const match of domainHits(source, appHost)) {
    const line = source.slice(0, match.index).split("\n").length;
    fail("domain gõ tay", `${relative}:${line}`, `${match[0]} — APP_URL là ${appUrl}. Test phải đọc từ process.env.APP_URL, không ghi cứng domain.`);
  }
}

for (const relative of emailBearing) {
  const source = await read(relative);
  for (const match of source.matchAll(/https?:\/\/([a-z0-9.-]+)/gi)) {
    const host = match[1].toLowerCase();
    // The site's own origin is the one value that must never be written into a
    // file: it decides the canonical URL, which is what tells a search engine
    // which of two copies is the real page. index.html writes {{site}} and the
    // server fills it from APP_URL, so a domain change is one env var.
    if (appHostRaw && (host === appHost || host === `www.${appHost}`)) {
      fail("domain gõ tay", relative, `https://${host} viết thẳng vào file — dùng {{site}} (index.html) hoặc site() (src/pages.js)`);
      continue;
    }
    if (thirdParty.has(host)) continue;
    if (host.endsWith(".supabase.co") || host.endsWith(".r2.cloudflarestorage.com")) continue;
    fail("domain gõ tay", relative, `https://${host} — APP_URL là ${appUrl}`);
  }
  // The same domain written without a scheme. The scan above needs "https://" to
  // find a host, so prose like "áp dụng cho mọi giao dịch tại sonvudev.com" passed
  // straight through — and that is exactly the string a legal page shows a buyer
  // deciding whether the terms they are reading are the ones that apply.
  if (appHostRaw) {
    for (const match of domainHits(source, appHost)) {
      const line = source.slice(0, match.index).split("\n").length;
      fail("domain gõ tay", `${relative}:${line}`, `${match[0]} — APP_URL là ${appUrl}`);
    }
  }
  for (const match of source.matchAll(/[\w.+-]+@[\w.-]+\.[a-z]{2,}/gi)) {
    const address = match[0].toLowerCase();
    if (address === supportEmail) continue;
    if (/@(example|sonvudev|localhost|test|your-paypal)/.test(address)) continue;
    fail("email gõ tay", relative, `${match[0]} — SUPPORT_EMAIL là ${supportEmail}`);
  }
}

// ---------------------------------------------------------------------------
// 4b. The site's own host written into a file the audit never looked at.
//
//     Section 4 above reads public/, src/pages.js and i18n.js. deploy/ and
//     scripts/ were never in the list, so Caddyfile could pin the reverse proxy to
//     one domain and deploy.sh to one install root, and publish-product.mjs could
//     tell the operator to go and check one specific address at the end of a
//     release. Every gate was green and none of those files had ever been
//     examined.
//
//     Only this project's own host is checked here, not arbitrary hosts: a script
//     legitimately talks to api.render.com and supabase.com, and flagging those
//     would only teach people to ignore the audit. What must never be written down
//     is the value APP_URL already holds.
// ---------------------------------------------------------------------------
// Recursive, and over every directory that holds shipped configuration.
//
// It used to be `readdir` — non-recursive, two directories. So `scripts/lib/*.mjs`
// was never read: the only module in the repository that several tools import for
// their shared behaviour, in the one gate whose job is to notice a value written
// into two places. `cloudflare/` and `supabase/` were not in the list at all, which
// is why cloudflare/r2-cors.json could carry the production domain and schema.sql
// could carry a Vietnamese UI default, with every gate green.
//
// walkProjectFiles is the shared walker, so the excluded-directory rules cannot
// drift from the ones lint, build and metrics use. .github is not under it (it is a
// dot-directory) and has to be walked explicitly, because a domain typed into a
// workflow's env block reaches production exactly as surely as one in deploy/.
const infraFiles = [];
const INFRA_EXTENSIONS = /\.(mjs|js|sh|ps1|json|jsonc|yaml|yml|sql|example|service)$/;
for (const dir of ["deploy", "scripts", "cloudflare", "supabase", ".github"]) {
  const full = path.join(root, dir);
  if (!existsSync(full)) continue;
  if (dir === ".github") {
    // The one directory the shared walker excludes on purpose, because for most
    // tools .git and tool caches are noise. Here they are the subject.
    for (const name of await readdir(full, { recursive: true, withFileTypes: true })) {
      if (!name.isFile() || !INFRA_EXTENSIONS.test(name.name)) continue;
      infraFiles.push(path.join(".github", name.parentPath.slice(full.length + 1) || "", name.name).replaceAll("\\", "/"));
    }
    continue;
  }
  for (const absolute of await walkProjectFiles(full)) {
    const relative = path.relative(root, absolute).replaceAll("\\", "/");
    if (INFRA_EXTENSIONS.test(relative) || path.basename(relative) === "Caddyfile") infraFiles.push(relative);
  }
}
// Files whose entire purpose is to carry the address, so the scan must skip them —
// and each exemption says who holds them to account instead. A blanket skip would
// be the same hole as before; a named one is a decision.
const DOMAIN_EXEMPT = new Map([
  // Written by `npm run r2:cors:write` from APP_URL, and held to it by the R2 CORS
  // check below — which fails the build when this file and APP_URL disagree. So the
  // address is correct here by construction, and the gate for it already exists.
  ["cloudflare/r2-cors.json", "sinh ra từ APP_URL, kiểm bằng nhóm kiểm tra R2 CORS"],
  // This file, and the Caddyfile it also skips: both exist to name the mistake.
  ["scripts/audit-web.mjs", "chính file chứa lỗi cần tìm"],
  ["deploy/Caddyfile", "biến {$SITE_DOMAIN} do deploy/sonvudev-store.env.example cung cấp"],
  // CI workflow uses a fixture APP_URL (ci-fixture.example) to run the audit
  // without a real domain. The fixture is necessarily hardcoded here and is the
  // value the audit itself runs against.
  [".github/workflows/checks.yml", "fixture APP_URL cho CI, audit chạy chính với giá trị này"],
]);

for (const relative of infraFiles) {
  if (DOMAIN_EXEMPT.has(relative)) continue;
  // Skipped by name rather than by shape, because a shape recogniser eventually
   // matches a real hardcode written the same way.
   if (path.basename(relative) === "audit-web.mjs") continue;
   const source = await read(relative);
   if (!appHostRaw) continue;
   for (const match of domainHits(source, appHost)) {
    const line = source.slice(0, match.index).split("\n").length;
    fail("domain gõ tay", `${relative}:${line}`, `${match[0]} — APP_URL là ${appUrl}. Dùng biến môi trường thay vì ghi tên miền.`);
  }
}

// ---------------------------------------------------------------------------
// 4bb. The R2 bucket's origin list, which is the one place a browser can be refused.
//
//     cloudflare/r2-cors.json is applied to the bucket by hand and read by nothing.
//     No other check in this repository can see it, and the failure it produces is
//     the single release-publishing action in the shop: public/admin.js asks the
//     server for a presigned URL and then PUTs to *.r2.cloudflarestorage.com from
//     the browser, so a stale AllowedOrigins refuses the upload with a CORS error
//     and nothing else in the project notices — not the build, not /api/health,
//     not check:production.
//
//     So the file is compared against APP_URL by the same function the fix command
//     uses (scripts/lib/cors.mjs), which means the check and the repair cannot
//     disagree about what "correct" is.
//
//     Skipped on a fixture APP_URL, and it says so. CI sets APP_URL to
//     https://ci-fixture.example so that a fresh clone and this machine run the
//     same checks — a value whose host is a reserved .example domain cannot be a
//     shop anybody buys from, so asking whether the committed CORS file matches it
//     would report a false failure on every push. The real comparison happens on a
//     machine with a real .env, and again in check:production before a deploy.
// ---------------------------------------------------------------------------
if (!appHostRaw || (appUrl && isFixtureHost(appUrl))) {
  skipped.push("R2 CORS khớp APP_URL (APP_URL là giá trị giả)");
} else if (appUrl) {
  let corsRules = [];
  let corsReadable = true;
  try {
    corsRules = JSON.parse(await read(path.join("cloudflare", "r2-cors.json")));
  } catch (error) {
    corsReadable = false;
    fail("R2 CORS lệch", "cloudflare/r2-cors.json", `không đọc được: ${error.message}`);
  }
  if (corsReadable) {
    const diff = corsDiff(corsRules, appUrl);
    if (diff.missing.length) {
      fail("R2 CORS lệch", "cloudflare/r2-cors.json",
        `thiếu ${diff.missing.join(", ")} — upload từ trang quản trị sẽ bị CORS chặn. Chạy: npm run r2:cors:write`);
    }
    // An extra origin is a widening of who may upload to the bucket rather than a
    // break, so it is reported with the same fix but not as the same severity.
    if (diff.extra.length) {
      fail("R2 CORS thừa origin", "cloudflare/r2-cors.json",
        `${diff.extra.join(", ")} không do APP_URL sinh ra — ai đó có thể upload vào bucket`);
    }
  }
}

const accented = (value) => /[àáâãèéêìíòóôõùúýăđĩũơưạảấầẩẫậắằẳẵặẹẻẽếềểễệỉịọỏốồổỗộớờởỡợụủứừửữựỳỵỷỹ]/i.test(value);
// ---------------------------------------------------------------------------
// 4c. Content the storefront prints, written in a language the reader may not
//     speak.
//
//     /api/checkout/options used to answer with Vietnamese labels — "Chuyển khoản
//     ngân hàng / Quét mã QR", "Hỗ trợ MoMo, ZaloPay và quét mã VietQR" — and the
//     checkout form printed them straight into the markup. A visitor who switched
//     the site to English chose a payment method labelled in the language they had
//     chosen not to read, on the one screen where the money is.
//
//     The server now names a key and the browser resolves it, so no sentence can
//     survive in this file by accident. src/pages.js is deliberately exempt: it
//     renders the page itself and keeps one table per locale, which is the only
//     place a sentence is allowed to belong to one language.
// ---------------------------------------------------------------------------
for (const name of ["payments.js"]) {
  const file = path.join("src", name);
  if (!existsSync(file)) continue;
  const source = await read(file);
  for (const match of source.matchAll(/(['"`])((?:[^'"`\\]|\\.)*?)\1/g)) {
    const value = match[2];
    if (value.length > 2 && accented(value)) {
      const line = source.slice(0, match.index).split("\n").length;
      fail("tiếng Việt ở phía máy chủ", `src/${name}:${line}`, `"${value}" — nội dung hiển thị phải đến từ từ điển, máy chủ chỉ gửi khoá`);
    }
  }
}

// ---------------------------------------------------------------------------
// 4d. The same identity declared twice on one page.
//
//     og:site_name, og:brand and twitter:site are added to every rendered page by
//     brandMeta() from BRAND_NAME. index.html also typed its own, with the brand
//     written into og:site_name, og:title, og:image:alt and twitter:title — so a
//     page carried two og:site_name tags with no way to say which one a scraper
//     would believe, and changing BRAND_NAME left the homepage announcing the old
//     shop on every share card while the product pages announced the new one.
//
//     "Declared once" is the property worth checking. Whether a page may add one of
//     its own is a question about the brand, and the audit cannot answer that.
// ---------------------------------------------------------------------------
for (const name of htmlFiles) {
  const source = await read(path.join("public", name));
  for (const property of ["og:site_name", "og:brand"]) {
    const declared = [...source.matchAll(new RegExp(`property="${property}"`, "g"))];
    if (declared.length > 1) {
      fail("thương hiệu khai báo hai lần", `public/${name}`, `${property} xuất hiện ${declared.length} lần — để brandMeta() lo, đừng gõ thêm vào template`);
    }
  }
}

// ---------------------------------------------------------------------------
// 4e. The language switch: one, on one page.
//
//     The switch used to live on all nine translated pages, which meant nine buttons
//     for one decision. Two of them were positioned by CSS rules that existed only to
//     place a button — .lookup-lang and .paypal-lang — on pages with no header to put
//     it in, which is the shape of a control added because it was missing rather than
//     because it was wanted.
//
//     Now there is one, on the homepage. Every other page reads the choice from
//     localStorage, which public/i18n.js does before it paints anything, so a buyer
//     who picked English on the homepage is in English on the terms page without a
//     second control to find.
//
//     Two failures are worth catching here, and they pull in opposite directions:
//
//     - a switch on a page with no dictionary flips nothing;
//     - a second switch somewhere else is the duplication this removed.
//
//     Both are checked by count rather than by style, so the rule survives the control
//     being restyled or moved.
// ---------------------------------------------------------------------------
{
  const withDictionary = [];
  const withSwitch = [];
  for (const name of htmlFiles) {
    const source = await read(path.join("public", name));
    // Accept absolute (/i18n.js) or relative (i18n.js); locale-prefixed pages require absolute.
    const hasDictionary = /src="\/?i18n\.js"/.test(source);
    const hasSwitch = /data-lang-switch|data-lang-toggle/.test(source);
    if (hasDictionary) withDictionary.push(name);
    if (hasSwitch) {
      withSwitch.push(name);
      if (!hasDictionary) {
        fail("nút đổi ngữ không có từ điển", `public/${name}`, `có data-lang-switch nhưng không nạp i18n.js — nút sẽ không làm gì`);
      }
    }
  }
  // Exactly one page owns the decision. Naming it rather than counting alone means the
  // failure says where to look.
  if (withSwitch.length !== 1 || withSwitch[0] !== "index.html") {
    fail("nút đổi ngữ lặp hoặc thiếu", withSwitch.length ? withSwitch.join(", ") : "(không trang nào)",
      `phải đúng một trang chủ mới có nút đổi ngôn ngữ (index.html); các trang khác đọc lựa chọn đã lưu. Đang có ${withSwitch.length} trang: ${withSwitch.join(", ") || "không trang nào"}`);
  }
  // And the homepage must still be translated, or the switch there is decoration.
  if (!withDictionary.includes("index.html")) {
    fail("trang chủ mất từ điển", "public/index.html", "trang chủ phải nạp i18n.js — nút đổi ngôn ngữ không có gì để dịch");
  }
}

// ---------------------------------------------------------------------------
// 4g-bis. A CSS variable that is read and never declared.
//
// The silent one. `font-family: var(--display)` with no --display in :root is not
// a parse error and not a rendering error: the declaration is dropped, the property
// falls back to its initial value, and the page still draws. public/styles.css had
// three rules doing this — the review heading's typeface and the review form's and
// the review list's backgrounds — so the review block was rendering in the body
// font on transparent, indistinguishable from an intentional choice.
//
// Nothing about "the page renders" is evidence that the CSS did what it said.
// Every var() is compared against the :root block, which is the only place a
// custom property can come from here.
// ---------------------------------------------------------------------------
{
  const css = await read(path.join("public", "styles.css"));
  // The :root block, taken from the place :root actually starts to the brace that
  // closes it.
  //
  // It used to be "everything up to the first }", which was the same thing only
  // while :root was the first rule in the file. The self-hosted @font-face rules
  // now come first, so that expression measured the font declarations and
  // concluded that every variable in the stylesheet was undeclared — the gate
  // reporting twenty variables missing while the page rendered them all.
  const rootStart = css.search(/:root\s*\{/);
  const rootBlock = rootStart === -1 ? "" : css.slice(rootStart, css.indexOf("}", rootStart) + 1);
  const declared = new Set([...rootBlock.matchAll(/(--[a-z0-9-]+)\s*:/gi)].map((m) => m[1]));
  const used = new Map();
  for (const match of css.matchAll(/var\(\s*(--[a-z0-9-]+)/gi)) {
    if (!used.has(match[1])) used.set(match[1], []);
    const line = css.slice(0, match.index).split("\n").length;
    if (!used.get(match[1]).includes(line)) used.get(match[1]).push(line);
  }
  for (const [name, lines] of used) {
    if (declared.has(name)) continue;
    fail("biến CSS chưa khai báo", "public/styles.css",
      `var(${name}) ở dòng ${lines.join(", ")} nhưng :root không khai báo — khai báo bị bỏ qua, thuộc tính rơi về giá trị mặc định`);
  }
}

// ---------------------------------------------------------------------------
// 4g. A page that uses the brand fonts without loading them.
//
//     styles.css names 'Space Grotesk' for .brand, the headings and the numerals
//     that carry the product prices. A page that links the stylesheet but not the
//     font gets those rules with nothing to resolve to, and falls back to the
//     generic sans-serif — the brand's own typeface, gone, on exactly the page a
//     buyer is looking at.
//
//     public/admin.html did this, and nothing reported it: there was no check, and
//     the omission is invisible in a diff that only compares HTML structure. The
//     link block is copied into ten pages by hand, so "the other pages have it"
//     is not a property anything enforces.
//
//     It stays copied. Eleven occurrences of a 200-character <link> is a smaller
//     problem than a token every page has to resolve before its CSS applies, and
//     the check below is what makes the copies safe: a new page that forgets gets
//     told, instead of quietly rendering in Arial.
//
//     The fonts moved: they are served from this origin now (public/fonts), and
//     the @font-face rules travel inside the stylesheet every page already
//     loads. So the check has two halves. The stylesheet has to declare both
//     families, or a page that loads it has no brand typeface at all; and no
//     page may reach for a webfont host again, because that stylesheet was a
//     render-blocking request to a second origin and cost about 260 ms.
// ---------------------------------------------------------------------------
{
  const css = await readFileSync(path.join("public", "styles.css"), "utf8");
  const faces = [...css.matchAll(/@font-face\s*\{([^}]*)\}/g)].map((m) => m[1]);
  for (const family of ["Space Grotesk", "Be Vietnam Pro"]) {
    const own = faces.filter((body) => body.includes(`font-family:'${family}'`));
    if (!own.length) {
      fail("thiếu khai báo @font-face", "public/styles.css",
        `không có @font-face cho '${family}' — mọi trang nạp stylesheet sẽ rơi về sans-serif mặc định`);
      continue;
    }
    // A font family without the Vietnamese block is not a font for this shop.
    //
    // DM Sans shipped latin and latin-ext only, and latin-ext stops at U+1E9F —
    // the Vietnamese block starts at U+1EA0. Every accented character in the
    // body copy was therefore rendered by the fallback while the unaccented
    // characters stayed in the brand face: a Vietnamese paragraph in two
    // typefaces, and nothing in the build said so.
    if (!own.some((body) => /unicode-range:[^}]*U\+1EA0/i.test(body))) {
      fail("thiếu khai báo @font-face", "public/styles.css",
        `font '${family}' không có subset tiếng Việt (unicode-range phải chứa U+1EA0) — mọi chữ có dấu sẽ rơi về font hệ thống`);
    }
  }
  for (const name of htmlFiles) {
    const source = await read(path.join("public", name));
    // Both forms. The page links the minified stylesheet "/styles.min.css";
    // the source "styles.css" is only what the minify step reads. Matching only
    // the source name left the page that actually lost its fonts unexamined.
    if (!/href="\/?styles\.min\.css"/.test(source)) continue;
    if (/fonts\.(?:googleapis|gstatic)\.com/.test(source)) {
      fail("font thương hiệu từ bên ngoài", `public/${name}`,
        "trang vẫn nạp webfont từ fonts.googleapis.com — phải dùng font tự host trong /fonts");
    }
  }
}

// ---------------------------------------------------------------------------
// 4h. A refusal the browser cannot translate.
//
//     src/app.js answered 43 failures with `res.json({ error: "…tiếng Việt…" })`
//     and every page read that sentence before its own dictionary — the shape was
//     `payload.error || T('some.fallback')`, and the server was first. The visitor
//     who switched the shop to English was therefore told what went wrong in
//     Vietnamese, by the shop, including on the checkout form.
//
//     Nothing caught it, and nothing would have: the string was in the right place
//     grammatically, the audit only looked at HTML and at keys, and the sentence
//     was correct Vietnamese. It was a correct sentence in the wrong language for
//     the reader, which no spelling or accent check can see.
//
//     The rule is the one src/refuse.js exists to make possible: a refusal that
//     goes into a JSON body has to carry a `code` the dictionary can resolve. Both
//     halves of it. A sentence on its own is only allowed where nothing reads the
//     body as prose.
// ---------------------------------------------------------------------------
const VIETNAMESE_SENTENCE = /[\u00c0-\u1ef9]{2,}/;
for (const name of ["app.js", "store.js", "orders.js", "payments.js", "r2.js", "reviews.js", "rates.js", "geo.js", "notify.js"]) {
  const file = path.join("src", name);
  if (!existsSync(file)) continue;
  const source = await read(file);
  for (const match of source.matchAll(/res\.status\([^)]*\)\.json\(\{\s*error:\s*"([^"]+)"/g)) {
    if (VIETNAMESE_SENTENCE.test(match[1])) {
      fail("lỗi tiếng Việt cho trình duyệt", "ngôn ngữ khai báo sai", `src/${name}`,
        `gửi thẳng "${match[1].slice(0, 60)}" mà không có code — dùng refuse("khoá", "câu tiếng Việt", status) để trình duyệt dịch được`);
    }
  }
  // And the same, for a body built as a variable rather than an object literal.
  for (const match of source.matchAll(/json\(\{\s*error:\s*`([^`]+)`/g)) {
    fail("lỗi tiếng Việt cho trình duyệt", "ngôn ngữ khai báo sai", `src/${name}`,
      `gửi thẳng một câu nội suy "${match[1].slice(0, 60)}" mà không có code — dùng refuse()`);
  }
}

// Every key the server sends must exist in both halves of the dictionary. The
// orphan check above asks the opposite question — is anything in the dictionary
// unread — and neither would notice a key that is sent, is read, and is simply
// not there: the browser falls through to the sentence and the page is Vietnamese
// again, with no finding anywhere.
// Comments are removed before the scan. A key that appears only in prose is not
// a key anyone sends, and reading documentation as code produced thirty-eight
// phantom usages on the first run of this check — the same mistake
// objectLiteralAt above made, in a different parser. The stripper is the shared
// one in scripts/lib/source.mjs: this file used to carry two of its own, and the
// regex one could not tell a URL inside a string from a comment.

for (const [name, source] of keyProducers) {
  for (const match of stripComments(source).matchAll(/refuse\("([\w.]+)"/g)) {
    if (!declared.has(match[1])) {
      fail("khoá i18n chưa định nghĩa", name, `máy chủ gửi "${match[1]}" mà từ điển không có — trình duyệt sẽ hiện tiếng Việt`);
    }
  }
}

// ---------------------------------------------------------------------------
// 4i. A page claiming a translation it does not have.
//
//     terms.html, privacy.html, refund.html and about.html each carried
//     `<meta property="og:locale:alternate" content="en_US">` — a statement to
//     every social scraper that an English version of the page exists. None of them
//     had one: they do not load i18n.js, and their prose is Vietnamese.
//
//     What made it worse than a harmless wrong tag is that each of those four
//     pages already said the opposite in its own hreflang, which listed `vi` and
//     `x-default` and nothing else. The page told two crawlers contradictory
//     things about itself, in markup written to agree.
//
//     So the rule is: if a page lists an alternate locale, it has to serve that
//     locale. index.html keeps its en_US because it genuinely has /en/ routes.
//     When the legal pages get English versions this stops being a finding, and
//     the check is the thing that has to notice — not the author.
// ---------------------------------------------------------------------------
for (const name of htmlFiles) {
  const source = await read(path.join("public", name));
  const alternate = /property="og:locale:alternate" content="([^"]+)"/.exec(source);
  if (!alternate) continue;
  const hasAlternateRoute = /hreflang="en"/.test(source) || /\/en\//.test(source);
  if (!hasAlternateRoute) {
    fail("ngôn ngữ khai báo sai", `public/${name}`,
      `khai báo og:locale:alternate="${alternate[1]}" nhưng không phục vụ bản ${alternate[1].slice(0, 2)} — hreflang của chính trang này cũng chỉ liệt kê vi`);
  }
}

// ---------------------------------------------------------------------------
// 4f. A placeholder the renderer does not know how to fill.
//
//     A product description may contain {{founder}}, and it is filled on the way out
//     from BRAND_FOUNDER_NAME. That is the whole reason it is a placeholder: the name
//     was typed by hand once, into one product's text, in a spelling the owner does
//     not use — "Vũng Trọng Sơn" where the name is "Vũ Trung Sơn". Nothing could
//     compare the two, because every other mention of the owner on the site read
//     from configuration and that one read from a text field.
//
//     A placeholder the renderer does not recognise is the failure this design has
//     instead, and a worse-looking one: the buyer reads the braces. So an unknown
//     {{token}} in a template is a FAIL rather than something that quietly ships.
//
//     Scoped to the templates, which is where a placeholder can reach a customer.
//     The audit's own source quotes several of them in the explanation of this very
//     check, and a check that fires on the description of the bug it is looking for
//     is a check that gets switched off.
//
//     The list itself is not written here. It is read out of src/pages.js, next to
//     the builder that fills the values, so a token the renderer learns is known
//     here the same edit — the hand-written copy this replaces had already drifted
//     ({{brandWordmark}} filled, "unknown"), failing the build on correct pages.
const readTokenList = (exportName) => {
  const block = pagesSource.match(new RegExp(`export const ${exportName} = \\[([\\s\\S]*?)\\];`))?.[1] || "";
  return (block.match(/"([^"]+)"/g) || []).map((quoted) => quoted.replace(/"/g, ""));
};
const KNOWN_TOKENS = new Set([...readTokenList("PAGE_TOKENS"), ...readTokenList("COPY_TOKENS")]);
if (!KNOWN_TOKENS.size) {
  fail("placeholder lạ", "src/pages.js", "không đọc được PAGE_TOKENS/COPY_TOKENS — audit không thể biết token nào là hợp lệ");
}
for (const name of htmlFiles) {
  const source = await read(path.join("public", name));
  for (const token of source.matchAll(/\{\{\s*([a-zA-Z]+)\s*\}\}/g)) {
    if (!KNOWN_TOKENS.has(token[1])) {
      fail("placeholder lạ", `public/${name}`, `{{${token[1]}}} không nằm trong danh sách token mà renderPage biết điền`);
    }
  }
}

// ---------------------------------------------------------------------------
// 5. Structured data that points at a page robots.txt forbids.
//    SearchAction aimed at /lookup, a page the store deliberately hides: the
//    markup told Google to read a page it had been told to skip. Anything a
//    crawler is told to read has to be a page it is allowed to read.
// ---------------------------------------------------------------------------
// The rules are read out of src/robots.js — the module the server renders the file
// with — rather than scraped from src/app.js. They used to be scraped from app.js
// as `Disallow: "…"` literals, and moved to their own module made that capture come
// back empty: this check went from "verifies structured data does not point at a
// hidden page" to "always passes", with no red line anywhere. Reading the module
// means adding a private path is one edit that both the response and this check see.
const robotsSource = await read(path.join("src", "robots.js"));
const robotsBlock = robotsSource.match(/ROBOTS_DISALLOW\s*=\s*(?:Object\.freeze\()?\s*\[([\s\S]*?)\]/)?.[1] || "";
const blocked = new Set((robotsBlock.match(/'([^']+)'/g) || []).map((quoted) => quoted.replace(/'/g, "").replace(/\/$/, "")));
if (!blocked.size) {
  fail("schema chặn", "src/robots.js", "không đọc được ROBOTS_DISALLOW — audit không thể biết trang nào robots.txt cấm, nên mọi dữ liệu có cấu trúc đều bị coi là hợp lệ");
}
for (const match of pagesSource.matchAll(/"(?:urlTemplate|item|url)"\s*:\s*`?\$\{?site\(\)\}?(\/[^"`]*)/g)) {
  // Only the path decides whether a crawler may read it. A target with a query
  // string still describes the page behind it, and that page is what matters.
  const target = match[1].split("?")[0].replace(/\/$/, "");
  if (blocked.has(target)) fail("schema chặn", "src/pages.js", `dữ liệu có cấu trúc trỏ tới ${target} mà robots.txt chặn`);
}

// ---------------------------------------------------------------------------
// 5b. Vietnamese written without its diacritics, in text a person reads.
//
//     Two buttons in the admin panel read "Tai them don hang" and "Da xem het don
//     hang" for as long as the panel has existed. Nothing here would have caught it:
//     it parses, it renders, it has the right shape, and every test that touched the
//     panel asserted on structure rather than on what it says.
//
//     The first attempt compared single words and was hopeless: "thanh", "hay",
//     "dung", "thay", "ngay" and "trong" are all real Vietnamese words with the
//     diacritics dropped, and English code comments are full of "that", "than" and
//     "them", which are the same as "thất" and "thận" without marks. Fifty-three
//     findings, none of them the bug.
//
//     So this matches phrases of two or three words instead. "Tai them don hang"
//     cannot be English, cannot be a coincidence, and is unmistakably the
//     unaccented form of a phrase spelled correctly somewhere else in the project.
//     The dictionary is still built from the project itself, so it has nothing to
//     tune and cannot fire on a phrase the project has never written.
// ---------------------------------------------------------------------------
const stripDiacritics = (value) => value.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
const PHRASES = new Map();
for (const source of [i18nSource, ...htmlSources, ...pageScriptSources, await read(path.join("src", "pages.js")), await read(path.join("src", "app.js"))]) {
  const words = source.replace(/<[^>]+>/g, " ").match(/[\wÀ-ỹĐđ]{2,}/g) || [];
  for (let i = 0; i < words.length; i += 1) {
    for (const size of [3, 2]) {
      if (i + size > words.length) continue;
      const phrase = words.slice(i, i + size);
      // Every word has to be accented, or the phrase is already ASCII somewhere
      // else and the entry would fire on perfectly correct text.
      if (!phrase.every(accented)) continue;
      PHRASES.set(stripDiacritics(phrase.join(" ")), phrase.join(" "));
    }
  }
}
const suspects = [...PHRASES.keys()].sort((a, b) => b.length - a.length);
// i18n.js is excluded: its own source is the dictionary, so every correctly spelled
// phrase in the project appears in it in ASCII form as the key.
const customerFacing = [...htmlFiles, ...scriptFiles.filter((name) => name !== "i18n.js")].map((name) => path.join("public", name));
// Comments are stripped first, and only comments: they are English, and a save
// handler documented in prose is full of "that" and "them". Strings are kept,
// because that is where the customer-facing text lives. The stripper is the
// shared scanner in scripts/lib/source.mjs, which unlike the regex this used to
// have keeps a URL inside a string out of its way and keeps every offset where
// it was.
const customerFacingText = (relative, raw) => stripComments(relative.endsWith(".js")
  ? raw
  : raw.replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<!--[\s\S]*?-->/g, " "));
for (const relative of customerFacing) {
  const raw = await read(relative);
  const text = customerFacingText(relative, raw);
  for (const phrase of suspects) {
    const match = new RegExp(`(?<![\\wÀ-ỹ])${phrase.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(?![\\wÀ-ỹ])`, "i").exec(text);
    if (match) fail("tiếng Việt không dấu", relative, `"${match[0]}" — viết đúng là "${PHRASES.get(match[0].toLowerCase())}"`);
  }
}

// The same rule for the text a person reads when something is wrong rather than
// when they buy something: script output and test names.
//
// Those two were never scanned, so the missing diacritics accumulated in exactly
// the places that get read under pressure — an unaccented "Khong tim thay san pham",
// an unaccented "phai tra ve cung mot don", an unaccented "trang sau khac trang
// truoc". Unaccented Vietnamese is not illegible, which is why it survived: it
// reads as written, just wrong, and only someone who already knows the correct
// spelling notices. A customer on the storefront would have spotted it at once.
//
// Longer phrases only, and comments are stripped as they are above. Two Vietnamese
// words collide with ordinary English often enough to be useless ("on it", "so the"),
// and this repository writes its code comments in English on purpose — the Vietnamese
// that appears in a comment is a quotation of a message that was wrong, and a check
// that fires on the description of a fixed bug is a check people disable.
//
// Strings and test titles are not ambiguous: if three or more accented words appear
// bare together, they are a sentence in this language.
// Recursive for the two directories that hold shipped configuration and shared
// helpers, top-level for test/.
//
// test/ is left shallow on purpose. Its files are fixtures: several contain the exact
// unaccented strings this check exists to catch, and a deep scan turned a two-second
// audit into a thirteen-second one on a copy of the project — a check whose cost grows
// with the repository rather than with the problem is a check that gets turned off.
// scripts/lib/ is scanned deeply, and that is where the misspellings that reach every
// tool actually live.
const operatorFacing = [];
for (const dir of ["scripts", "test", "deploy"]) {
  const full = path.join(root, dir);
  if (!existsSync(full)) continue;
  const shallow = dir === "test";
  const names = shallow ? await readdir(full) : await walkProjectFiles(full);
  for (const entry of names) {
    const relative = shallow ? path.join(dir, entry) : path.relative(root, entry).replaceAll("\\", "/");
    if (/\.(mjs|js|sh|service|example)$/.test(relative) || path.basename(relative) === "Caddyfile") operatorFacing.push(relative);
  }
}
if (existsSync(path.join(root, ".env.example"))) operatorFacing.push(".env.example");
const longSuspects = [...PHRASES.entries()].filter(([bare]) => bare.split(" ").length >= 3).map(([bare]) => bare).sort((a, b) => b.length - a.length);
for (const relative of operatorFacing) {
  // This test exists to make the check fail, so it has to contain the mistake. Same
  // reasoning as skipping this file's own domain scan above, and the same cost: a
  // deliberate hole in one file, for the file that proves the rule works.
  if (path.basename(relative) === "audit.test.js") continue;
  const text = stripComments(await read(relative));
  for (const phrase of longSuspects) {
    const match = new RegExp(`(?<![\\wÀ-ỹ])${phrase.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(?![\\wÀ-ỹ])`, "i").exec(text);
    if (match) fail("tiếng Việt không dấu", relative, `"${match[0]}" — viết đúng là "${PHRASES.get(match[0].toLowerCase())}"`);
  }
}

// A token the server never substitutes is a value the page prints verbatim, and a
// token on a page the renderer never sees is the same thing for a second reason.
// Both used to hide behind one hand-written list of token *names*, which answered
// the wrong question twice over: it could not tell that {{reviewMax}} had no
// substitute anywhere, and it could not tell that {{support}} had one and was still
// being printed raw — because lookup.html was never routed through renderPage at
// all. /lookup served the literal "{{support}}" as the support address on the
// recovery page, and /404.html printed "© {{year}}". Four gates, all green.
//
// So the names are read out of the renderer's own wiring instead of being written
// down, and a file carrying any token has to be named in the renderer at all. The
// wiring used to be eleven replaceAll literals inside renderPage; it is now one
// shared filler fed by PAGE_TOKENS in src/pages.js, so this check reads that list
// and additionally asserts renderPage still goes through the filler. If renderPage
// ever stops using it, every token fails loudly rather than silently passing again.
const renderStart = serverSource.indexOf("async function renderPage");
const renderBody = serverSource.slice(renderStart, serverSource.indexOf("const sendPage", renderStart));
if (!/fillPageTokens\s*\(/.test(renderBody)) {
  fail("token chưa nối", "src/app.js", "renderPage không còn dùng fillPageTokens — kiểm tra này không còn nhìn thấy token nào được nối");
}
const wiredTokens = new Set(readTokenList("PAGE_TOKENS"));
for (const name of htmlFiles) {
  const source = await read(path.join("public", name));
  for (const match of source.matchAll(/\{\{\s*([a-zA-Z]+)\s*\}\}/g)) {
    if (!wiredTokens.has(match[1])) {
      fail("token chưa nối", `public/${name}`, `{{${match[1]}}} không có chỗ nào trong renderPage điền vào`);
    }
    if (!serverSource.includes(`"${name}"`)) {
      fail("trang chưa render", `public/${name}`, `có token {{${match[1]}}} nhưng tên file không xuất hiện trong src/app.js — express.static sẽ serve file thô và token lọt thẳng ra trang`);
    }
  }
}

// ---------------------------------------------------------------------------
// 5f. A header that spells the brand out instead of reading it from configuration.
//
//     Every page's header carries the wordmark, and its last segment is styled
//     separately, so it cannot be a plain {{brandName}} substitution — which is
//     exactly why it was typed into fourteen places: seven HTML files, twice in most
//     of them, plus the product page the server builds in code.
//
//     Fourteen copies is fourteen chances to answer a rename with the old shop, and it
//     already happened: the product page is the surface a crawler reads most, and its
//     header kept announcing the old brand while the title, the canonical, the
//     structured data and every email had moved on.
//
//     The check above it could not see this. Section 4d counts og:site_name inside
//     public/*.html, and src/pages.js never exists as a file — so the one header that
//     is generated in code, and the one most likely to drift, was the one it was blind
//     to. So this asks a question with no brand value in it: does a site header carry
//     literal text, or does it carry the token?
//
//     Brand-value independent on purpose. CI sets BRAND_NAME to a fixture, so a check
//     built around the real name would pass there and catch nothing.
// ---------------------------------------------------------------------------
for (const name of htmlFiles) {
  const source = await read(path.join("public", name));
  for (const header of source.matchAll(/<a class="brand"[^>]*>([\s\S]*?)<\/a>/g)) {
    if (!header[1].includes("{{brandWordmark}}")) {
      fail("thương hiệu gõ cứng", `public/${name}`, `header viết chữ thật thay vì {{brandWordmark}} — đổi BRAND_NAME sẽ không áp dụng ở đây`);
    }
  }
}
// The generated one. src/pages.js is the header most likely to drift and the one no
// file-based check can reach.
for (const header of pagesSource.matchAll(/<a class="brand"[^>]*>([\s\S]*?)<\/a>/g)) {
  if (!header[1].includes("${brandWordmark()}")) {
    fail("thương hiệu gõ cứng", "src/pages.js", `header trang sản phẩm viết chữ thật thay vì \${brandWordmark()} — đây là trang crawler đọc nhiều nhất`);
  }
}

// ---------------------------------------------------------------------------
// 5d. An hreflang pointing at a URL the site does not answer.
//
//     index.html declared hreflang="en" href="{{site}}/en" for as long as the
//     language switch existed. There is no /en route and never was: the English
//     pages are /en/product/<slug>, rendered by pages.js. So the homepage told a
//     crawler the English version of itself lived at a 404.
//
//     This audit could not catch it, because the hand-written dynamicRoute list in
//     section 1 included /en — it asserted the existence of the very route it was
//     meant to check. The routes are read out of src/app.js instead, so the check
//     can no longer pass by believing something the server does not register.
// ---------------------------------------------------------------------------
const routeMatches = [...serverSource.matchAll(/app\.(?:get|post|patch|put|delete)\(\s*(?:"([^"]*)"|\[([^\]]*)\])/g)];
const routePaths = routeMatches.flatMap((m) => (m[2] ? [...m[2].matchAll(/"([^"]*)"/g)].map((x) => x[1]) : [m[1]])).filter(Boolean);
// The static locale routes (/en/, /de/terms, ...) are registered by a loop over
// LOCALE_CODES, not by literal app.get strings, so the literal regex above
// cannot see them. Read the same registry the router reads - a new locale can
// never drift past this check by being invisible to it.
for (const code of LOCALE_CODES) {
  if (code === "vi") continue;
  routePaths.push(`/${code}`, `/${code}/`, `/${code}/about`, `/${code}/terms`, `/${code}/privacy`, `/${code}/refund`, `/${code}/contact`);
}
const toRouteRegex = (route) => new RegExp(`^${route.split("/").map((part) => (part.startsWith(":") ? "[^/]+" : part.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"))).join("\\/")}/?$`);
const answers = (target) => isRealTarget(target) || routePaths.some((route) => toRouteRegex(route).test(target));

for (const name of htmlFiles) {
  const source = await read(path.join("public", name));
  for (const match of source.matchAll(/hreflang="([^"]+)"\s+href="\{\{site\}\}([^"]+)"/g)) {
    if (!answers(match[2])) {
      fail("hreflang chết", `public/${name}`, `hreflang="${match[1]}" trỏ tới ${match[2]} mà máy chủ không có route nào trả lời`);
    }
  }
}
// The product renderer picks its own two shapes, one per language, and hangs the
// alternate links off them. Neither is written in a template, so it is asserted
// against the route list here instead of being read out of a tag.
for (const shape of ["/product/:slug", "/en/product/:slug"]) {
  if (!routePaths.includes(shape)) {
    fail("hreflang chết", "src/pages.js", `productUrl() sinh ra ${shape} nhưng src/app.js không đăng ký route đó`);
  }
}

// ---------------------------------------------------------------------------
// 6. A page in public/ that nothing links to.

// 6a. A data-i18n element with no text in it.
//
// The storefront fills these from the dictionary at runtime, so an element left
// empty is fine for a person with JavaScript and empty for everyone else: a
// crawler, a link-preview bot, an assistant fetching the HTML, or a reader who
// turned scripting off. The text has to be sitting in the markup already, which is
// what scripts/fill-static-text.mjs writes.
//
// This check is what turns that one-off script into a gate: it can be run once,
// and the build then refuses to let the drift come back the next time someone
// edits i18n.js and forgets the HTML.
for (const match of indexHtml.matchAll(/<(?:span|p|h1|h2|h3|a|button|summary|li|div)[^>]*\bdata-i18n="([\w.]+)"[^>]*>\s*</g)) {
  fail("chữ rỗng", "public/index.html", `data-i18n="${match[1]}" không có chữ trong HTML — chạy npm run i18n:fill`);
}

const reachable = new Set();
for (const name of htmlFiles) {
  const source = await read(path.join("public", name));
  for (const match of source.matchAll(/href="\/([^"#?]*)/g)) {
    const target = match[1].replace(/\/$/, "");
    if (target) reachable.add(target.endsWith(".html") ? target : `${target}.html`);
  }
}
// Every page links to every other page through the footer, and the footer is
// rendered by src/pages.js rather than written into any file — so a page that is
// only reachable from the footer reads as an orphan here. That is the check
// reporting its own blind spot, not a page nobody links to, and it fires the first
// time the navigation is moved rather than every time a link is dropped.
for (const block of chromeLinkLists(pagesSource)) {
  for (const match of block.matchAll(/href:\s*"\/([^"#?]*)"/g)) {
    const target = match[1].replace(/\/$/, "");
    if (target) reachable.add(target.endsWith(".html") ? target : `${target}.html`);
  }
}
for (const name of htmlFiles) {
  if (name === "index.html" || entryPages.has(name)) continue;
  if (!reachable.has(name)) fail("trang mồ côi", `public/${name}`, `/${name.replace(/\.html$/, "")} không có trang nào trỏ tới`);
}

// ---------------------------------------------------------------------------
// 7. Two scripts on one page declaring the same top-level name.
//    A classic <script> with `let x` or `const x` puts x in the global lexical
//    scope, so a second script declaring x is a SyntaxError and that script never
//    runs at all. order.js and i18n.js both declared `current`, which left the
//    order page blank: it renders an empty shell with no error on screen, and it
//    is the page a buyer reaches after paying and losing their session. Both
//    files passed their own syntax check and their own tests, because each was
//    valid on its own — only loading them together breaks.
// ---------------------------------------------------------------------------
const declarationsOf = (source) => {
  const names = [];
  for (const match of source.matchAll(/^(?:let|const)\s+([^=;]+)=/gm)) {
    // One statement can declare several names; only the leading ones matter,
    // since the rest need their own destructuring pass.
    for (const part of match[1].split(",")) {
      const name = part.trim().split(/[\s=:[({]/)[0];
      if (name && /^[A-Za-z_$][\w$]*$/.test(name)) names.push(name);
    }
  }
  return names;
};
for (const name of htmlFiles) {
  const html = await read(path.join("public", name));
  const scripts = [...html.matchAll(/<script[^>]+src="([^"]+\.js)"/g)].map((m) => m[1].replace(/^\.?\//, ""));
  const owners = new Map();
  for (const script of scripts) {
    const file = path.join(publicDir, script);
    if (!existsSync(file)) continue;
    for (const declared of declarationsOf(await read(path.join("public", script)))) {
      if (!owners.has(declared)) owners.set(declared, []);
      owners.get(declared).push(script);
    }
  }
  for (const [declared, files] of owners) {
    if (files.length > 1) {
      fail("trùng tên toàn cục", `public/${name}`, `"${declared}" được khai báo ở cả ${files.join(" và ")} — trang sẽ không chạy`);
    }
  }
}

// ---------------------------------------------------------------------------
// Every family of defect this file knows how to catch.
//
// The number used to be a literal — 17 — sitting under a comment that listed 19, so
// the one figure a reader was meant to sanity-check had already drifted from the
// list above it. That is the exact failure the file exists to prevent, committed by
// the file itself, and no gate could see it: a test asserting "groups === 17" would
// have kept passing while the list said 19.
//
// So the count is derived from the check labels the code actually registered. A new
// family cannot be added without the number moving, the number cannot be wrong, and
// the comment below stays a readable index rather than the source of truth.
//
//  1 link or asset with no file behind it
//  2 the same route registered twice
//  3 an i18n key in one language and missing in the other
//  3b an i18n key no page and no server module can reach
//  3c the same key written twice in one dictionary
//  4 a configured value also written into a file
//  4b the site's own host in deploy/ or scripts/
//  4bb the R2 bucket's origin list against APP_URL
//  4c display content sent in one language
//  4d the same identity declared twice on one page
//  4e a language switch the page cannot honour
//  4f a template placeholder nothing knows how to fill
//  5 structured data pointing at a page robots.txt forbids
//  5b Vietnamese written without its diacritics, in the storefront, in src/ and in
//     the operator-facing text of scripts/ and test/
//  5c a template token the renderer never fills
//  5d a template the renderer never sees, token or not
//  5e an hreflang pointing at a URL nothing answers
//  5f a hardcoded brand wordmark in HTML the server renders
//  6 a page nothing links to
//  7 a phrase from the fallback dictionary inside the dictionary itself
//  8 the same global declared by two scripts on one page
const REGISTERED = new Set(findings.map((item) => item.check));
// Families that ran and found nothing leave no trace in `findings`, so the labels
// they use have to be declared here. Adding a check without adding its label is
// still possible, and the audit.test.js test below is what holds this honest.
// Every label fail() can be called with. It is checked against the labels the
// run actually used, because a mismatch makes the audit report the wrong reason
// for a real finding: "check not declared in the list at the end of the file"
// tells whoever is looking that the gate itself is broken, which is both true
// and useless.
//
// It had drifted in six places, and in four of them only by a diacritic —
// "khoá" at the call site against "khóa" in this list, the same word written two
// ways. Nothing failed while that was true, because REGISTERED is built from the
// findings and a clean run produces none, so `unknown` is empty and the check
// passes. It would only have spoken up at the exact moment it was needed: the
// first real orphaned translation key, reported as a problem with the audit
// instead of with the dictionary.
//
// The labels below are the call sites' spelling, character for character.
const DECLARED = [
  "link gãy", "route trùng", "thiếu bản dịch", "khoá i18n mồ côi", "khoá i18n chưa định nghĩa",
  "khoá i18n trùng", "nút đổi ngữ không có từ điển", "dịch thiếu", "dịch lệch",
  "domain gõ tay", "email gõ tay", "R2 CORS lệch", "R2 CORS thừa origin", "biến CSS chưa khai báo",
  "nút đổi ngữ lặp hoặc thiếu", "trang chủ mất từ điển",
  "thương hiệu khai báo hai lần", "placeholder lạ",
  "schema chặn", "tiếng Việt không dấu", "tiếng Việt ở phía máy chủ", "token chưa nối",
  "trang chưa render", "hreflang chết", "thương hiệu gõ cứng", "trang mồ côi",
  "trùng tên toàn cục", "chữ rỗng", "thiếu khai báo @font-face", "font thương hiệu từ bên ngoài",
  "lỗi tiếng Việt cho trình duyệt", "ngôn ngữ khai báo sai",
  // A file the scan listed and could not open. This one was missing while it was
  // already being produced, which is the shape of rot the reverse guard below
  // exists to catch: a check can be live and still not be counted.
  "không đọc được file",
];
// The reverse direction, which is the one that actually rots.
//
// A label with no call site is a check that was deleted from the code and left in
// the list. It counts towards the total this script reports, so `[audit] 29 nhom
// kiem tra` was claiming two families of checking that no longer exist — and a
// number that overstates coverage is worse than no number, because it is what a
// reader trusts. Two were here: "ngôn ngữ thiếu" and "thừa ngôn ngữ", both left
// behind when the language comparison was rewritten.
//
// Read from the source rather than from REGISTERED, because REGISTERED is built
// from `findings` and a clean run produces none — checking it against that would
// report every label as unused on every green run, which is a check nobody keeps.
const callSiteLabels = new Set([...readFileSync(new URL(import.meta.url), "utf8").matchAll(/fail\(\s*"([^"]+)"/g)].map((m) => m[1]));
const unusedLabels = DECLARED.filter((label) => !callSiteLabels.has(label));
if (unusedLabels.length) {
  console.error(`[audit] Nhóm kiểm tra khai báo nhưng không có call site nào: ${unusedLabels.join(", ")}`);
  process.exitCode = 1;
}
const unknown = [...REGISTERED].filter((label) => !DECLARED.includes(label));
if (unknown.length) {
  console.error(`[audit] Nhóm kiểm tra chưa khai báo trong danh sách cuối file: ${unknown.join(", ")}`);
  process.exitCode = 1;
}
const groups = new Set([...DECLARED, ...REGISTERED]).size;
// Recorded as a finding rather than thrown: a file that was listed and then
// could not be opened is a file this run could not check, and saying so is the
// only honest verdict. Exit status follows, because a gate that quietly checked
// less than it claims is the failure mode this replaces.
for (const relative of unreadable) {
  fail("không đọc được file", relative, "có trong danh sách quét nhưng không mở được — lần chạy này không kiểm tra được file này");
}
for (const item of findings) console.error(`FAIL  ${item.check.padEnd(18)} ${item.file}: ${item.detail}`);
console.log(`\n[audit] ${groups} nhóm kiểm tra, ${findings.length} vấn đề.`);
if (skipped.length) {
  console.log(`[audit] Bỏ qua ${skipped.length} nhóm vì thiếu cấu hình: ${skipped.join(", ")}`);
  console.log("[audit] Dat APP_URL va SUPPORT_EMAIL (xem .env.example) de chay day du.");
}
if (!findings.length) console.log("[audit] PASS: không có domain gõ tay, route trùng, link gãy, tiếng Việt mất dấu hay khoá i18n mồ côi.");
else process.exitCode = 1;
