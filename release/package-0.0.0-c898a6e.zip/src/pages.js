import { readdirSync, readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

// AI summaries are generated offline, reviewed, and shipped as content. They live
// in src/ (not data/) because the deploy artifact copies src/ but deliberately
// excludes runtime state in data/.
const AI_SUMMARIES = JSON.parse(
  readFileSync(new URL("./ai-summaries.json", import.meta.url), "utf8"),
);
import { env } from "./config.js";
import { isSellable } from "./store.js";
import { esc, money, formatBytes, initials } from "./format.js";
import { commitHash } from "./lib/git.mjs";
import { assetUrl } from "./lib/assets.mjs";
import { CATEGORY_EN, normaliseCategory } from "./lib/categories.mjs";
import { inlineStyles } from "./lib/inline-styles.mjs";
import { loadBlogPosts, getBlogPostBySlug, renderBlogPost, renderBlogIndex, renderBlogFeed } from "./blog.js";
import { LOCALE_CODES, DEFAULT_LOCALE } from "./i18n-registry.mjs";

// The commit that produced this process.
//
// It is no longer the version a page asks the browser to fetch: that is the
// hash of the file's own bytes, written by the build and read by
// src/lib/assets.mjs, so the version changes exactly when the file changes.
// What is left here is the process-level fallback — a single value for this
// run, so two pages rendered by the same process never disagree — and the
// value of the {{cssVersion}} token.
const cssVersion = commitHash().slice(0, 8);

// Product pages are rendered on the server here, not in the browser. The
// storefront sends an empty skeleton and fills it in with JavaScript. That is
// fine for a person, but leaves a search engine with a page of empty headings
// and no products, and it leaves link-preview crawlers (those used by Facebook,
// Zalo and Telegram when a URL is shared) with nothing at all.
//
// Everything a crawler needs has to be in the bytes the server sends.
//
// esc and money live in format.js, shared with the mail templates. They were
// written out here and in notify.js, identical to the character, and the two
// appear in the same sentence: the page a crawler reads and the email a buyer
// reads. Two copies of an escape function do not have to be wrong today to
// disagree tomorrow.

const site = () => env.appUrl.replace(/\/$/, "");

const absolute = (path) => `${site()}${path.startsWith("/") ? path : `/${path}`}`;

export { absolute };


/**
 * Fills the placeholders a product's copy is allowed to contain.
 *
 * `{{founder}}` is the owner's name, and it was typed by hand into the description
 * of a real product — as "Vũng Trọng Sơn" where the owner is "Vũ Trung Sơn". The
 * mistake lived in the database, appeared on the storefront in both languages, and
 * nothing could catch it: the name was correct in every other place on the site,
 * because everywhere else it came from BRAND_FOUNDER_NAME.
 *
 * So a product description no longer carries the name. It carries the placeholder,
 * and the one place that decides what it means is the same environment variable the
 * terms, the schema and the about page already read. Changing the name in one place
 * changes it everywhere, and a misspelling becomes impossible rather than
 * detectable.
 *
 * Called on the way out rather than on the way in, deliberately: the stored value
 * stays a placeholder, so the admin panel shows the author what is actually
 * happening instead of baking one spelling of the name into a text field where the
 * next person to save it would silently freeze a new one.
 *
 * The name is escaped for HTML because it lands inside page markup and inside
 * structured data, and it comes from configuration like anything else.
 */
export const fillCopy = (value) => {
  const text = String(value ?? "");
  if (!text.includes("{{")) return text;
  const founder = env.brand.founderName || env.brand.name;
  return text
    .replaceAll("{{founder}}", esc(founder))
    // An unknown placeholder is left alone and reported by the audit rather than
    // silently blanked, so a typo shows up as {{typo}} in the page instead of a
    // sentence with a hole in it.
    .replaceAll("{{brand}}", esc(env.brand.name));
};

/**
 * A short, honest summary for search results and link previews. The full
 * description can run to several thousand characters, and both Google and
 * Facebook truncate well before that, so a truncated wall of text buys nothing.
 */
export function productSummary(product, max = 155) {
  // The camelCase field is the one localize() has already picked for this
  // language and stripped of prices; the snake_case field is the raw database
  // row. Preferring the raw row put Vietnamese text in English metadata and
  // reintroduced prices the render path had just removed.
  //
  // For machine-readable outputs (/llms.txt, /feed.json) we prefer the English
  // copy when it exists, because those endpoints are read by search engines and
  // assistants that do not negotiate a language. A Vietnamese summary there is
  // not a fallback — it is the only text the crawler sees.
  const source = fillCopy(product.shortDescriptionEn || product.shortDescription || product.short_description || product.description || "").replace(/\s+/g, " ").trim();
  if (source.length <= max) return source;
  const cut = source.slice(0, max);
  return `${cut.slice(0, cut.lastIndexOf(" "))}…`;
}

/**
 * Tokens that make a string unusable as product data.
 *
 * Google's product data specification forbids price, discount and urgency in the
 * title, and Merchant Center reads the landing page title whenever the page does
 * not carry a Product node. This catalogue's copy was written for a sale, so the
 * title read "RAMCleaner Early Bird - 199k VND (33% off) First 100 Customers
 * Only" — three violations in one line, and the reason the feed item was built
 * from it instead of from the catalogue.
 *
 * The check is deliberately all-or-nothing. Editing a promotional sentence token
 * by token leaves the grammar behind ("all features for instead of ."), and a
 * half-rewritten title is worse data than a clean one derived from the product's
 * own name. So a string that trips this is discarded, not repaired.
 */
export const PROMO_IN_TEXT = new RegExp(
  `(?<![\\p{L}\\p{N}_])(?:${[
    String.raw`\d[\d.,]*\s*k?\s*(?:₫|đ|vnd|usd|eur|gbp)`,
    String.raw`[$€£]\s?\d`,
    String.raw`\d{1,3}\s*%`,
    String.raw`(?:first|only|last)\s+\d+\s+(?:customers?|copies|orders?|slots?|units?)`,
    String.raw`\d+\s+(?:copies|gói|khách)`,
    String.raw`chỉ\s+\d+\s+(?:gói|bản|khách|suất)`,
    String.raw`giảm\s+\d`,
    // Vietnamese sale wording that carries no number: "mua sớm", "khóa giá",
    // "ưu đãi". The bare word "giá" is deliberately not matched on its own,
    // because "đánh giá" (review) is a legitimate word and would be dropped
    // with it. A "giá" followed by a sale qualifier is still promotional.
    String.raw`(?:mua sớm|mua ngay|đặt ngay|khóa giá|giữ giá|ưu đãi|khuyến m[ãa]i|giảm giá|hết là hết)`,
    String.raw`giá\s+(?:chỉ|sẽ|gốc|tiêu chuẩn|niêm yết|ưu đãi|rẻ)`,
    String.raw`(?:early bird deal|limited time|while supplies last|act now|hurry|order now|buy now|special offer|discount|on sale|lock in)`,
    String.raw`prices?`,
  ].join("|")})(?![\\p{L}\\p{N}_])`,
  "iu"
);

/**
 * The owner's SEO copy when it is safe to publish, otherwise an empty string.
 *
 * Returning "" rather than a repaired string is what lets every caller fall back
 * to a title built from the product's own name, which is the only value that is
 * guaranteed to be free of the promotion the owner was running that week.
 */
const cleanSeoText = (value) => {
  const text = fillCopy(String(value ?? "")).trim();
  return text && !PROMO_IN_TEXT.test(text) ? text : "";
};

const truncateAtWord = (text, max) => (text.length <= max ? text : `${text.slice(0, text.lastIndexOf(" ") || max)}…`);

/**
 * A last-resort description built only from facts the catalogue always carries.
 *
 * Reached when the owner's copy is entirely promotional or in the wrong
 * language. It describes the product and the platforms it runs on without
 * mentioning a price, a discount or a deadline — the three things Google's
 * product data specification forbids in this field.
 */
const derivedDescription = (product, max = 0) => {
  const name = fillCopy(String(product.name || "").trim());
  const platform = fillCopy(String(product.platform || "Windows").trim());
  const line = `${name} for ${platform} — software from ${env.brand.name}`;
  return max ? truncateAtWord(line, max) : line;
};

/**
 * The first sentence of the full description that says something factual.
 *
 * A short description can be nothing but a sale notice ("Early bird deal for the
 * first 100 customers"), and using it as the meta description means the one
 * sentence Google has to judge the page by describes a discount rather than a
 * product. The full description usually still carries a real sentence, so the
 * promotional one is skipped instead of being rewritten — the same rule the
 * title follows.
 *
 * English pages never borrow Vietnamese prose here: a meta description in the
 * wrong language is worse than a derived one, and the caller has a fallback.
 */
const firstCleanSentence = (product, lang, max) => {
  const raw = String(product.description || "").replace(/\s+/g, " ").trim();
  if (!raw) return "";
  if (lang !== "vi" && VIETNAMESE_RE.test(raw)) return "";
  const sentence = raw.split(/(?<=[.!?])\s+/).find((item) => item.length >= 20 && !PROMO_IN_TEXT.test(item));
  return sentence ? truncateAtWord(sentence, max) : "";
};

/**
 * The description a search engine and a link preview are shown.
 *
 * Distinct from productSummary on purpose. productSummary describes the product for a
 * reader who is already on the page, so falling back to the Vietnamese copy when the
 * English copy is missing is the better of two imperfect options. A meta description
 * is not read on the page — it is read by someone who searched in English and is
 * deciding whether to click. Serving them a Vietnamese sentence there puts the wrong
 * text in the result and reads as two pages competing for the same query, which is
 * what hreflang exists to prevent.
 *
 * So: the owner's own SEO copy when it exists and carries no promotion, then the
 * product's own prose, then a language-neutral line built from the product name and
 * platform. A weak description is recoverable; a description in the wrong language
 * is worse than none.
 *
 * @param {object} product already passed through localisedProduct
 * @param {string} lang "en" or anything else for Vietnamese
 * @returns {string}
 */
const metaDescriptionFor = (product, lang = "vi", max = 155) => {
  const own = cleanSeoText(product.seoDescription);
  if (own) return truncateAtWord(own, max);

  // The short description is the preferred summary, but only when it describes
  // the product in the language the page declares. A promotional summary is
  // skipped rather than rewritten; the full description is asked for one clean
  // sentence next.
  const summary = productSummary(product, max);
  const usable = summary && !PROMO_IN_TEXT.test(summary) && (lang === "vi" || !VIETNAMESE_RE.test(summary));
  if (usable) return summary;

  const clean = firstCleanSentence(product, lang, max);
  if (clean) return clean;

  // Every sentence was promotional or in the wrong language. The derived line
  // still says what the product is, and it says nothing about its price.
  return derivedDescription(product, max);
};

/**
 * The one logo URL the whole site publishes as the brand's logo.
 *
 * It was previously /favicon.svg, which is the right answer for a browser tab and
 * the wrong answer for structured data: Google asks for a logo of at least 112x112
 * and reads Organization.logo as an image to render in a knowledge panel. A 64x64
 * favicon is under that, so the field was technically present and practically
 * unusable. /logo-1024.png is the source mark at full size, generated by
 * scripts/make-logo-assets.mjs, and it is a real file rather than a path that was
 * only ever named in a comment.
 *
 * The tab icon is a different question with a different answer, and stays
 * /favicon.svg: 64px is all a tab can show, and SVG is sharper there.
 */
export const LOGO_PATH = "/logo-1024.png";

const PUBLIC_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "public");

// ---------------------------------------------------------------------------
// Locale registry for the product page.
//
// Vietnamese is the catalogue's source language; every other supported locale
// gets a real server-rendered page at /<lang>/product/<slug>. The per-locale
// asset (public/locales/<lang>.json, the same one the browser fetches) carries
// the translated product copy as `product.copy.<slug>.<field>` and the
// translated category/badge labels as `product.label.<kind>.<key>`. Reading it
// at render time keeps one source of truth for those translations: editing the
// asset fixes the homepage cards, the 404 list and the product page together.
// A missing or unreadable asset is not fatal: the page degrades to the English
// copy, never to a blank or a crash.
// ---------------------------------------------------------------------------
const OG_LOCALE = { vi: "vi_VN", en: "en_US", de: "de_DE", es: "es_ES", fr: "fr_FR", ja: "ja_JP", "zh-CN": "zh_CN" };
const SCHEMA_LANG = { vi: "vi-VN", en: "en", de: "de", es: "es", fr: "fr", ja: "ja", "zh-CN": "zh-CN" };
const localePrefix = (lang) => (!lang || lang === "vi" ? "" : `/${lang}`);
// Mirrors public/i18n.js labelSlug() so the server derives the same dictionary
// keys ("Phát hành 1.5.0" -> "phat-hanh-1.5.0") without importing browser code.
const labelSlug = (value) => String(value || "")
  .toLowerCase()
  .normalize("NFD")
  .replace(/[\u0300-\u036f]/g, "")
  .replace(/đ/g, "d")
  .trim()
  .replace(/[^a-z0-9.]+/g, "-")
  .replace(/^-+|-+$/g, "");
// Letters that exist only in Vietnamese among this site's languages (plus the
// U+1EA0-U+1EF9 block, all Vietnamese vowels with tone). French, German,
// Spanish, Japanese and Chinese never carry these, so a line containing one is
// never mistaken for an Italian/French sentence.
const VIETNAMESE_RE = /[ăĂơƠưƯĐđẠ-ỹ]/;
const localeJsonCache = new Map();
const loadLocaleJson = (lang) => {
  if (!lang || lang === "vi") return null; // vi is the source language; the templates carry it already
  if (localeJsonCache.has(lang)) return localeJsonCache.get(lang);
  try {
    // en.json is generated from public/i18n.js's bundled DICT (see
    // scripts/lib/i18n-bundled.mjs and test/locale-en.test.js); it exists so the
    // server can render the same English words the browser would, from the
    // same source, without a network fetch or a vm at request time.
    const parsed = JSON.parse(readFileSync(path.join(PUBLIC_DIR, "locales", `${lang}.json`), "utf8"));
    localeJsonCache.set(lang, parsed);
    return parsed;
  } catch (error) {
    console.error(`[i18n] locales/${lang}.json unavailable, English fallback:`, error.message);
    localeJsonCache.set(lang, null);
    return null;
  }
};
// The catalogue's free-text category/badge columns, translated through the
// locale asset. Returns a vi->localised map for exactly the values this shop
// uses; an unknown value falls back to the English label, then to the raw text.
const overlayLabels = (json, kind, viTable) => {
  const enTable = COPY_EN[kind === "category" ? "categories" : "badges"];
  const out = {};
  for (const vi of Object.keys(viTable)) {
    const hit = json ? json[`product.label.${kind}.${labelSlug(vi)}`] : undefined;
    out[vi] = (typeof hit === "string" && hit) || enTable[vi] || vi;
  }
  return out;
};

/**
 * The per-product covers scripts/make-product-images.mjs writes, read once.
 *
 * Read once rather than per request: the directory only changes when the
 * generator runs, and a product page should not pay a stat call per render. A
 * missing directory is a valid state — a checkout without the assets still
 * serves pages — so it becomes an empty set rather than an error.
 */
let coverCache = null;
const productCovers = () => {
  if (coverCache) return coverCache;
  try {
    coverCache = new Set(readdirSync(path.join(PUBLIC_DIR, "og")).filter((file) => file.endsWith(".png")));
  } catch {
    coverCache = new Set();
  }
  return coverCache;
};

/**
 * The image a crawler is given for this product.
 *
 * A catalogue-wide logo is the same image for every item, and Merchant Center
 * reads that as "the image does not show the product". The generated cover per
 * slug is distinct, carries no price or promotion, and is 1200x630, so it also
 * satisfies the share-card dimensions. `imageUrl` wins over both: an owner who
 * uploads a real screenshot should never have to edit code for it.
 */
const productImage = (product) => {
  const explicit = String(product.imageUrl || product.image_url || "").trim();
  if (explicit) return /^https?:\/\//i.test(explicit) ? explicit : absolute(explicit);
  const slug = String(product.slug || "").trim();
  if (slug && productCovers().has(`${slug}.png`)) return absolute(`/og/${slug}.png`);
  return absolute(LOGO_PATH);
};

/**
 * The icon slots, declared once because every page has to link the same set.
 *
 * Each entry is one place a logo can be shown by something other than this site:
 * a browser tab, an iOS home screen, a Windows taskbar, an installed PWA, a Safari
 * pinned tab. They were all missing except the tab. A page that declares only
 * favicon.svg is not a page with a favicon — it is a page with a favicon and no
 * iOS icon, which is invisible until someone installs the shop and sees a blank
 * square with no way to tell what it is.
 *
 * `sizes` is what the browser uses to pick; it must be present and correct on each
 * entry, or Chrome logs a warning and guesses.
 */
export const ICON_LINKS = [
  { rel: 'icon', href: '/favicon.ico', sizes: 'any' },
  { rel: 'icon', href: '/favicon.svg', type: 'image/svg+xml' },
  { rel: 'icon', href: '/icon-16.png', type: 'image/png', sizes: '16x16' },
  { rel: 'icon', href: '/icon-32.png', type: 'image/png', sizes: '32x32' },
  { rel: 'icon', href: '/icon-192.png', type: 'image/png', sizes: '192x192' },
  { rel: 'icon', href: '/icon-512.png', type: 'image/png', sizes: '512x512' },
  { rel: 'apple-touch-icon', href: '/apple-touch-icon.png', sizes: '180x180' },
  { rel: 'mask-icon', href: '/mask-icon.png', color: '#0f2a22' },
  // The manifest registration is deliberately NOT here: a <link rel="manifest"> in
  // the head is discovered while the HTML is parsed, and quality.js appends it after
  // load so it is not the page's own critical request. iconLinkMarkup() does emit a
  // <link rel="preload" as="manifest"> hint so the fetch runs in parallel with the
  // HTML rather than chaining after quality.js — see the note there.
];

/** The <link> lines for every icon slot, one per line, ready to drop into a <head>. */
export const iconLinkMarkup = () => {
  const lines = ICON_LINKS.map((link) => {
    const attrs = [`rel="${link.rel}"`, `href="${link.href}"`];
    if (link.type) attrs.push(`type="${link.type}"`);
    if (link.sizes) attrs.push(`sizes="${link.sizes}"`);
    if (link.color) attrs.push(`color="${link.color}"`);
    return `<link ${attrs.join(' ')}>`;
  });
  // No manifest link and no manifest preload here.
  //
  // `as="manifest"` is not a valid preload destination — the preload list is
  // audio, document, embed, fetch, font, image, object, script, style, track,
  // video, worker — so Chrome reports a warning against that exact <link> and
  // ignores it. The bytes are fetched anyway when quality.js appends the real
  // <link rel="manifest">, which is the only registration. A <link rel="manifest">
  // in the head would put the fetch on the critical tree (Lighthouse "Network
  // dependency tree": 781 ms for a 1 KiB file), and the preload that was tried
  // instead did not remove anything because browsers rejected it.
  return lines;
};

/**
 * The raster card for link previews.
 *
 * The per-product SVG at /og/:slug.svg is still generated, because some
 * crawlers render it. It is not what og:image points at, because Facebook, Zalo,
 * Telegram, Slack, LinkedIn and most AI answer engines refuse SVG outright and
 * show an empty box instead. This PNG is generated once by
 * scripts/make-og-image.mjs and committed, so neither the build nor the server
 * needs an image library to produce a shareable card.
 */
const OG_IMAGE_PATH = "/og.png";

/**
 * Every page og:image, og:image:width and og:image:height have to agree, so the
 * numbers live here rather than being repeated in each meta block.
 */
const OG_IMAGE = { path: OG_IMAGE_PATH, width: 1200, height: 630 };

// brand, organization, brandWordmark and legalEntityLine were all exported. None of
// them has an importer anywhere in src/, scripts/ or test/ — each is used only by
// this module — and an export with no reader is an API nobody agreed to. They stay
// here as functions, which is what they always were; the export was the orphan.
const brand = () => env.brand.name;

const organization = () => {
  const phone = String(env.brand.phone || '').trim();
  const address = String(env.brand.address || '').trim();
  const email = String(env.email.supportEmail || '').trim();
  return {
    "@type": "Organization",
    "@id": `${site()}/#organization`,
    name: brand(),
    url: `${site()}/`,
    logo: absolute(LOGO_PATH),
    description: env.brand.description,
    // Emit only owner-verified/configured contact details. Hardcoding or
    // fabricating address/phone in templates/schema increases Merchant Center
    // misrepresentation risk; missing optional fields are safer than wrong ones.
    ...(phone ? { telephone: phone } : {}),
    ...(email ? { contactPoint: [{ "@type": "ContactPoint", contactType: "customer support", email }] } : {}),
    ...(address ? { address: { "@type": "PostalAddress", streetAddress: address } } : {}),
    ...(env.brand.socialLinks.length ? { sameAs: env.brand.socialLinks } : {}),
    // A named person behind the shop. Anonymous storefronts get cited far less
    // readily than a place with a human attached to it.
    ...(env.brand.founderName ? {
      founder: {
        "@type": "Person",
        name: env.brand.founderName,
        ...(env.brand.founderUrl ? { url: env.brand.founderUrl } : {}),
      },
    } : {}),
  };
};

/**
 * SoftwareApplication is the schema.org type that matches a downloadable tool.
 * Product plus an Offer would also be valid, but SoftwareApplication carries
 * operatingSystem and applicationCategory, which is what makes it eligible for
 * the software rich result.
 *
 * The fields past the ones a search result shows are what a model needs to say
 * something specific rather than something generic: which platforms it runs on,
 * what it needs to run at all, and where the file actually is.
 */
/**
 * The verification block: the links a claim rests on, and nothing else.
 *
 * Three things this deliberately does not do. It never asserts the software is
 * safe, because a page asserting that is worth nothing next to a scan a reader can
 * open. It does not show the build report as though it described the download — the
 * report covers this storefront's own server code, and passing it off as product
 * verification is the same overclaiming the product copy was already corrected
 * for. And it never renders a row for evidence that is missing: a "verified" link
 * with no href behind it is worse than no row, because it looks like a pass.
 */
const trustBlock = (product, copy) => {
  const scan = String(product.virusScanUrl || "").trim();
  if (!scan) return "";
  const rows = [`<li><a href="${esc(scan)}" rel="nofollow noopener" target="_blank">${esc(copy.trustScan)}</a><small>${esc(copy.trustScanNote)}</small></li>`];
  rows.push(`<li><a href="/build-report.json">${esc(copy.trustBuild)}</a><small>${esc(copy.trustBuildNote)}</small></li>`);
  return `<section class="detail-block trust"><h2>${esc(copy.trustHeading)}</h2><ul class="trust-list">${rows.join("")}</ul></section>`;
};

// The AI summary. One column, full width, with a disclaimer that names the
// limitation. The text comes from src/ai-summaries.json — offline-generated and
// reviewed — not from a live model call, so the page has no API dependency and
// no per-request cost.
const aiSummaryBlock = (product, lang, copy) => {
  const entry = AI_SUMMARIES[product.slug];
  const text = entry?.[lang === "vi" ? "vi" : "en"] || entry?.vi || entry?.en;
  if (!text) return "";
  return `<section class="detail-block ai-summary" aria-labelledby="ai-summary-title">
    <div class="ai-summary-head"><h2 id="ai-summary-title">${esc(copy.aiSummary)}</h2><span class="ai-badge">${esc(copy.aiGenerated || "AI")}</span></div>
    <p>${esc(text)}</p>
    <p class="ai-disclaimer">${esc(copy.aiDisclaimer)}</p>
  </section>`;
};

const productSchema = (product, lang = "vi") => ({
  "@type": "SoftwareApplication",
  "@id": absolute(productUrl(product.slug, lang)) + "#software",
  name: `${product.name} ${product.version ? `v${product.version}` : ""}`.trim(),
  // altText and the description both take the search phrasing, so the product
  // is findable by the problem it solves and not only by its product name.
  description: metaDescriptionFor(product, lang),
  alternateName: cleanSeoText(product.seoTitle) || undefined,
  url: absolute(productUrl(product.slug, lang)),
  inLanguage: SCHEMA_LANG[lang] || "en",
  applicationCategory: product.category || "UtilitiesApplication",
  operatingSystem: product.platform || "Windows",
  softwareVersion: product.version || undefined,
  // A requirements field in the data is the closest thing to a spec sheet, and
  // it is the field an assistant quotes when asked whether something will run.
  softwareRequirements: product.requirements || undefined,
  downloadUrl: absolute(productUrl(product.slug, lang)),
  installUrl: absolute(productUrl(product.slug, lang)),
  image: productImage(product),
  brand: { "@type": "Brand", name: brand() },
  ...(env.brand.socialLinks.length ? { sameAs: env.brand.socialLinks } : {}),
  author: { "@id": `${site()}/#organization` },
  publisher: { "@id": `${site()}/#organization` },
  // No offers here: the Product node carries the single Offer. Two Offer objects
  // for one product made Merchant Center report the merchant fields as missing on
  // the app node even though the page published them.
});

/**
 * The node Merchant Center reads.
 *
 * SoftwareApplication is the right type for an app rich result and the wrong type
 * for a product feed: Google's merchant listing markup expects Product with an
 * Offer, and a page that ships only SoftwareApplication is a page Merchant Center
 * has to guess at. That guess is what produced a feed item titled
 * "RAMCleaner Early Bird - 199k VND (33% off) First 100 Customers Only": with no
 * Product to read, Google fell back to <title> and the meta description.
 *
 * Both nodes are emitted. They describe the same URL, they do not contradict each
 * other, and each is read by a different Google surface — the app result reads
 * SoftwareApplication, the shopping surface reads Product.
 *
 * `price` is the shelf price in the product's own currency, which is also the
 * number printed on the page. It is never the converted figure: a price that
 * moves with the exchange rate is a price Google cannot match on the next crawl.
 */
// Shared return/shipping policy nodes for the merchant listing graph.
 //
 // Google Search Console flags an Offer whose MerchantReturnPolicy omits
 // `applicableCountry`/`returnMethod`, and an Offer that omits `shippingDetails`.
 // The published policy at /refund is a 14-day, free-return policy under
 // Vietnamese jurisdiction, so those are the values a crawler is given. Digital
 // delivery has no carrier and no shipping cost, so the shipping rate is zero.
const merchantReturnPolicy = () => {
    const policy = {
      "@type": "MerchantReturnPolicy",
      applicableCountry: ["VN"],
      returnPolicyCategory: "https://schema.org/MerchantReturnFiniteReturnWindow",
      merchantReturnDays: 14,
      returnFees: "https://schema.org/FreeReturn",
      // Google supports only ReturnAtKiosk, ReturnByMail and ReturnInStore here.
      // ReturnDownload is a real schema.org term but is NOT a supported value —
      // emitting it made Merchant Center report "'returnMethod' không hợp lệ"
      // on 7 items and blocked rich-result validation. The remote return of a
      // downloaded file is expressed with the supported remote method.
      returnMethod: "https://schema.org/ReturnByMail",
    };
    return policy;
  };

 const digitalShippingDetails = (isDigital = true, currency = "VND") => {
   // All products are digital downloads. Merchant Center flags an Offer whose
   // shippingDetails has no deliveryTime; an instant digital delivery is honestly
   // zero handling and zero transit.
   const unitCode = "DAY";
   const handlingTime = { "@type": "QuantitativeValue", minValue: 0, maxValue: 0, unitCode };
   const transitTime = { "@type": "QuantitativeValue", minValue: 0, maxValue: 0, unitCode };
   return {
     "@type": "OfferShippingDetails",
     shippingRate: { "@type": "MonetaryAmount", value: 0, currency: String(currency || "VND").toUpperCase() },
     shippingDestination: [{ "@type": "DefinedRegion", addressCountry: "VN" }],
     deliveryTime: {
       "@type": "ShippingDeliveryTime",
       handlingTime,
       transitTime,
     },
   };
 };

// One Offer node, used by the Product node; SoftwareApplication deliberately
// carries no offers (see productSchema). They used to be two hand-built objects:
// the Product carried itemCondition and hasMerchantReturnPolicy, the
// SoftwareApplication carried neither — so a crawler that read the app node
// reported the merchant fields as missing even though the page published them.
// The Offer carries a Google-supported returnMethod (ReturnByMail — see
// merchantReturnPolicy); shippingDetails IS present with a zero-value digital
// deliveryTime because Merchant Center flags its absence (see digitalShippingDetails).
const productOffer = (product, lang = DEFAULT_LOCALE) => {
  const isDigital = true; // All products are digital downloads
  const shippingDetails = digitalShippingDetails(isDigital, String(product.currency || "VND").toUpperCase());
  return {
    "@type": "Offer",
    price: Number(product.price) || 0,
    priceCurrency: String(product.currency || "VND").toUpperCase(),
    availability: "https://schema.org/InStock",
    itemCondition: "https://schema.org/NewCondition",
    url: absolute(productUrl(product.slug, lang)),
    seller: { "@id": `${site()}/#organization` },
    hasMerchantReturnPolicy: merchantReturnPolicy(),
    ...(shippingDetails ? { shippingDetails } : {}),
  };
};

const merchantProductSchema = (product, lang = "vi") => {
  const url = absolute(productUrl(product.slug, lang));
  // Google's description attribute is a product description, not a sale notice.
  // Sentences that only exist to run a promotion are dropped whole — a sentence
  // is the smallest unit that survives deletion with its grammar intact. If every
  // sentence was promotional, a line derived from the product's own name and
  // platforms is used instead of the raw text: an empty field is an error, but a
  // promotional one is the policy violation this code exists to remove.
  const rawDescription = String(product.description || product.shortDescription || "").replace(/\s+/g, " ").trim();
  const kept = rawDescription.split(/(?<=[.!?])\s+/).filter((sentence) => !PROMO_IN_TEXT.test(sentence)).join(" ").trim();
  const description = (kept || derivedDescription(product)).slice(0, 5000);
  return {
    "@type": "Product",
    "@id": `${url}#product`,
    name: fillCopy(String(product.name || "").trim()),
    description,
    url,
    // One image, resolved by productImage(): an uploaded screenshot first, then
    // the generated cover for this slug, then the brand mark. Google wants an
    // image of the product, not a catalogue-wide logo.
    image: [productImage(product)],
    // No GTIN is assigned to a small developer's utility, so the identifier pair
    // Google asks for instead is brand + MPN. The product id is stable and unique.
    sku: String(product.id || product.slug),
    mpn: String(product.id || product.slug),
    brand: { "@type": "Brand", name: brand() },
    category: "Software > Computer Software",
    additionalType: "https://schema.org/SoftwareApplication",
    itemCondition: "https://schema.org/NewCondition",
    offers: productOffer(product, lang),
  };
};

// A secondary TechArticle node. Google's AI/answer surfaces read article-like
// content; the Product node is the commercial source of truth, and this node
// gives the same page an article shape without changing the product data.
const techArticleSchema = (product, lang = "vi") => {
  const url = absolute(productUrl(product.slug, lang));
  const headline = String(product.name || "").trim();
  const description = String(product.shortDescription || product.description || "").replace(/\s+/g, " ").trim();
  return {
    "@type": "TechArticle",
    "@id": `${url}#article`,
    headline,
    ...(description ? { description: description.slice(0, 300) } : {}),
    inLanguage: lang,
    isAccessibleForFree: true,
    mainEntityOfPage: { "@id": url },
    about: { "@id": `${url}#product` },
    author: { "@id": `${site()}/#organization` },
    publisher: { "@id": `${site()}/#organization` },
    image: [productImage(product)],
    ...(product.createdAt ? { datePublished: product.createdAt } : {}),
    ...(product.updatedAt ? { dateModified: product.updatedAt } : {}),
  };
};

const breadcrumbSchema = (product, lang = "vi") => {
  const labels = (() => {
    const c = getCopy(lang);
    return { home: c.home, products: c.products, here: product.name };
  })();
  return {
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: labels.home, item: lang === "vi" ? `${site()}/` : absolute(`${localePrefix(lang)}/`) },
      { "@type": "ListItem", position: 2, name: labels.products, item: lang === "vi" ? `${site()}/#products` : absolute(`${localePrefix(lang)}/#products`) },
      { "@type": "ListItem", position: 3, name: labels.here, item: absolute(productUrl(product.slug, lang)) },
    ],
  };
};

/**
 * The four questions a buyer asks before paying, answered from what this shop
 * actually does rather than from a generic template.
 *
 * Question-and-answer prose in the exact wording someone uses is close to the
 * highest-yield thing on the page for an assistant: it is the shape of text these
 * systems quote, and it is the shape they can verify against the page itself.
 */
const faqSchema = (product, lang = "vi") => {
  const window = env.orders.paymentWindowHours;
  const entries = lang === "vi" ? [
    ["Tôi nhận hàng bằng cách nào?", "PayPal: mã tra cứu và link tải gửi qua email ngay. Chuyển khoản: gửi sau khi giao dịch được xác nhận, thường trong giờ làm việc."],
    ["Tải được mấy lần?", "Bạn tự tạo link tải mới bất cứ lúc nào bằng mã tra cứu. Link có thời hạn ngắn nhưng không giới hạn số lần tạo."],
    ["Phần mềm chạy trên nền tảng nào?", `${product.platform || "Windows"}. ${product.requirements || ""}`.trim()],
    ["Nếu file lỗi?", `Liên hệ ${env.email.supportEmail} kèm mã đơn. Chúng tôi hoàn tiền hoặc gửi lại bản sửa theo chính sách hoàn tiền.`],
    ["Tôi có bao lâu để thanh toán?", `Đơn chưa thanh toán bị hủy sau ${window} giờ, nên thanh toán trong khoảng đó là an toàn.`],
  ] : [
    ["How do I receive the file?", "PayPal: the lookup code and download link are emailed immediately. Bank transfer: sent once the transfer is confirmed, usually within business hours."],
    ["How many times can I download it?", "As many as you like. The lookup code in your email makes a fresh download link on demand; links expire quickly, the number of downloads does not."],
    ["Which platforms does it run on?", `${product.platform || "Windows"}. ${product.requirements || ""}`.trim()],
    ["What if the file is broken?", `Email ${env.email.supportEmail} with your order code and the file is replaced or refunded under the Refund Policy.`],
    ["How long do I have to pay?", `An unpaid order is cancelled after ${window} hours, so pay inside that window and nothing happens to it.`],
  ];
  return {
    "@type": "FAQPage",
    mainEntity: entries.map(([question, answer]) => ({
      "@type": "Question",
      name: question,
      acceptedAnswer: { "@type": "Answer", text: answer },
    })),
  };
};

// Google retired the sitelinks search box in November 2024, so a SearchAction
// earns nothing any more. What it used to point at was worse than useless: the
// only page this site has that takes a query string is /lookup, the order
// recovery form, which robots.txt disallows and which serves noindex. Telling a
// search engine the site's search feature is a page it must not read is a
// contradiction in the markup, so the action is gone.
const websiteSchema = () => ({
  "@type": "WebSite",
  "@id": `${site()}/#website`,
  name: brand(),
  url: `${site()}/`,
  inLanguage: "vi-VN",
  publisher: { "@id": `${site()}/#organization` },
});

/**
 * The one place a structured-data block is serialised.
 *
 * Every node gets its own `@context`. Without it the block is valid JSON and
 * invalid JSON-LD: a consumer has no vocabulary to resolve `Product` or
 * `SoftwareApplication` against, so it ignores the graph and falls back to
 * <title>, the meta description and og:image. That fallback is exactly how a
 * promotional page title ended up as a Merchant Center product title.
 *
 * The product page passes one `@graph` document, which is the shape the
 * homepage already used. That keeps the Organization and WebSite nodes
 * byte-identical on both pages — a crawler comparing them is comparing the
 * shop's identity, and two spellings of it is the drift the graph exists to
 * prevent. The array branch stays for any caller that ships loose nodes.
 */
const jsonLd = (data) => {
  const withContext = (node) => (node && typeof node === "object" && !Array.isArray(node)
    ? { "@context": "https://schema.org", ...node }
    : node);
  const payload = Array.isArray(data) ? data.map(withContext) : withContext(data);
  return `<script type="application/ld+json">${JSON.stringify(payload).replace(/</g, "\\u003c")}</script>`;
};

/**
 * Search engine ownership tokens, as meta tags.
 *
 * Google and Bing each hand out one string and offer two ways to present it: a
 * tag in the head, or a file at the site root. Both are served from the same env
 * var so whichever the dashboard offers works without touching the code.
 * Returns an empty string when nothing is configured, which is not an error:
 * a store that has not claimed the domain in Search Console still works.
 */
export const verificationMeta = () => {
  const tags = [];
  if (env.site.googleVerification) tags.push(`<meta name="google-site-verification" content="${esc(env.site.googleVerification)}">`);
  if (env.site.bingVerification) tags.push(`<meta name="msvalidate.01" content="${esc(env.site.bingVerification)}">`);
  return tags.join("\n");
};

/**
 * The brand, as a meta tag, so the browser knows it.
 *
 * It used to be a literal in the dictionary, and then it briefly became the part of
 * SUPPORT_EMAIL after the "@" — which printed the bare domain in the footer in lower
 * case, and would have printed "gmail.com" the moment the support address moved to a
 * webmail provider. Neither is the brand. The name belongs to the configuration, so
 * it is injected once here and every page reads it back, exactly the way the support
 * address already is.
 */
/**
 * The site's identity, in the form link previews read.
 *
 * Every page gets this, so the shop's name is stated once from configuration rather
 * than typed into each template's head. It used to be typed into index.html's
 * og:site_name, og:title, og:image:alt, twitter:title and twitter:description —
 * eleven literals of the same name across one file, while the product pages read
 * the same thing from env.brand.name. Change BRAND_NAME and the homepage kept
 * announcing the old shop on every share.
 *
 * Only the identity tags live here. The title and description are per page: the
 * homepage sells the shop and a product page sells one thing, and a shared tag
 * would have one of them wrong.
 */
export const brandMeta = () => [
  `<meta name="x-brand" content="${esc(env.brand.name)}">`,
  `<meta property="og:site_name" content="${esc(env.brand.name)}">`,
  `<meta property="og:brand" content="${esc(env.brand.name)}">`,
  `<meta name="twitter:site" content="${esc(env.brand.name)}">`,
].join("\n");

/**
 * Cloudflare Web Analytics, on every page.
 *
 * There was no way to answer "has anyone ever actually visited this shop?" —
 * the only orders on record were the owner's own test purchases. Cloudflare's
 * edge already fronts this site, so the beacon is first-party to the same
 * operator and the measurement costs nothing.
 *
 * The snippet is written here rather than pasted into ten templates for the
 * same reason brandMeta exists: one definition, every page gets the same tag,
 * and rotating the token is a one-line change. The automatic injection Cloudflare
 * offers for proxied zones did not fire for this zone, which is why the tag is
 * explicit.
 *
 * Two CSP entries back it (see src/app.js): the script host, and the endpoint
 * the beacon reports to. Without them the browser blocks the tag and the
 * dashboard shows a confident zero.
 */
export const analyticsMeta = () => {
  // Both third-party analytics tags used to be here: Cloudflare Web Analytics
  // and GA4. Neither is any more.
  //
  // Cloudflare's beacon was 10 KB of third-party JavaScript carrying its own
  // polyfills for Array.prototype.at/findLast/includes (Lighthouse: "Legacy
  // JavaScript") and cached for a single day ("Use efficient cache lifetimes").
  //
  // GA4's gtag.js is blocked outright by every tracker blocker and privacy
  // setting: the request failed with ERR_BLOCKED_BY_CLIENT in the visitor's
  // own network tab, on every page, for every visitor who has one. A tag that
  // fails for those visitors collects nothing for them and only produces a red
  // line in their console.
  //
  // What the shop measures instead is its own: the RUM beacon in
  // public/quality.js posts the URL, the Core Web Vitals and the page errors to
  // /api/quality — same origin, navigator.sendBeacon, so it survives the
  // visitor leaving the page and no proxy or blocker can stop it.
  //
  // Putting either one back is one tag plus one CSP entry. What it costs is
  // written down in docs/QUALITY-L4-L5-BACKLOG.md.
  return "";
};

/**
 * The wordmark every header shows, built from BRAND_NAME.
 *
 * It is generated rather than templated because of the typographic split: the last
 * segment is styled separately, so "SonVuDev" renders as SonVu|Dev with Dev in the
 * accent colour. A single {{brandName}} cannot express that, which is the whole
 * reason the name ended up typed into fourteen places — seven HTML files, twice in
 * most of them, plus the product page the server builds in code.
 *
 * Fourteen copies is fourteen chances to answer a rename with the old shop. It was
 * already true once: the product page is the surface a crawler reads most, and its
 * header announced the old brand while the title, the canonical, the structured data
 * and every email had all moved to the new one. No audit could see it, because the
 * audit counts og:site_name inside public/*.html and this markup is generated by
 * src/pages.js and never exists on disk.
 *
 * The split is read out of the name rather than configured: the last capital letter
 * that starts a word, i.e. one preceded by a lowercase letter or a digit. "SonVuDev"
 * gives SonVu|Dev, "MyStore" gives My|Store, and a single-word name gives no split at
 * all — which is the right answer rather than a failure.
 */
const brandWordmark = () => {
  const name = String(env.brand.name || "").trim();
  const mark = esc(name.slice(0, 1));
  let cut = -1;
  for (let i = name.length - 1; i > 0; i -= 1) {
    if (/[A-Z]/.test(name[i]) && /[a-z0-9]/.test(name[i - 1])) { cut = i; break; }
  }
  // The mark is the shop's own logo rather than the first letter of its name. The
  // letterform was a second, hand-drawn version of the same idea and it was the one
  // that survived: the header on all fourteen pages, the admin panel and every email
  // carried a plain S in a rounded square while the favicon, the share card and the
  // home screen icon carried the real mark. One logo, one file, everywhere.
  //
  // logo-ink rather than the source mark: the source is a flat #3f6a5c, which measures
  // 2.71:1 against the paper-white header — below the 3:1 WCAG asks of a graphic that
  // carries meaning. logo-ink is the same silhouette in --green, 3.3:1. The shape is
  // identical; only the tint differs, because a surface decides how a mark is inked.
  const logo = `<span class="brand-mark"><img src="/logo-ink-64.png" alt="" width="26" height="26" loading="eager" decoding="async"></span>`;
  if (cut < 1) return `${logo}<span>${esc(name)}</span>`;
  return `${logo}<span>${esc(name.slice(0, cut))}<span>${esc(name.slice(cut))}</span></span>`;
};

/**
 * The header bar and the footer, written once.
 *
 * Both used to be a block of markup copied into ten files, and ten copies is nine
 * chances to be the tenth one that is different. /about and /404 still carried the
 * old one-line footer, /lookup and /paypal-return carried no bar at all, and the
 * homepage carried a third navigation that no other page could afford to copy
 * because it held the language switch. Nothing reported any of it: every file was
 * internally correct, and no check asks whether two pages agree with each other.
 *
 * So the set of links is data here, and the one question a hand-written file
 * cannot answer is answered by code — which of these links points back at the page
 * the reader is already on. A footer offering "Terms" to someone reading the terms
 * is a button that costs a click to arrive where they already are, and the answer
 * depends on the route, which only the server knows. Excluding the current page is
 * therefore not a thing each template may or may not do; it is the behaviour of
 * every footer, written once, on every page including the ones generated in code.
 *
 * Two label sources, one list. The static pages are translated in the browser by
 * public/i18n.js, so their anchors carry data-i18n and the Vietnamese inside them
 * is only the pre-script fallback a crawler reads. The product page is rendered by
 * this module in one language per URL and loads no dictionary, so it reads
 * COPY_VI/COPY_EN. `vi` is therefore the one word that appears in both worlds — it
 * is the fallback the server writes into the markup, and audit-web.mjs holds it
 * against the dictionary's own Vietnamese, so the two cannot drift.
 */

/**
 * A link, and the page it belongs to.
 *
 * `route` is what makes two links "the same page to a reader": the two homepage
 * anchors share the route "/" because they are sections of it, and the footer
 * drops both while the reader stands there. `page: true` marks a whole page, and
 * only a whole page can be aria-current="page" — two anchors on the homepage would
 * otherwise both claim to be the page the reader is on, and the announcement a
 * screen reader makes would name a section as if it were the site.
 */
const HEADER_LINKS = [
  { href: "/#products", route: "/", key: "nav.products", copy: "products", vi: "Sản phẩm" },
  { href: "/#faq", route: "/", key: "nav.faq", copy: "faqNav", vi: "FAQ" },
  { href: "/terms", route: "/terms", key: "nav.terms", copy: "terms", vi: "Điều khoản", page: true },
];

const FOOTER_LINKS = [
  { href: "/#products", route: "/", key: "nav.products", copy: "products", vi: "Sản phẩm" },
  { href: "/#faq", route: "/", key: "nav.faq", copy: "faqNav", vi: "FAQ" },
  { href: "/terms", route: "/terms", key: "nav.terms", copy: "terms", vi: "Điều khoản", page: true },
  { href: "/privacy", route: "/privacy", key: "nav.privacy", copy: "privacy", vi: "Bảo mật", page: true },
  { href: "/refund", route: "/refund", key: "nav.refund", copy: "refund", vi: "Hoàn tiền", page: true },
  { href: "/about", route: "/about", key: "nav.about", copy: "about", vi: "Về chúng tôi", page: true },
  { href: "/lookup", route: "/lookup", key: "nav.lookup", copy: "lookup", vi: "Tra cứu đơn", page: true },
  { href: "/contact", route: "/contact", key: "nav.contact", copy: "contact", vi: "Liên hệ", page: true },
  { mail: true, route: null, key: "nav.contactEmail", copy: "contactEmail", vi: "Email hỗ trợ" },
];

/**
 * The route a template answers on, from the file it lives in.
 *
 * The file name is the route because every page in public/ is registered under its
 * own name by src/app.js — /terms.html answers /terms — so this reads the same
 * table the router does rather than keeping a second list of addresses.
 */
const routeForFile = (file) => {
  const name = String(file || "").trim();
  if (!name) return "";
  if (name === "index.html") return "/";
  return `/${name.replace(/\.html$/, "")}`;
};

const chromeLink = (link, route, copy, prefix = "") => {
  // The support address is configuration, and it is already filled into these
  // pages as {{support}} — the same value the mail templates and the terms use.
  // A locale-prefixed page keeps its reader inside its language: every internal
  // link this bar can offer exists under every supported locale (the homepage,
  // the legal pages), so the prefix follows. A bare mailto stays bare. Links
  // to the landing sections (/#products) keep the prefix too, because /de/#products
  // is the German homepage's products section.
  const raw = link.href;
  const href = link.mail
    ? `mailto:${esc(env.email.supportEmail)}`
    : (prefix && raw.startsWith("/") && !raw.startsWith("//") ? `${prefix}${raw}` : raw);
  const label = copy ? copy[link.copy] : link.vi;
  const current = link.page && link.route === route ? ' aria-current="page"' : "";
  // The dictionary form keeps the switch working on a page that loads i18n.js;
  // the copy form is the product page, which is written in one language already.
  return copy
    ? `<a href="${href}"${current}>${esc(label)}</a>`
    : `<a href="${href}" data-i18n="${link.key}"${current}>${esc(label)}</a>`;
};

/**
 * The navigation every page carries, wrapped in its own <nav>.
 *
 * @param {string} route the route being rendered, or "" when it is none of them
 * @param {object} [copy] COPY_VI/COPY_EN when the server writes the words itself
 */
export const headerNav = (route, copy = null, prefix = "") =>
  `<nav>${HEADER_LINKS.map((link) => chromeLink(link, route, copy, prefix)).join("")}</nav>`;

/**
 * The footer's links: every one of them, except the one that points at this page.
 *
 * @param {string} route the route being rendered, or "" when it is none of them
 * @param {object} [copy] COPY_VI/COPY_EN when the server writes the words itself
 */
export const footerLinks = (route, copy = null, prefix = "") =>
  FOOTER_LINKS.filter((link) => !link.route || link.route !== route)
    .map((link) => chromeLink(link, route, copy, prefix)).join("");

/**
 * The footer as one element, for the page rendered in code rather than from a
 * template. The template pages get their <footer> from their own file so the brand
 * wordmark and the tagline stay in the markup; this is the same bar without the
 * two strings that live only in the dictionary.
 */
export const footerBar = (route, copy, prefix = "") => {
  const contactHtml = businessContactHtml(copy ? 'vi' : 'vi');
  return `<footer class="site-footer wrap"><div class="brand">${brandWordmark()}</div>` +
    `<p>${esc(copy.tagline || "")}</p>` +
    (contactHtml ? `<div class="footer-contact">${contactHtml}</div>` : '') +
    `<div class="footer-links">${footerLinks(route, copy, prefix)}</div>` +
    `<small>© ${new Date().getFullYear()} ${esc(brand())}</small></footer>`;
};

/**
 * Every {{token}} a static page template is allowed to carry, in one place.
 *
 * This list used to exist three times — as eleven replaceAll calls in
 * src/app.js, as a hand-written set in scripts/audit-web.mjs, and as another
 * one in test/support-address.test.js — and the three had already drifted:
 * {{brandWordmark}} was filled by the renderer but unknown to the audit, so the
 * build failed on thirteen correct pages while a real leak on /product/:slug
 * passed every gate. One list, exported from the module that also builds the
 * values, so adding a token in one place updates the renderer, the audit and
 * the tests together.
 *
 * PAGE_TOKENS and COPY_TOKENS stay `export const` even though almost nothing
 * imports them: scripts/audit-web.mjs reads them out of this file as *text*
 * (see readTokenList there), so the literal words `export const` are the
 * contract. The exports the audit does not read and nothing imports were
 * removed — an export with no reader is an API nobody agreed to.
 */
export const PAGE_TOKENS = [
  "site", "brandName", "brandWordmark", "support", "paymentWindowHours",
  "localeRegistry",
  "reviewMinLength", "reviewMaxLength", "year", "legalEntityLine", "businessContactHtml", "jsonLd", "iconLinks", "cssVersion",
  "policyUpdated", "policyUpdatedDisplay", "headerNav", "footerLinks", "founder", "brandPhone", "brandAddress",
  "contactPhoneCardAttr", "contactAddressCardAttr",
];
/**
 * The date printed at the top of the refund policy.
 *
 * It is a constant rather than "today" on purpose. A buyer who asks for a refund
 * five months from now is answering to the policy that was published when they
 * paid, not the one that has been reworded since; the order records this value
 * beside the moment they accepted it, and the policy page renders the same one so
 * the two can never say different dates.
 */
export const REFUND_POLICY_UPDATED = "2026-09-28";

/**
 * The same date as a reader sees it.
 *
 * The constant stays ISO because it is written onto every order and has to sort
 * and compare as a date. A legal page is not that: it prints "28/09/2026" in
 * Vietnamese and "28 September 2026" to an English reader. Formatting that at
 * each of the six places it appears is how the six came to disagree in the first
 * place — three templates typed the date by hand and drifted from the dictionary
 * the moment the constant moved.
 *
 * So there is one formatter and one token, and the fallback text in the HTML and
 * the string in the dictionary are the same value filled the same way.
 *
 * @param {string} iso an ISO date
 * @param {string} lang the page language
 * @returns {string} the date as that language writes it
 */
export const policyUpdatedFor = (iso, lang) => {
  const at = new Date(`${String(iso)}T00:00:00Z`);
  if (!Number.isFinite(at.getTime())) return String(iso);
  const DATE_LOCALES = { vi: "vi-VN", en: "en-GB", de: "de-DE", es: "es-ES", fr: "fr-FR", ja: "ja-JP", "zh-CN": "zh-CN" };
  return at.toLocaleDateString(DATE_LOCALES[lang] || "en-GB", {
    day: "2-digit", month: "2-digit", year: "numeric", timeZone: "UTC",
  });
};
/** Placeholders inside product copy, filled on the way out rather than in a page. */
export const COPY_TOKENS = ["founder", "brand"];
export const KNOWN_TEMPLATE_TOKENS = [...PAGE_TOKENS, ...COPY_TOKENS];

/**
 * The value of every page token for one render. reviewLimits travels as an
 * argument rather than an import so this module keeps its single dependency on
 * the store and never reaches into the review rules itself.
 *
 * `page` is the template being rendered, and it is the one thing the chrome needs
 * to know: the footer is the same everywhere except that it does not offer a link
 * back to the page it is printed on. See headerNav() and footerLinks().
 *
 * `lang` is the language of the page being rendered. The static pages answer
 * under their own prefix for every locale, so the chrome links and the
 * policy-date format follow it instead of assuming Vietnamese.
 */
export function pageTokenValues({ products = [], reviewLimits = null, page = "", lang = DEFAULT_LOCALE } = {}) {
  const route = routeForFile(page);
  const prefix = lang === DEFAULT_LOCALE ? "" : `/${lang}`;
  return {
    site: env.appUrl,
    // One source of truth for the locale list, published to the browser as a
    // script token. i18n.js and lang-detect.js read window.SVD_LOCALES instead of
    // keeping their own copies; adding a language is then one registry entry.
    localeRegistry: `<script defer src="/locale-registry.js"></script>`,
    brandName: esc(env.brand.name),
    brandWordmark: brandWordmark(),
    support: env.email.supportEmail,
    paymentWindowHours: String(env.orders.paymentWindowHours),
    reviewMinLength: String(reviewLimits?.minLength ?? 20),
    reviewMaxLength: String(reviewLimits?.maxLength ?? 1200),
    year: String(new Date().getFullYear()),
    // The day the refund policy was last reworded. Written on the policy page and
    // stored on every order placed after it, so a buyer who disputes the terms can
    // be shown the exact text they were given rather than whatever the page says
    // today. Two copies of this date is the bug where they disagree under a
    // dispute; it lives here because every reader imports it from one module.
    policyUpdated: REFUND_POLICY_UPDATED,
    policyUpdatedDisplay: policyUpdatedFor(REFUND_POLICY_UPDATED, lang),
    // Only legalEntityLine, not legalEntity. fillPageTokens fills the names in
    // PAGE_TOKENS and "legalEntity" is not one of them, so the bare value below
    // was an entry in this object that nothing could ever read — the legal entity
    // reached the page through the line, which is what handles it being empty.
    legalEntityLine: legalEntityLine(),
    businessContactHtml: businessContactHtml(lang),
    jsonLd: jsonLdGraph(products),
    // Rendered, not written into nine <head>s. The icon block is nine lines in ten
    // places otherwise, and the page that misses one is the page with no iOS icon.
    iconLinks: iconLinkMarkup().join("\n"),
    // The same argument for the two bars, and one step further: the footer cannot
    // be a block of text at all, because which of its links is missing depends on
    // the route being rendered. The prefix keeps a localized page's chrome links
    // inside its own language.
    headerNav: headerNav(route, null, prefix),
    footerLinks: footerLinks(route, null, prefix),
    cssVersion,
    founder: esc(env.brand.founderName || env.brand.name),
    brandPhone: esc(env.brand.phone || ''),
    brandAddress: esc(env.brand.address || ''),
    // An optional contact card is hidden, not emptied, when its value is not
    // configured. A <p></p> under "Địa chỉ" and a tel: link with no number read
    // as a broken page to a visitor and as a seller nobody can locate to the
    // Merchant Center misrepresentation review. The owner still has to set
    // BRAND_PHONE/BRAND_ADDRESS; this only stops the page from advertising that
    // they are missing.
    contactPhoneCardAttr: String(env.brand.phone || '').trim() ? '' : ' hidden',
    contactAddressCardAttr: String(env.brand.address || '').trim() ? '' : ' hidden',
  };
}

/**
 * Fills the page tokens in a template. Tokens with no value are left alone
 * rather than blanked, so a typo shows up as {{typo}} for the audit and the
 * byte-level tests to catch instead of a sentence with a hole in it.
 */
export function fillPageTokens(html, values) {
  let out = String(html ?? "");
  for (const name of PAGE_TOKENS) {
    if (values[name] !== undefined) out = out.replaceAll(`{{${name}}}`, values[name]);
  }
  return out;
}

// ---------------------------------------------------------------------------
// Localisation for the static pages (homepage, legal pages).
//
// The same static file used to be served as-is in every locale, so a crawler
// asking for /de/ received a Vietnamese <html lang>, a Vietnamese title and a
// canonical pointing at "/", indistinguishable from the Vietnamese homepage.
// renderPage() passes the route's language along; this function makes the rest
// of the head tell the truth - html lang, title, description, canonical,
// Open Graph locale, hreflang - and swaps the body's data-i18n text for the
// language's own words before the crawler ever sees them.
// ---------------------------------------------------------------------------

/**
 * The static pages rendered for every locale, and the route slug each one owns.
 * Keyed by file name because that is what public/ ships and what the router
 * mounts; vi is the source language, so it maps to the unprefixed routes.
 */
const STATIC_PAGES = {
  "index.html": { slug: "", key: "home" },
  "about.html": { slug: "/about", key: "about" },
  "terms.html": { slug: "/terms", key: "terms" },
  "privacy.html": { slug: "/privacy", key: "privacy" },
  "refund.html": { slug: "/refund", key: "refund" },
  // Contact is linked from every footer and was the one localized route left out
  // of this table. /en/contact therefore skipped localizeStaticHtml, served the
  // Vietnamese template with lang="vi", and let i18n.js translate the whole page
  // after load — a 0.204 layout shift on a phone, and a crawlable English URL
  // that returned Vietnamese bytes.
  "contact.html": { slug: "/contact", key: "contact" },
};

/**
 * The title and description a non-Vietnamese reader and crawler should see,
 * per page, per locale. Vietnamese lives in the templates themselves (it is
 * the source language); English is the fallback for any locale that ever loses
 * its entry here. {{brandName}} is resolved in the same pass as every other
 * page token, so a brand change still reaches every sentence.
 */
export const STATIC_META = {
  home: {
    vi: { title: "Bật macro Excel & kiểm tra dung lượng USB | {{brandName}}", description: "Bật macro Excel không cần chỉnh tay từng file, kiểm tra dung lượng thật của USB và thẻ nhớ. Hai tiện ích Windows, mua một lần dùng vĩnh viễn, tải ngay sau khi thanh toán." },
    en: { title: "Excel macro fix & real USB capacity check | {{brandName}}", description: "Get Excel macros running without touching each file by hand, and check the real capacity of your USB drive and memory card. Two Windows utilities, one-time payment, download right after payment." },
    de: { title: "Excel-Makros aktivieren & echte USB-Kapazität prüfen | {{brandName}}", description: "Bringen Sie Excel-Makros ohne Handarbeit pro Datei zum Laufen und prüfen Sie die echte Kapazität Ihres USB-Sticks und Ihrer Speicherkarten. Zwei Windows-Werkzeuge, einmaliger Kauf, sofortiger Download nach Zahlung." },
    es: { title: "Activar macros de Excel & comprobar capacidad real del USB | {{brandName}}", description: "Activa las macros de Excel sin ajustar archivo por archivo y comprueba la capacidad real de tu USB y tarjetas de memoria. Dos utilidades para Windows, pago único, descarga inmediata tras el pago." },
    fr: { title: "Activer les macros Excel & mesurer la vraie capacité USB | {{brandName}}", description: "Faites fonctionner vos macros sans réglage fichier par fichier et mesurez la vraie capacité de votre clé USB et de vos cartes mémoire. Deux utilitaires Windows, achat unique, téléchargement immédiat après paiement." },
    ja: { title: "Excelマクロを有効化 & USB容量の実測 | {{brandName}}", description: "ファイルごとの手作業なしでExcelマクロを動かし、USBメモリとメモリカードの本当の容量を検証。Windows向け2つのユーティリティ、買い切り、お支払い後すぐにダウンロード。" },
    "zh-CN": { title: "启用 Excel 宏 & 实测 USB 真实容量 | {{brandName}}", description: "无需逐个文件手动修改即可启用 Excel 宏，并检测 U 盘和内存卡的真实容量。两款 Windows 小工具，一次买断，付款后立即下载。" },
  },
  about: {
    vi: { title: "Về chúng tôi - ai làm ra {{brandName}} và vì sao", description: "{{brandName}} là ai, làm phần mềm gì, và ai đứng sau nó. Trang này nói thẳng để bạn biết mình đang mua của ai." },
    en: { title: "About {{brandName}} - who makes this software and why", description: "Who {{brandName}} is, what software it makes and who is behind it. This page says it plainly so you know who you are buying from." },
    de: { title: "Über {{brandName}} - wer diese Software macht und warum", description: "Wer {{brandName}} ist, welche Software es entwickelt und wer dahintersteht. Auf dieser Seite steht es klar und deutlich, damit Sie wissen, bei wem Sie kaufen." },
    es: { title: "Sobre {{brandName}} - quién hace este software y por qué", description: "Quién es {{brandName}}, qué software fabrica y quién está detrás. En esta página se dice claramente para que sepas a quién le compras." },
    fr: { title: "À propos de {{brandName}} - qui conçoit ce logiciel et pourquoi", description: "Qui est {{brandName}}, quels logiciels sont conçus et qui est derrière tout cela. Cette page le dit clairement, pour que vous sachiez à qui vous achetez." },
    ja: { title: "{{brandName}} について - 誰が、なぜこのソフトを作ったか", description: "{{brandName}} とは何者か、どんなソフトウェアを作っているか、誰が運営しているかを率直に書きます。誰から買っているかを知ってほしいからです。" },
    "zh-CN": { title: "关于 {{brandName}} - 谁在做这个软件，为什么", description: "{{brandName}} 是谁，做什么软件，背后是谁。这一页直说重点，让你知道自己在向谁购买。" },
  },
  terms: {
    vi: { title: "Điều khoản sử dụng - {{brandName}}", description: "Điều khoản sử dụng kho phần mềm {{brandName}}: phạm vi cấp phép, thanh toán, bảo hành và giới hạn trách nhiệm." },
    en: { title: "Terms of use - {{brandName}}", description: "Terms of use for the {{brandName}} software catalogue: licence scope, payment, warranty and liability limits." },
    de: { title: "Nutzungsbedingungen - {{brandName}}", description: "Nutzungsbedingungen für den {{brandName}} Softwarekatalog: Lizenzumfang, Zahlung, Gewährleistung und Haftungsgrenzen." },
    es: { title: "Términos de uso - {{brandName}}", description: "Términos de uso del catálogo de software de {{brandName}}: alcance de la licencia, pagos, garantía y límites de responsabilidad." },
    fr: { title: "Conditions d'utilisation - {{brandName}}", description: "Conditions d'utilisation du catalogue logiciel {{brandName}} : périmètre de licence, paiement, garantie et limites de responsabilité." },
    ja: { title: "利用規約 - {{brandName}}", description: "{{brandName}} ソフトウェアカタログの利用規約：ライセンス範囲、支払い、保証と責任の制限。" },
    "zh-CN": { title: "使用条款 - {{brandName}}", description: "{{brandName}} 软件目录的使用条款：授权范围、付款、保修与责任限制。" },
  },
  privacy: {
    vi: { title: "Chính sách bảo mật - {{brandName}}", description: "Chính sách bảo mật {{brandName}}: dữ liệu nào được thu thập, lưu giữ bao lâu và ai có thể truy cập." },
    en: { title: "Privacy policy - {{brandName}}", description: "{{brandName}} privacy policy: what data we collect, how long we keep it and who can access it." },
    de: { title: "Datenschutzerklärung - {{brandName}}", description: "Datenschutzerklärung von {{brandName}}: welche Daten wir erheben, wie lange wir sie speichern und wer sie einsehen kann." },
    es: { title: "Política de privacidad - {{brandName}}", description: "Política de privacidad de {{brandName}}: qué datos recopilamos, cuánto tiempo los conservamos y quién puede acceder." },
    fr: { title: "Politique de confidentialité - {{brandName}}", description: "Politique de confidentialité de {{brandName}} : quelles données sont collectées, combien de temps elles sont conservées et qui y accède." },
    ja: { title: "プライバシーポリシー - {{brandName}}", description: "{{brandName}} のプライバシーポリシー：収集するデータ、保存期間と、誰がアクセスできるか。" },
    "zh-CN": { title: "隐私政策 - {{brandName}}", description: "{{brandName}} 隐私政策：我们收集什么数据、保存多久，以及谁可以访问。" },
  },
  refund: {
    vi: { title: "Chính sách hoàn tiền - {{brandName}}", description: "Chính sách hoàn tiền {{brandName}}: điều kiện được hoàn, thời hạn xử lý và các trường hợp không hoàn." },
    en: { title: "Refund policy - {{brandName}}", description: "{{brandName}} refund policy: refund conditions, processing deadlines and the cases where we cannot refund." },
    de: { title: "Rückerstattungsrichtlinie - {{brandName}}", description: "Rückerstattungsrichtlinie von {{brandName}}: Erstattungsbedingungen, Bearbeitungsfristen und die Fälle, in denen keine Erstattung erfolgt." },
    es: { title: "Política de reembolso - {{brandName}}", description: "Política de reembolso de {{brandName}}: condiciones de reembolso, plazos de tramitación y los casos en los que no se puede reembolsar." },
    fr: { title: "Politique de remboursement - {{brandName}}", description: "Politique de remboursement de {{brandName}} : conditions de remboursement, délais de traitement et les cas où le remboursement est impossible." },
    ja: { title: "返金ポリシー - {{brandName}}", description: "{{brandName}} の返金ポリシー：返金条件、処理期限、返金できない場合。" },
    "zh-CN": { title: "退款政策 - {{brandName}}", description: "{{brandName}} 退款政策：退款条件、处理期限，以及不予退款的情形。" },
  },
  contact: {
    vi: { title: "Liên hệ - {{brandName}}", description: "Liên hệ {{brandName}} để được hỗ trợ đơn hàng, hoàn tiền, hoặc hỏi đáp trước khi mua. Chúng tôi trả lời qua email và điện thoại." },
    en: { title: "Contact - {{brandName}}", description: "Contact {{brandName}} for order support, refunds or pre-sales questions. We answer by email and phone." },
    de: { title: "Kontakt - {{brandName}}", description: "Kontaktieren Sie {{brandName}} für Bestellhilfe, Rückerstattungen oder Fragen vor dem Kauf. Wir antworten per E-Mail und Telefon." },
    es: { title: "Contacto - {{brandName}}", description: "Contacta con {{brandName}} para soporte de pedidos, reembolsos o dudas antes de comprar. Respondemos por correo y teléfono." },
    fr: { title: "Contact - {{brandName}}", description: "Contactez {{brandName}} pour l'aide sur les commandes, les remboursements ou les questions avant achat. Nous répondons par e-mail et par téléphone." },
    ja: { title: "お問い合わせ - {{brandName}}", description: "ご注文のサポート、返金、購入前のご質問は {{brandName}} まで。メールと電話でお答えします。" },
    "zh-CN": { title: "联系我们 - {{brandName}}", description: "如需订单支持、退款或购买前咨询，请联系 {{brandName}}。我们通过电子邮件和电话回复。" },
  },
};

/** The URL a static page answers on in one language. Vietnamese keeps the root; every other locale prefixes its own code. */
const staticPageUrl = (slug, lang) => `${site()}${lang === "vi" ? "" : `/${lang}`}${slug || "/"}`;

const altLinks = (slug) =>
  `${LOCALE_CODES.map((code) => `<link rel="alternate" hreflang="${code}" href="${esc(staticPageUrl(slug, code))}">`).join("\n")}\n` +
  `<link rel="alternate" hreflang="x-default" href="${esc(staticPageUrl(slug, DEFAULT_LOCALE))}">`;

/** The single-brace placeholders the browser dictionary fills from its own TOKENS map; the server resolves the ones it can and leaves the rest alone. */
const fillSingleBraces = (text, lang) => {
  const vars = {
    brand: env.brand.name,
    brandName: env.brand.name,
    founder: env.brand.founderName || env.brand.name,
    support: env.email.supportEmail,
    year: String(new Date().getFullYear()),
    hours: String(env.orders.paymentWindowHours),
    paymentWindowHours: String(env.orders.paymentWindowHours),
    site: site(),
    policyUpdatedDisplay: policyUpdatedFor(REFUND_POLICY_UPDATED, lang),
    policyUpdatedDisplayEn: policyUpdatedFor(REFUND_POLICY_UPDATED, "en"),
  };
  let out = String(text);
  // Double-brace tokens belong to pageTokenValues, not to this pass. A plain
  // replacement would find {{brandName}}'s trailing {brandName} and leave the
  // outer braces around the real value ({SonVuDev}).
  for (const [key, value] of Object.entries(vars)) {
    out = out.replace(new RegExp(`(?<!\\{)\\{${key}\\}(?!\\})`, "g"), String(value));
  }
  return out;
};

const dictFor = (lang) => (lang === "vi" ? null : loadLocaleJson(lang));

/**
 * Localizes a static page for one language. Returns the HTML ready to send.
 *
 * `values` is the same token bag pageTokenValues() built - the second pass fills
 * any {{...}} the dictionaries introduce (legal strings carry {{brandName}}
 * and {{paymentWindowHours}}), so the browser and the crawler agree on the
 * numbers.
 */
export function localizeStaticHtml(html, { file = "", lang = DEFAULT_LOCALE, values = null } = {}) {
  const entry = STATIC_PAGES[file];
  if (!entry) return String(html);
  const { slug, key } = entry;
  const meta = STATIC_META[key][lang] || STATIC_META[key].en;
  const url = staticPageUrl(slug, lang);
  const title = esc(fillSingleBraces(meta.title, lang));
  const description = esc(fillSingleBraces(meta.description, lang));
  let out = String(html);

  // 1. Root language, and every crawler-visible head field.
  out = out.replace(/<html lang="[^"]*">/, `<html lang="${lang}">`);
  out = out.replace(/<title([^>]*)>[\s\S]*?<\/title>/, `<title$1>${title}</title>`);
  out = out.replace(/<meta name="description" content="[^"]*">/, `<meta name="description" content="${description}">`);
  out = out.replace(/<link rel="canonical" href="[^"]*">/, `<link rel="canonical" href="${esc(url)}">`);
  out = out.replace(/<meta property="og:url" content="[^"]*">/, `<meta property="og:url" content="${esc(url)}">`);
  out = out.replace(/<meta property="og:title" content="[^"]*">/, `<meta property="og:title" content="${title}">`);
  out = out.replace(/<meta property="og:description" content="[^"]*">/, `<meta property="og:description" content="${description}">`);
  out = out.replace(/<meta property="twitter:title" content="[^"]*">/, `<meta property="twitter:title" content="${title}">`);
  out = out.replace(/<meta property="twitter:description" content="[^"]*">/, `<meta property="twitter:description" content="${description}">`);
  // The link-preview card says what the page is; make it the same sentence the page opens with.
  out = out.replace(/<meta property="og:image:alt" content="[^"]*">/, `<meta property="og:image:alt" content="${title}">`);
  out = out.replace(/<meta property="og:locale" content="[^"]*">/, `<meta property="og:locale" content="${OG_LOCALE[lang] || OG_LOCALE.en}">`);
  // og:locale:alternate: one line per other locale, not a single stale vi_VN.
  out = out.replace(/\n?[ \t]*<meta property="og:locale:alternate" content="[^"]*">/g, "");
  out = out.replace(
    /(<meta property="og:locale" content="[^"]*">)/,
    `$1\n${LOCALE_CODES.filter((code) => code !== lang).map((code) => `<meta property="og:locale:alternate" content="${OG_LOCALE[code]}">`).join("\n")}`,
  );
  // hreflang: drop the template's hand-written pair, write the whole set.
  out = out.replace(/<link rel="alternate" hreflang="[^"]*" href="[^"]*">\s*/g, "");
  out = out.replace(/<\/head>/, `${altLinks(slug)}\n</head>`);

  // 2. Body text: swap the Vietnamese fallback copy for the locale's own words.
  const dict = dictFor(lang);
  if (dict) {
    out = out.replace(
      /<([A-Za-z][\w-]*)([^>]*?)\sdata-i18n-html="([^"]+)"([^>]*)>([\s\S]*?)<\/\1>/g,
      (_m, tag, before, k, _after, _inner) => {
        const v = dict[k];
        return typeof v === "string" && v ? `<${tag}${before}>${fillSingleBraces(v, lang)}</${tag}>` : _m;
      },
    );
    out = out.replace(
      // Nested markup is allowed and flattened to the dictionary's text on
      // purpose. The browser's apply() sets textContent, so a localized
      // sentence with a <strong> or a link in the template ends up as plain
      // text there too; matching only text-only elements left the contact
      // list in Vietnamese on /en/contact until i18n.js rewrote it after load,
      // which is the 0.204 layout shift this pass exists to prevent.
      /<([A-Za-z][\w-]*)([^>]*?)\sdata-i18n="([^"]+)"([^>]*)>([\s\S]*?)<\/\1>/g,
      // Rebuild the tag keeping data-i18n so the browser's dictionary still owns the live page.
      (_m, tag, before, k, after, _inner) => {
        const v = dict[k];
        return typeof v === "string" && v
          ? `<${tag}${before} data-i18n="${k}"${after}>${esc(fillSingleBraces(v, lang))}</${tag}>`
          : _m;
      },
    );
    out = out.replace(/<[A-Za-z][\w-]*[^>]*\sdata-i18n-attr="[^"]*"[^>]*>/g, (tag) => {
      const m = tag.match(/data-i18n-attr="([^"]+)"/);
      if (!m) return tag;
      let result = tag;
      for (const pair of m[1].split(",")) {
        const [attr, k] = pair.split(":").map((s) => s.trim());
        const v = k ? dict[k] : undefined;
        const safeAttr = String(attr || "").replace(/[^a-zA-Z-]/g, "");
        if (!safeAttr || typeof v !== "string") continue;
        result = result.replace(
          new RegExp(`(${safeAttr.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")})="[^"]*"`),
          `$1="${esc(fillSingleBraces(v, lang))}"`,
        );
      }
      return result;
    });
  }

  // 3. Any {{...}} the dictionaries introduced, and the fill of {{brandName}} inside them.
  if (values) out = fillPageTokens(out, values);
  return out;
}

/**
 * The configuration values a language switch still needs, shipped in one meta
 * tag.
 *
 * The legal pages carry {{paymentWindowHours}} and {{support}} inside their
 * *translations*. The server fills those placeholders into the HTML it renders,
 * and that is the only copy it can reach: when a reader switches language,
 * i18n.js replaces the paragraph with the dictionary copy through I18N.t(),
 * which brings the placeholder back with it. The sentence then reads "cancelled
 * after {{paymentWindowHours}} hours", on a page that was correct a second
 * earlier. Both dictionaries are affected, so neither language is the safe one.
 *
 * Hard-coding the numbers into both dictionaries is the other way out, and it
 * is worse: the refund window would then be written in three places (config,
 * English, Vietnamese) with nothing tying them together. The values travel with
 * the page instead, and the browser substitutes them on the way out.
 *
 * Values are percent-encoded because a support address contains "@" and a
 * payment window does not — the delimiter has to survive both.
 */
export const tokenMeta = (lang = DEFAULT_LOCALE) => {
  // JSON rather than name=value pairs joined by a delimiter. The joined form
  // needs a separator no value can contain, and escaping it needs an escape
  // helper of its own — which is a third copy of esc() and exactly what the
  // escCopies metric is there to catch. esc(JSON.stringify(...)) reuses the one
  // in format.js, and the browser gets clean JSON back after parsing the
  // attribute.
  const values = {
    brandName: String(env.brand.name ?? ""),
    site: String(env.appUrl ?? ""),
    support: String(env.email.supportEmail ?? ""),
    year: String(new Date().getFullYear()),
    paymentWindowHours: String(env.orders.paymentWindowHours ?? ""),
    // The refund policy's own date, for the sentence the buyer reads on the policy
    // page. It travels with the page tokens so the policy date in the dictionary
    // and the one recorded on the order are filled from the same constant.
    policyUpdated: REFUND_POLICY_UPDATED,
    policyUpdatedDisplay: policyUpdatedFor(REFUND_POLICY_UPDATED, lang),
    // The browser fills the English sentences from this too, so a language switch
    // shows the date written the way that language writes dates.
    policyUpdatedDisplayEn: policyUpdatedFor(REFUND_POLICY_UPDATED, "en"),
  };
  return `<meta name="sv-tokens" content="${esc(JSON.stringify(values))}">`;
};

/**
 * The verification file a search engine fetches from the site root.
 *
 * Google names it google<token>.html and wants a one-line body naming itself;
 * Bing names it ms<token>.txt and wants the bare token. Both names come out of
 * the same string the meta tag uses, so one env var satisfies either method.
 * Returns null when the token is not configured, which is not an error.
 */
export const verificationFile = (prefix, suffix, token) => {
  const value = String(token || "").trim();
  if (!value || !/^[0-9a-z]+$/i.test(value)) return null;
  const name = `${prefix}${value}${suffix}`;
  return { name, body: prefix === "google" ? `google-site-verification: ${name}` : value };
};

/** One product's canonical address. Vietnamese is the root; every other locale prefixes its own code. */
const productUrl = (slug, lang = "vi") => `${localePrefix(lang)}/product/${slug}`;

/**
 * The legal-entity line, or nothing at all.
 *
 * The three legal pages each carried `<p class="legal-entity">{{legalEntity}}</p>`
 * unconditionally, and BRAND_LEGAL_ENTITY is unset by default — so every one of them
 * shipped an empty paragraph. It is not invisible: `legal-entity` has its own margin
 * and colour, so what a buyer saw on /terms was a gap where the shop's name should
 * be, on the page whose entire job is saying who is responsible for the sale.
 *
 * The whole element is the token rather than just its text, because the alternative
 * is the same empty paragraph with a different failure: an empty <p> is a layout
 * artefact that only a person looking at the page would ever notice, whereas
 * omitting it is a decision the markup makes visible in review.
 */
const legalEntityLine = (className = 'legal-entity') => {
  const name = String(env.brand.legalEntity || '').trim();
  return name ? `<p class="${className}">${esc(name)}</p>` : '';
};

// Owner-verified business contact details for transparency pages. Only values
// explicitly configured are rendered; missing optional fields are omitted rather
// than fabricated (fabricated identity details increase misrepresentation risk).
const businessContactHtml = (lang = DEFAULT_LOCALE) => {
  const labels = {
    vi: { legal: 'Pháp nhân/đơn vị', address: 'Địa chỉ', phone: 'Điện thoại', email: 'Email hỗ trợ' },
    en: { legal: 'Legal entity', address: 'Address', phone: 'Phone', email: 'Support email' },
  }[lang] || { legal: 'Legal entity', address: 'Address', phone: 'Phone', email: 'Support email' };
  const lines = [];
  const legal = String(env.brand.legalEntity || '').trim();
  const address = String(env.brand.address || '').trim();
  const phone = String(env.brand.phone || '').trim();
  const email = String(env.email.supportEmail || '').trim();
  if (legal) lines.push(`<p><strong>${labels.legal}:</strong> ${esc(legal)}</p>`);
  if (address) lines.push(`<p><strong>${labels.address}:</strong> ${esc(address)}</p>`);
  if (phone) lines.push(`<p><strong>${labels.phone}:</strong> <a href="tel:${esc(phone.replace(/[^\d+]/g, ''))}">${esc(phone)}</a></p>`);
  if (email) lines.push(`<p><strong>${labels.email}:</strong> <a href="mailto:${esc(email)}">${esc(email)}</a></p>`);
  return lines.join('\n');
};

/**
 * Meta block shared by every indexable page.
 *
 * og:image points at the committed PNG rather than the per-product SVG. The SVG
 * is still generated and still served, but Facebook, Zalo, Telegram, Slack,
 * LinkedIn and most AI answer engines refuse SVG outright, so a card that looks
 * right in a browser is an empty box at every place the link is actually shared.
 */
const meta = ({ title, description, url, image = absolute(OG_IMAGE_PATH), type = "website", published, lang = "vi", alternates }) => {
  const ogLocale = OG_LOCALE[lang] || OG_LOCALE.en;
  // Every supported locale is a separate URL serving the same product, so they
  // all point at each other. A crawler that finds only vi and en sees five
  // more pages with no declaration of who they are — and either drops them as
  // duplicates or indexes them as competitors to the Vietnamese one.
  const alternateLinks = LOCALE_CODES
    .map((code) => (alternates?.[code] ? `<link rel="alternate" hreflang="${code}" href="${esc(alternates[code])}">` : null))
    .filter(Boolean);
  return [
  `<title>${esc(title)}</title>`,
  `<meta name="description" content="${esc(description)}">`,
  `<link rel="canonical" href="${esc(url)}">`,
  ...alternateLinks,
  `<link rel="alternate" hreflang="x-default" href="${esc(alternates?.vi || url)}">`,
  `<meta property="og:type" content="${type}">`,
  `<meta property="og:site_name" content="${esc(brand())}">`,
  `<meta property="og:locale" content="${ogLocale}">`,
  ...LOCALE_CODES.filter((code) => code !== lang).map((code) => `<meta property="og:locale:alternate" content="${OG_LOCALE[code]}">`),
  `<meta property="og:title" content="${esc(title)}">`,
  `<meta property="og:description" content="${esc(description)}">`,
  `<meta property="og:url" content="${esc(url)}">`,
  image ? `<meta property="og:image" content="${esc(image)}">` : "",
  image ? `<meta property="og:image:width" content="${OG_IMAGE.width}">` : "",
  image ? `<meta property="og:image:height" content="${OG_IMAGE.height}">` : "",
  image ? `<meta property="og:image:alt" content="${esc(title)}">` : "",
  `<meta name="twitter:card" content="${image ? "summary_large_image" : "summary"}">`,
  `<meta name="twitter:title" content="${esc(title)}">`,
  `<meta name="twitter:description" content="${esc(description)}">`,
  published ? `<meta property="article:published_time" content="${esc(published)}">` : "",
  ].filter(Boolean).join("\n");
};

/**
 * The product grid, rendered on the server into the homepage.
 *
 * The storefront fills this in with JavaScript, which is fine for a person but
 * means a crawler reads a landing page with a hero, a slogan and no products: no
 * names, no prices, and not one link to a product page. Internal links are how a
 * search engine discovers and judges the rest of a site, so a store that only
 * advertises its products in the sitemap is a store that is one crawl away from
 * being invisible.
 *
 * The classes and fields are the ones public/app.js produces, so the swap when
 * the page's own script runs is a repaint rather than a layout change. The name
 * and the arrow are real links, which is what makes the page usable with
 * JavaScript turned off.
*/
/**
 * The homepage product grid, rendered in Vietnamese with data attributes
 * for client-side translation. Categories and badges include both VI and EN
 * so the browser can switch languages without a server round-trip.
 */
export function renderIndexGrid(products, lang = DEFAULT_LOCALE) {
  const labels = ssrLabels(lang);
  const cards = (products || []).filter(isSellable).map((product) => {
    const shown = localize(product, lang);
    const art = esc(String(product.category || "khac").toLowerCase().replace(/\s+/g, "-"));
    // RULE: purchase actions use /?buy=<id> and open the purchase form (never
    // navigate to /product/* from store/blog buy affordances). See docs/PURCHASE-LINK-RULES.md.
    // Keep an absolute product-page link for SEO/crawler discovery (no-JS fallback).
    const url = absolute(`/product/${encodeURIComponent(product.slug)}`);
    const buyUrl = `/?buy=${encodeURIComponent(product.id)}`;
    const badgeRaw = String(product.badge || "").trim();
    const badgeFilled = fillCopy(badgeRaw);
    const badgeVi = badgeFilled || "Mới";
    const badgeEn = COPY_EN.badges[badgeVi] || badgeVi;
    const categoryRaw = String(product.category || "").trim();
    const categoryVi = normaliseCategory(categoryRaw) || COPY_VI.software;
    const categoryEn = COPY_EN.categories[categoryVi] || categoryVi;
    const nameVi = esc(fillCopy(product.name));
    const nameEn = product.nameEn ? esc(fillCopy(product.nameEn)) : nameVi;
    const descVi = esc(fillCopy(product.shortDescription || product.short_description || product.description || ""));
    const descEn = product.shortDescriptionEn ? esc(fillCopy(product.shortDescriptionEn)) : descVi;
    
    const featuresVi = (product.features || []).slice(0, 2).map((item) => esc(fillCopy(item)));
    const featuresEn = (product.featuresEn && product.featuresEn.length)
      ? (product.featuresEn || []).slice(0, 2).map((item) => esc(fillCopy(item)))
      : featuresVi;
    
    const featureShown = (shown.features || []).slice(0, 2).map((f) => esc(fillCopy(f)));
    const features = featuresVi.map((item, index) =>
      `<li data-vi="✓ ${item}" data-en="✓ ${(featuresEn[index] || item)}">✓ ${(featureShown[index] || (lang === "vi" ? item : (featuresEn[index] || item)))}</li>`).join("");
    const badgeShown = lang === "vi" ? badgeVi : (labels.badge[badgeVi] || badgeEn);
    return `<article class="product-card" data-id="${esc(product.id)}">
    <div class="product-art art-${art}">
      <span class="product-badge" data-i18n="products.new" data-vi="${esc(badgeVi)}" data-en="${esc(badgeEn)}">${esc(badgeShown)}</span>
      <div class="product-logo">${esc(initials(product.name))}</div>
      <div class="art-grid"></div>
      <span class="art-spark">✦</span>
    </div>
    <div class="product-info">
      <div class="product-meta"><span>${esc(product.platform || "Windows")} · v${esc(product.version || "1.0")}</span><span data-vi="${esc(categoryVi)}" data-en="${esc(categoryEn)}">${esc(lang === "vi" ? categoryVi : (labels.category[categoryVi] || categoryEn))}</span></div>
      <h3><a class="product-page-link" href="${esc(url)}" data-vi="${nameVi}" data-en="${nameEn}">${esc(lang === "vi" ? fillCopy(product.name) : fillCopy(shown.name))}</a></h3>
      <p data-vi="${descVi}" data-en="${descEn}">${esc(lang === "vi" ? fillCopy(product.shortDescription || product.description || "") : shown.shortDescription)}</p>
      <ul>${features}</ul>
      <div class="product-buy">
        <strong>${esc(money(product.price, product.currency))}</strong>
        <a class="round-arrow buy-btn" href="${esc(buyUrl)}" rel="nofollow" data-buy-id="${esc(product.id)}" data-i18n-attr="aria-label:products.buyAria" aria-label="Mua ${nameVi}">↗</a>
      </div>
    </div>
  </article>`;
  });
  return cards.length
    ? cards.join("\n")
    : `<div class="empty-state"><b data-i18n="products.emptyTitle" data-vi="Không có sản phẩm nào khớp" data-en="No products match">Không có sản phẩm nào khớp</b><p data-i18n="products.emptyText" data-vi="Hãy thử từ khoá khác, hoặc bỏ bộ lọc đang chọn." data-en="Try a different word, or clear the filter you picked.">Hãy thử từ khoá khác, hoặc bỏ bộ lọc đang chọn.</p></div>`;
};
// The visible text of the homepage grid is rendered in the route's language so a
// crawler or a reader without JavaScript does not see Vietnamese under a /de/ or
// /ja/ prefix. The data-vi/data-en attributes stay: the browser still swaps them
// for vi/en, and for every other locale it re-renders the grid from the same
// locale asset (public/locales/<lang>.json) via localize(). One translation
// source, two renderers, no hand-maintained second table.
const ssrLabels = (lang) => {
  const json = loadLocaleJson(lang);
  return {
    category: overlayLabels(json, "category", CATEGORY_EN),
    badge: overlayLabels(json, "badge", COPY_EN.badges),
  };
};

const COUNT_WORD = { vi: "sản phẩm", en: "products", de: "Produkte", es: "productos", fr: "produits", ja: "製品", "zh-CN": "个产品" };

/** The product count above the grid, in the route's language. */
export const renderIndexCount = (products, lang = DEFAULT_LOCALE) => {
  const total = (products || []).filter(isSellable).length;
  return `${String(total).padStart(2, "0")} ${COUNT_WORD[lang] || COUNT_WORD.en}`;
};

/**
 * The homepage's category filter row, built from what is actually for sale.
 * Rendered in Vietnamese with data-vi/data-en attributes for client-side translation.
 */
// The catalogue may store the category in either Vietnamese or English.
// Normalise to Vietnamese so downstream renderers always have the same anchor
// for both the button text and the data-en attribute.
export const renderIndexFilters = (products, lang = DEFAULT_LOCALE) => {
  const labels = ssrLabels(lang);
  const allWord = { vi: "Tất cả", en: "All", de: "Alle", es: "Todo", fr: "Tous", ja: "すべて", "zh-CN": "全部" }[lang] || "All";
  const counts = new Map();
  for (const product of products || []) {
    // Canonical, so "Utility" (English, singular, typed in the admin panel) and
    // "Tiện ích" are one filter with one label in every language, and the
    // browser compares a canonical value with a canonical value.
    const raw = normaliseCategory(product.category);
    if (!raw) continue;
    counts.set(raw, (counts.get(raw) || 0) + 1);
  }
  const buttons = [...counts.entries()]
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0], "vi"))
    .map(([raw, count]) => {
      const categoryVi = normaliseCategory(raw);
      const categoryEn = COPY_EN.categories[categoryVi] || categoryVi;
      const shown = lang === "vi" ? categoryVi : (labels.category[categoryVi] || categoryEn);
      return `<button class="filter" data-filter="${esc(raw)}" data-count="${count}" data-vi="${esc(categoryVi)}" data-en="${esc(categoryEn)}">${esc(shown)}</button>`;
    })
    .join("");
  return `<button class="filter active" data-filter="all" data-i18n="products.all" data-vi="Tất cả" data-en="All">${esc(allWord)}</button>${buttons}`;
};

/**
 * The three numbers under the hero, counted from the catalogue.
 *
 * These were 01+, 4.9/5 and 100% written into the template. None of the three was a
 * measurement of anything: there is no rating in this shop, and nothing behind the
 * third one. So the strip was making claims in numbers, on the page whose whole
 * argument is that the work is careful.
 *
 * What replaced them can be counted, which means it is true at every moment without
 * anyone remembering to update it. A shop with one product reads "1", which is a
 * smaller and less impressive number and also the correct one.
 *
 * Returns null when there is nothing to count, so the caller can drop the strip
 * rather than print zeros: a shop with an empty catalogue saying "0 products" is
 * still making a statement about itself.
 */
export const renderStats = (products) => {
  const sellable = (products || []).filter(isSellable);
  if (!sellable.length) return null;
  const platforms = new Set(sellable.map((product) => String(product.platform || "").trim()).filter(Boolean));
  return {
    products: sellable.length,
    platforms: platforms.size,
    // Counting versions rather than summing a field nobody maintains: a product
    // with a `version` has at least that one release, and the catalogue does not
    // record a release history.
    releases: sellable.reduce((total, product) => total + (product.version ? 1 : 0), 0),
  };
};

/**
 * The words on a product page, in both languages.
 *
 * These used to be typed into the Vietnamese template and left out of the English
 * one entirely, which is why the server only ever had one language to render. Two
 * tables side by side make a missing translation a visible gap rather than a
 * silent absence.
 */
export const COPY_VI = {
  home: "Trang chủ",
  tagline: "Phần mềm tốt cho công việc tốt",
  products: "Sản phẩm",
  faqNav: "Câu hỏi",
  about: "Về chúng tôi",
  // The footer on a product page is the same list as every other page's, so these
  // two are not decoration on this page: without them the generated footer could
  // not carry the last two links the shop has.
  lookup: "Tra cứu đơn",
  contact: "Liên hệ",
  status: "Trạng thái",
  breadcrumbLabel: "Đường dẫn",
  software: "Phần mềm",
  // Category and badge are free-text columns, so a Vietnamese product carries
  // Vietnamese words there. Rendering them raw put "Công cụ · Windows · Phát hành 1.5.0"
  // at the top of the English page. These map the values the shop actually uses; an
  // unknown one still renders as written rather than disappearing.
  categories: { "Công cụ": "Công cụ", "Tiện ích": "Tiện ích", "Phần mềm": "Phần mềm", "Khác": "Khác" },
  badges: { "Mới": "Mới", "Bán chạy": "Bán chạy", "Cập nhật": "Cập nhật", "Phát hành": "Phát hành", "Phổ biến": "Phổ biến", "Chuyên nghiệp": "Chuyên nghiệp", "Tiết kiệm": "Tiết kiệm", "Doanh nghiệp": "Doanh nghiệp", "Ưu đãi sớm": "Ưu đãi sớm", "Safe Edition v4.3": "Safe Edition v4.3", "Phát hành 1.5.0": "Phát hành 1.5.0" },
  // The verification block. What it links to is what the claim rests on, so every
  // line here points at something a stranger can open and check: an independent
  // antivirus scan, and the build report of the shop selling the file. Neither
  // says the software is safe — that is not a thing a page can assert — they give
  // the reader the evidence to form their own answer, which is the only version of
  // a trust claim that survives being checked.
  trustHeading: "Kiểm chứng",
  trustScan: "Quét virus độc lập (VirusTotal)",
  trustScanNote: "Chạy bởi hãng thứ ba, không phải bởi shop. Bấm để xem đúng file bạn tải về đã được bao nhiêu công cụ quét, và bao nhiêu báo phát hiện.",
  trustBuild: "Báo cáo build của shop",
  trustBuildNote: "Commit, phiên bản Node, danh sách mọi file và mọi thư viện của trang bán hàng này, kèm mã băm SHA-256. Cái này mô tả shop, không mô tả phần mềm bạn mua.",
  fileSizeLabel: "Kích thước tệp tải về",
  buyNow: "Mua ngay",
  buyNote: "Giấy phép vĩnh viễn, không phí thuê bao. Thanh toán chuyển khoản hoặc PayPal.",
  // The footer on the link-preview card. It was written into the SVG template in
  // Vietnamese, so the one card an English page can hand a crawler was the one
  // page on the site that ignored the language it was rendered for.
  ogFooter: "Giấy phép vĩnh viễn · Tải ngay sau khi thanh toán",
  pointDownload: "Tải ngay sau khi thanh toán",
  pointLookup: "Mã tra cứu gửi qua email",
  pointRefund: "Hoàn tiền nếu file lỗi",
  features: "Tính năng",
  aiSummary: "Tóm tắt bằng AI",
  aiGenerated: "AI tạo",
  aiDisclaimer: "Tóm tắt do AI tạo, có thể chưa đầy đủ. Kiểm chứng và đọc bài viết đầy đủ bên dưới.",
  requirements: "Yêu cầu hệ thống",
  faqHeading: "Câu hỏi thường gặp",
  reviewsHeading: "Khách đã dùng",
  anonymous: "Khách hàng",
  related: "Sản phẩm khác",
  loading: "Đang tải…",
  terms: "Điều khoản",
  refund: "Hoàn tiền",
  privacy: "Bảo mật",
  disclaimerHeading: "Thông báo pháp lý",
  trademarkNote: "SonVuDev là nhà phát triển độc lập. Không liên kết với, được xác nhận bởi, hoặc được tài trợ bởi Microsoft. Windows, Excel và .NET là nhãn hiệu của Microsoft Corporation.",
};

export const COPY_EN = {
  home: "Home",
  tagline: "Good software for good work",
  products: "Products",
  faqNav: "FAQ",
  about: "About",
  lookup: "Order lookup",
  contact: "Contact",
  status: "Status",
  breadcrumbLabel: "Breadcrumb",
  software: "Software",
  // The Vietnamese values, translated. See the note on COPY_VI: the category and
  // badge are free-text columns written in one language and rendered in both.
  // The category list lives in src/lib/categories.mjs, because the catalogue's
  // raw values have to be mapped onto it in more than one place — here, and in
  // the store that reads the catalogue.
  categories: CATEGORY_EN,
  badges: { "Mới": "New", "Bán chạy": "Best seller", "Cập nhật": "Updated", "Phát hành": "Release", "Phổ biến": "Popular", "Chuyên nghiệp": "Professional", "Tiết kiệm": "Value", "Doanh nghiệp": "Enterprise", "Ưu đãi sớm": "Early Bird", "Safe Edition v4.3": "Safe Edition v4.3", "Phát hành 1.5.0": "Release 1.5.0" },
  trustHeading: "Verification",
  trustScan: "Independent antivirus scan (VirusTotal)",
  trustScanNote: "Run by a third party, not by this shop. Open it to see how many engines scanned the exact file you download, and how many flagged it.",
  trustBuild: "This shop's build report",
  trustBuildNote: "Commit, Node version, every shipped file and every dependency of this storefront, with SHA-256 digests. That describes the shop, not the software you are buying.",
  fileSizeLabel: "Download file size",
  buyNow: "Buy now",
  buyNote: "One-time licence, no subscription. Pay by bank transfer or PayPal.",
  ogFooter: "One-time licence · Download immediately after payment",
  pointDownload: "Download immediately after payment",
  pointLookup: "Lookup code sent by email",
  pointRefund: "Refunded if the file is broken",
  features: "Features",
  aiSummary: "AI summary",
  aiGenerated: "AI-generated",
  aiDisclaimer: "AI-generated summary. It may be incomplete — verify and read the full article below.",
  requirements: "System requirements",
  faqHeading: "Frequently asked questions",
  reviewsHeading: "What customers say",
  anonymous: "Customer",
  related: "Other products",
  loading: "Loading…",
  terms: "Terms",
  refund: "Refunds",
  privacy: "Privacy",
  disclaimerHeading: "Legal Disclaimer",
  trademarkNote: "SonVuDev is an independent developer. Not affiliated with, endorsed by, or sponsored by Microsoft. Windows, Excel and .NET are trademarks of Microsoft Corporation.",
};

// The chrome for the five on-demand locales. The scalar strings live here;
// the category/badge tables do NOT — those translations already exist in the
// per-locale assets (product.label.category.* / product.label.badge.*) and
// getCopy() overlays them at render time, so each wording has exactly one
// home. Anything missing from the asset falls back to the English label.
const COPY_DE = {
  home: "Startseite",
  tagline: "Gute Software für gute Arbeit",
  products: "Produkte",
  faqNav: "FAQ",
  about: "Über uns",
  lookup: "Bestellung nachschlagen",
  contact: "Kontakt",
  breadcrumbLabel: "Brotkrümelnavigation",
  software: "Software",
  trustHeading: "Prüfung",
  trustScan: "Unabhängiger Virenscan (VirusTotal)",
  trustScanNote: "Wird von einem Dritten ausgeführt, nicht von diesem Shop. Öffnen Sie die Seite, um zu sehen, wie viele Engines die exakte Datei gescannt haben, die Sie herunterladen, und wie viele sie markiert haben.",
  trustBuild: "Build-Bericht dieses Shops",
  trustBuildNote: "Commit, Node-Version, jede ausgelieferte Datei und jede Abhängigkeit dieses Shops, mit SHA-256. Das beschreibt den Shop, nicht die Software, die Sie kaufen.",
  fileSizeLabel: "Größe der Download-Datei",
  buyNow: "Jetzt kaufen",
  buyNote: "Dauerhafte Lizenz, kein Abo. Zahlung per Überweisung oder PayPal.",
  ogFooter: "Einmalige Lizenz · Sofortiger Download nach Zahlung",
  pointDownload: "Sofortiger Download nach Zahlung",
  pointLookup: "Nachschlagecode per E-Mail",
  pointRefund: "Erstattung bei defekter Datei",
  features: "Funktionen",
  requirements: "Systemanforderungen",
  faqHeading: "Häufige Fragen",
  reviewsHeading: "Was Kunden sagen",
  anonymous: "Kunde",
  related: "Weitere Produkte",
  loading: "Wird geladen…",
  terms: "AGB",
  refund: "Erstattung",
  privacy: "Datenschutz",
  disclaimerHeading: "Rechtlicher Hinweis",
  trademarkNote: "SonVuDev ist ein unabhängiger Entwickler. Nicht mit Microsoft verbunden, von Microsoft unterstützt oder gesponsert. Windows, Excel und .NET sind Marken der Microsoft Corporation.",
  nav: { contactEmail: "Support-E-Mail" },
  contact: {
    h1: "Kontakt",
    lede: "Jede Frage zu Bestellungen, Erstattungen oder vor dem Kauf wird direkt vom Entwickler beantwortet. Keine Chatbots, keine Weiterleitungen.",
    h2: "Kontaktinformationen",
    email: "Support-E-Mail",
    emailNote: "Antworten innerhalb von 24 Geschäftsstunden. Bitte Bestellnummer angeben, falls vorhanden.",
    phone: "Telefon",
    phoneNote: "Geschäftszeiten: Mo–Fr, 9:00–18:00 (GMT+7).",
    address: "Adresse",
    h3: "Bestell-Support",
    li1: "Bestell-Nachschlagen: /lookup — Bestellcode und E-Mail eingeben, um Status anzuzeigen, Download-Link neu zu generieren.",
    li2: "Erstattungen: Richtlinie unter /refund. Defekte Dateien oder versehentliche Käufe werden innerhalb von 14 Tagen unterstützt.",
    li3: "Zahlung: Inlandsüberweisung (Vietcombank), PayPal (international), MoMo, ZaloPay.",
    li4: "Rechnung: Elektronische Rechnung wird automatisch nach erfolgreicher Zahlung ausgestellt.",
    h4: "Bevor Sie uns kontaktieren",
    li5: "Spam-/Junk-Ordner prüfen — Bestellcodes und Download-Links werden manchmal gefiltert.",
    li6: "Stellen Sie sicher, dass Excel/Office vollständig geschlossen ist, bevor Sie das Trusted Locations Reparatur-Tool ausführen.",
    li7: "FAQ und About-Seite lesen — die Antwort steht oft schon dort.",
    h5: "Rechtliches",
    legal: "SonVuDev ist der Handelsname von Vũ Trung Sơn. Keine Firma, keine Agenten, keine Mitarbeiter. Alle Transaktionen werden persönlich vom Inhaber abgewickelt.",
  },
  title: { contact: "Kontakt — {brand}" },
};

const COPY_ES = {
  home: "Inicio",
  tagline: "Buen software para un buen trabajo",
  products: "Productos",
  faqNav: "Preguntas",
  about: "Sobre nosotros",
  lookup: "Buscar pedido",
  contact: "Contacto",
  breadcrumbLabel: "Migas de pan",
  software: "Software",
  trustHeading: "Verificación",
  trustScan: "Análisis antivirus independiente (VirusTotal)",
  trustScanNote: "Lo ejecuta un tercero, no esta tienda. Ábralo para ver cuántos motores analizaron el archivo exacto que descarga y cuántos lo marcaron.",
  trustBuild: "Informe de build de esta tienda",
  trustBuildNote: "Commit, versión de Node, cada archivo distribuido y cada dependencia de esta tienda, con SHA-256. Describe la tienda, no el software que compra.",
  fileSizeLabel: "Tamaño del archivo de descarga",
  buyNow: "Comprar ahora",
  buyNote: "Licencia permanente, sin suscripción. Pague por transferencia o PayPal.",
  ogFooter: "Licencia permanente · Descarga inmediata tras el pago",
  pointDownload: "Descarga inmediata tras el pago",
  pointLookup: "Código de consulta enviado por correo",
  pointRefund: "Reembolso si el archivo está dañado",
  features: "Funciones",
  requirements: "Requisitos del sistema",
  faqHeading: "Preguntas frecuentes",
  reviewsHeading: "Lo que dicen los clientes",
  anonymous: "Cliente",
  related: "Otros productos",
  loading: "Cargando…",
  terms: "Términos",
  refund: "Reembolso",
  privacy: "Privacidad",
  disclaimerHeading: "Aviso legal",
  trademarkNote: "SonVuDev es un desarrollador independiente. No está afiliado, respaldado ni patrocinado por Microsoft. Windows, Excel y .NET son marcas comerciales de Microsoft Corporation.",
  nav: { contactEmail: "Email de soporte" },
  contact: {
    h1: "Contacto",
    lede: "Todas las preguntas sobre pedidos, reembolsos o pre-venta son respondidas directamente por el desarrollador. Sin chatbots, sin transferencias.",
    h2: "Información de contacto",
    email: "Email de soporte",
    emailNote: "Respuestas en 24 horas hábiles. Incluya su código de pedido si tiene uno.",
    phone: "Teléfono",
    phoneNote: "Horario de atención: Lun–Vie, 9:00–18:00 (GMT+7).",
    address: "Dirección",
    h3: "Soporte de pedidos",
    li1: "Búsqueda de pedidos: /lookup — introduzca el código de pedido y el email para ver el estado, regenerar enlace de descarga.",
    li2: "Reembolsos: Ver política en /refund. Archivos rotos o compras accidentales soportados dentro de 14 días.",
    li3: "Pago: Transferencia bancaria nacional (Vietcombank), PayPal (internacional), MoMo, ZaloPay.",
    li4: "Factura: Factura electrónica emitida automáticamente tras el pago exitoso.",
    h4: "Antes de contactarnos",
    li5: "Revise la carpeta Spam/Junk — los códigos de pedido y enlaces de descarga a veces se filtran.",
    li6: "Asegúrese de que Excel/Office esté completamente cerrado antes de ejecutar la herramienta de reparación de Trusted Locations.",
    li7: "Revise la FAQ y la página About — la respuesta a menudo ya está ahí.",
    h5: "Legal",
    legal: "SonVuDev es el nombre comercial de Vũ Trung Sơn. No es una empresa, no hay agentes, no hay empleados. Todas las transacciones son gestionadas personalmente por el propietario.",
  },
  title: { contact: "Contacto — {brand}" },
};

const COPY_FR = {
  home: "Accueil",
  tagline: "Un bon logiciel pour un bon travail",
  products: "Produits",
  faqNav: "FAQ",
  about: "À propos",
  lookup: "Suivi de commande",
  contact: "Contact",
  breadcrumbLabel: "Fil d'Ariane",
  software: "Logiciel",
  trustHeading: "Vérification",
  trustScan: "Analyse antivirus indépendante (VirusTotal)",
  trustScanNote: "Réalisée par un tiers, pas par cette boutique. Ouvrez-la pour voir combien de moteurs ont analysé le fichier exact que vous téléchargez, et combien l'ont signalé.",
  trustBuild: "Rapport de build de cette boutique",
  trustBuildNote: "Commit, version de Node, chaque fichier livré et chaque dépendance de cette boutique, avec SHA-256. Cela décrit la boutique, pas le logiciel que vous achetez.",
  fileSizeLabel: "Taille du fichier téléchargé",
  buyNow: "Acheter",
  buyNote: "Licence permanente, sans abonnement. Paiement par virement ou PayPal.",
  ogFooter: "Licence permanente · Téléchargement immédiat après paiement",
  pointDownload: "Téléchargement immédiat après paiement",
  pointLookup: "Code de suivi envoyé par e-mail",
  pointRefund: "Remboursé si le fichier est défectueux",
  features: "Fonctionnalités",
  requirements: "Configuration requise",
  faqHeading: "Questions fréquentes",
  reviewsHeading: "Avis clients",
  anonymous: "Client",
  related: "Autres produits",
  loading: "Chargement…",
  terms: "Conditions",
  refund: "Remboursement",
  privacy: "Confidentialité",
  disclaimerHeading: "Avertissement légal",
  trademarkNote: "SonVuDev est un développeur indépendant. Non affilié, approuvé ou sponsorisé par Microsoft. Windows, Excel et .NET sont des marques de Microsoft Corporation.",
  nav: { contactEmail: "Email de support" },
  contact: {
    h1: "Contact",
    lede: "Toutes les questions sur les commandes, les remboursements ou la pré-vente sont répondues directement par le développeur. Pas de chatbots, pas de transfert.",
    h2: "Informations de contact",
    email: "Email de support",
    emailNote: "Réponses sous 24 heures ouvrées. Veuillez inclure votre code de commande si vous en avez un.",
    phone: "Téléphone",
    phoneNote: "Heures d'ouverture : Lun–Ven, 9:00–18:00 (GMT+7).",
    address: "Adresse",
    h3: "Support commande",
    li1: "Recherche de commande : /lookup — saisissez le code de commande et l'email pour voir le statut, régénérer le lien de téléchargement.",
    li2: "Remboursements : Voir la politique sur /refund. Fichiers corrompus ou achats accidentels pris en charge sous 14 jours.",
    li3: "Paiement : Virement bancaire national (Vietcombank), PayPal (international), MoMo, ZaloPay.",
    li4: "Facture : Facture électronique émise automatiquement après paiement réussi.",
    h4: "Avant de nous contacter",
    li5: "Vérifiez le dossier Spam/Courrier indésirable — les codes de commande et liens de téléchargement sont parfois filtrés.",
    li6: "Assurez-vous qu'Excel/Office est complètement fermé avant d'exécuter l'outil de réparation Trusted Locations.",
    li7: "Consultez la FAQ et la page À propos — la réponse s'y trouve souvent.",
    h5: "Mentions légales",
    legal: "SonVuDev est le nom commercial de Vũ Trung Sơn. Pas une entreprise, pas d'agents, pas d'employés. Toutes les transactions sont gérées personnellement par le propriétaire.",
  },
  title: { contact: "Contact — {brand}" },
};

const COPY_JA = {
  home: "ホーム",
  tagline: "良い仕事のための良いソフトウェア",
  products: "製品",
  faqNav: "よくある質問",
  about: "私たちについて",
  lookup: "注文を検索",
  contact: "お問い合わせ",
  breadcrumbLabel: "パンくずリスト",
  software: "ソフトウェア",
  trustHeading: "検証",
  trustScan: "独立したウイルススキャン（VirusTotal）",
  trustScanNote: "このショップではなく第三者が実施します。開くと、ダウンロードする正確なファイルをスキャンしたエンジン数と、それを検出したエンジン数を確認できます。",
  trustBuild: "このショップのビルドレポート",
  trustBuildNote: "コミット、Node バージョン、配布する全ファイルと依存関係を SHA-256 で示したもの。これはショップを説明するもので、購入するソフトウェアを説明するものではありません。",
  fileSizeLabel: "ダウンロードファイルのサイズ",
  buyNow: "今すぐ購入",
  buyNote: "買い切りライセンス、サブスクリプションなし。銀行振込または PayPal でお支払いください。",
  ogFooter: "買い切りライセンス · お支払い後すぐにダウンロード",
  pointDownload: "お支払い後すぐにダウンロード",
  pointLookup: "照会コードをメールでお送りします",
  pointRefund: "ファイルが破損している場合は返金",
  features: "機能",
  requirements: "動作環境",
  faqHeading: "よくあるご質問",
  reviewsHeading: "お客様の声",
  anonymous: "顧客",
  related: "その他の製品",
  loading: "読み込み中…",
  terms: "利用規約",
  refund: "返金",
  privacy: "プライバシー",
  disclaimerHeading: "法的免責事項",
  trademarkNote: "SonVuDev は独立した開発者です。Microsoft と提携、承認、後援されていません。Windows、Excel、.NET は Microsoft Corporation の商標です。",
  nav: { contactEmail: "サポートメール" },
  contact: {
    h1: "お問い合わせ",
    lede: "注文、返金、購入前の質問すべてに開発者が直接お答えします。チャットボットなし、たらい回しなし。",
    h2: "連絡先情報",
    email: "サポートメール",
    emailNote: "営業時間内24時間以内に返信。ご注文コードがあれば併記してください。",
    phone: "電話",
    phoneNote: "営業時間：月〜金、9:00〜18:00 (GMT+7)。",
    address: "住所",
    h3: "注文サポート",
    li1: "注文検索: /lookup — 注文コードとメールアドレスを入力してステータス確認、ダウンロードリンク再生成。",
    li2: "返金: /refund のポリシーを参照。ファイル破損や誤購入は 14 日以内に対応。",
    li3: "支払い: 国内銀行振込 (Vietcombank)、PayPal (海外)、MoMo、ZaloPay。",
    li4: "請求書: 支払い成功後に電子請求書を自動発行。",
    h4: "お問い合わせ前に",
    li5: "迷惑メールフォルダを確認 — 注文コードとダウンロードリンクがフィルタされることがあります。",
    li6: "Trusted Locations 修復ツールを実行する前に、Excel/Office が完全に終了していることを確認してください。",
    li7: "FAQ と About ページを確認 — 答えがすでにあることが多いです。",
    h5: "法的事項",
    legal: "SonVuDev は Vũ Trung Sơn の商標名です。会社ではなく、代理店も従業員もいません。すべての取引はオーナーが個人的に処理し責任を負います。",
  },
  title: { contact: "お問い合わせ — {brand}" },
};

const COPY_ZH = {
  home: "首页",
  tagline: "好工具，好工作",
  products: "产品",
  faqNav: "常见问题",
  about: "关于我们",
  lookup: "查询订单",
  contact: "联系",
  breadcrumbLabel: "面包屑导航",
  software: "软件",
  trustHeading: "验证",
  trustScan: "独立病毒扫描（VirusTotal）",
  trustScanNote: "由第三方执行，而非本商店。打开后可查看多少引擎扫描了您要下载的确切文件、多少引擎将其标记。",
  trustBuild: "本商店的构建报告",
  trustBuildNote: "提交、Node 版本、本商店发布的每一个文件和依赖项，附 SHA-256。这描述的是商店，不是您购买的软件。",
  fileSizeLabel: "下载文件大小",
  buyNow: "立即购买",
  buyNote: "永久授权，无订阅。可通过银行转账或 PayPal 付款。",
  ogFooter: "永久授权 · 付款后立即下载",
  pointDownload: "付款后立即下载",
  pointLookup: "查询代码已发送至您的邮箱",
  pointRefund: "文件损坏可退款",
  features: "功能",
  requirements: "系统要求",
  faqHeading: "常见问题",
  reviewsHeading: "客户评价",
  anonymous: "客户",
  related: "其他产品",
  loading: "加载中…",
  terms: "条款",
  refund: "退款",
  privacy: "隐私",
  disclaimerHeading: "法律声明",
  trademarkNote: "SonVuDev 是独立开发者。与 Microsoft 无关联、未获 Microsoft 认可或赞助。Windows、Excel 和 .NET 是 Microsoft Corporation 的商标。",
  nav: { contactEmail: "支持邮箱" },
  contact: {
    h1: "联系我们",
    lede: "关于订单、退款或售前咨询的所有问题，均由开发者直接解答。无聊天机器人，无推诿。",
    h2: "联系信息",
    email: "支持邮箱",
    emailNote: "24 个工作小时内回复。如有订单号请附上。",
    phone: "电话",
    phoneNote: "工作时间：周一至周五，9:00-18:00 (GMT+7)。",
    address: "地址",
    h3: "订单支持",
    li1: "订单查询: /lookup — 输入订单号和邮箱查看状态，重新生成下载链接。",
    li2: "退款: 查看 /refund 政策。文件损坏或误购可在 14 天内处理。",
    li3: "支付: 国内银行转账 (Vietcombank)、PayPal (国际)、MoMo、ZaloPay。",
    li4: "发票: 支付成功后自动开具电子发票。",
    h4: "联系我们前",
    li5: "检查垃圾箱 — 订单号和下载链接有时会被拦截。",
    li6: "运行 Trusted Locations 修复工具前，请确保 Excel/Office 已完全关闭。",
    li7: "查看 FAQ 和关于页面 — 答案通常已在那里。",
    h5: "法律声明",
    legal: "SonVuDev 是 Vũ Trung Sơn 的商标名。非公司，无代理，无员工。所有交易由所有者亲自处理并负责。",
  },
  title: { contact: "联系我们 — {brand}" },
};

const SCALAR_COPY = { vi: COPY_VI, en: COPY_EN, de: COPY_DE, es: COPY_ES, fr: COPY_FR, ja: COPY_JA, "zh-CN": COPY_ZH };

/** Returns the copy table for the given language. */
function getCopy(lang) {
  const base = SCALAR_COPY[lang] || COPY_EN;
  if (lang === "vi" || lang === "en") return base;
  const json = loadLocaleJson(lang);
  return {
    ...base,
    categories: overlayLabels(json, "category", COPY_VI.categories),
    badges: overlayLabels(json, "badge", COPY_VI.badges),
  };
}

/** Splits the long form description on the === heading === markers. */function sections(description) {
  const parts = String(description || "").split(/\n={3,}\n?/);
  if (parts.length > 1) {
    const [head, ...rest] = parts;
    return { intro: head.trim(), groups: rest.map((item) => item.trim()).filter(Boolean) };
  }
  return { intro: String(description || "").trim(), groups: [] };
}

const paragraphBlocks = (text) => String(text || "").split(/\n{2,}/).map((block) => block.trim()).filter(Boolean)
  .map((block) => {
    if (block.startsWith("===") && block.endsWith("===")) return `<h3>${esc(block.replace(/=/g, "").trim())}</h3>`;
    if (block.startsWith("- ")) {
      return `<ul>${block.split("\n").filter((line) => line.trim().startsWith("- ")).map((line) => `<li>${esc(line.replace(/^-\s*/, "").trim())}</li>`).join("")}</ul>`;
    }
    if (/^\d+\.\s/.test(block)) {
      return `<ol>${block.split("\n").filter((line) => /^\d+\.\s/.test(line.trim())).map((line) => `<li>${esc(line.replace(/^\d+\.\s*/, "").trim())}</li>`).join("")}</ol>`;
    }
    return `<p>${esc(block).replace(/\n/g, "<br>")}</p>`;
  }).join("\n");

/**
 * Swaps in the English copy when there is any, and falls back to the Vietnamese
 * per field rather than per product.
 *
 * A product translated half way must still render a complete page: falling back
 * field by field means a partially translated product is readable in both
 * languages, whereas falling back per product would show an English page full of
 * Vietnamese.
 */
/**
 * Strips hardcoded VND price strings from product copy.
 *
 * The price is rendered from structured data and the price component, so a
 * sentence that repeats "199.000đ" or "299,000 ₫" is not copy — it is a
 * feed-integrity hazard. A page whose text says one currency and whose
 * JSON-LD says another is flagged by Google's crawler as mismatched data.
 * This removes those price tokens from every field that passes through
 * localize(), leaving the surrounding prose intact.
 */
// No trailing \b on this pattern: JavaScript's \b is an ASCII word boundary,
// and both "đ" and "₫" are non-ASCII, so the old pattern never matched
// "199.000đ" — the exact form this catalogue uses. The currency word is matched
// explicitly, with "đồng" before "đ" so the longer form is removed whole.
const VND_PRICE_RE = /\b\d{1,3}(?:[.,]\d{3})+\s*(?:đồng|đ|₫|VND)|\b\d+k\s*(?:VND|đồng|đ|₫)/gi;
const stripPrices = (text) => String(text || "").replace(VND_PRICE_RE, "").replace(/\s+/g, " ").trim();

/**
 * Removes promotional or price-carrying sentences from a text block.
 *
 * A sentence is anything separated by terminal punctuation (`.`, `!`, `?`)
 * followed by whitespace. Sentences that carry a price, a discount, a
 * deadline or a call to action are dropped whole — a partial rewrite leaves
 * the grammar broken ("all features for instead of .").
 *
 * Used by the machine-readable catalogue (`/feed.json`, `/llms.txt`) so the
 * data a crawler reads carries the same amount of promotional noise as the
 * page's `Product`/`Offer` schema, and by nothing else.
 */
const stripPromotionalSentences = (text) => {
  const trimmed = String(text ?? "").replace(/\s+/g, " ").trim();
  if (!trimmed) return trimmed;
  const kept = trimmed
    .split(/(?<=[.!?])\s+/)
    .filter((sentence) => !PROMO_IN_TEXT.test(sentence))
    .join(" ")
    .trim();
  return kept;
};

/**
 * The catalogue's non-vi/en languages: overlay the translated asset on top of
 * the English columns, field by field.
 *
 * The per-locale asset (public/locales/<lang>.json, the same one the browser
 * loads) carries `product.copy.<slug>.<field>` with the full product copy —
 * name, descriptions, requirements and the feature list. Before this, every
 * non-vi page fell back to the English columns, so a French reader selecting
 * French got English text under a French heading. The chain is now:
 *   locale asset -> English column -> Vietnamese source
 * and Vietnamese keeps the catalogue's own rows, unmediated.
 */
function localizeForLang(product, lang) {
  const en = localizeToEnglish(product);
  if (lang === "en") return en;
  const slug = String(product.slug || product.id || "").trim();
  if (!slug) return en;
  const json = loadLocaleJson(lang);
  if (!json) return en;
  const read = (field) => {
    const value = json[`product.copy.${slug}.${field}`];
    return typeof value === "string" && value.trim() ? value : undefined;
  };
  const readList = (field) => {
    const value = json[`product.copy.${slug}.${field}`];
    return Array.isArray(value) ? value.filter((item) => String(item || "").trim()) : undefined;
  };
  const overlaid = {
    name: read("name"),
    shortDescription: read("shortDescription"),
    description: read("description"),
    requirements: read("requirements"),
    features: readList("features"),
  };
  const defined = Object.fromEntries(Object.entries(overlaid).filter(([, value]) => value !== undefined));
  return Object.keys(defined).length ? { ...en, ...defined } : en;
}

export function localize(product, lang) {
  if (!product) return product;
  // Vietnamese is the catalogue's source language. Every other supported locale
  // gets the per-locale asset overlaid on the English columns (see above), so a
  // French reader never sees raw Vietnamese (or silently English) product text
  // under a translated page heading when a translation exists.
  const resolved = lang === "vi" ? product : localizeForLang(product, lang);
  // Placeholders are filled after the language is chosen, so the same stored text
  // carries the owner's name in both. Filling them first would put the name into
  // whatever was picked as the fallback, and the English page would then show a
  // Vietnamese sentence with an English name in it.
  return {
    ...resolved,
    shortDescription: stripPrices(fillCopy(resolved.shortDescription)),
    description: stripPrices(fillCopy(resolved.description)),
    features: (resolved.features || []).map((f) => stripPrices(fillCopy(f))),
  };
}

/** Chooses the English text where it exists and the Vietnamese where it does not. */
function localizeToEnglish(product) {
  const pick = (en, vi) => (String(en || "").trim() ? en : vi);
  const featuresEn = Array.isArray(product.featuresEn) ? product.featuresEn.filter((item) => String(item || "").trim()) : [];
  return {
    ...product,
    shortDescription: pick(product.shortDescriptionEn, product.shortDescription),
    description: pick(product.descriptionEn, product.description),
    // System requirements are the one field a buyer must be able to check before
    // paying, and the old fallback answered it with "the guide is written in
    // Vietnamese" — a sentence that tells an English reader nothing. The stored
    // requirements are a technical spec (platform names, versions, architecture),
    // so showing them untranslated is more useful than showing a refusal; the
    // platform column is the last resort when the spec itself is empty.
    requirements: pick(product.requirementsEn, String(product.requirements || "").trim() || product.platform || ""),
    features: featuresEn.length ? featuresEn : product.features,
    // SEO copy is the one pair that does NOT fall back to Vietnamese.
    //
    // Everything else falls back because missing English is better than a hole.
    // Here the fallback is a page that serves Vietnamese words in its <title> and
    // meta description, on a URL declared as the English alternative of the
    // Vietnamese one — two hreflang pages with identical metadata, which reads as
    // duplicate content rather than as a translation, and puts a Vietnamese search
    // result in front of an English-language query. A derived title from the English
    // product name is worse copy and better markup, so that is what it falls back to.
    seoTitle: pick(product.seoTitleEn, ""),
    seoDescription: pick(product.seoDescriptionEn, ""),
  };
}

/**
 * Looks a free-text product field up in the dictionary for the current language.
 *
 * `category` and `badge` are free-text columns. They are written once, in whichever
 * language the owner was typing in, and the shop has two languages — so rendering
 * them raw put a Vietnamese eyebrow at the top of every English product page:
 * "Công cụ · Windows · Phát hành 1.5.0" on a URL declared as the English alternative
 * of the Vietnamese one. A dictionary entry cannot fix that on its own, because the
 * owner can type anything into those columns; the map below covers the values the
 * shop actually uses and this is what decides what happens to the rest.
 *
 * An unknown value is returned unchanged rather than dropped. A new category the owner
 * invented should appear on both pages, in one language, rather than leave a hole —
 * the reader can still see what it is, and the alternative is an empty eyebrow.
 *
 * @param {unknown} value the raw column value
 * @param {Record<string, string>|undefined} map dictionary for the current language
 * @param {string} [fallback] used when the column is empty
 * @returns {string}
 */
export const localised = (value, map, fallback = "") => {
  const raw = String(value ?? "").trim();
  if (!raw) return fallback;
  if (map && Object.prototype.hasOwnProperty.call(map, raw)) return map[raw];
  // A catalogue row typed without diacritics ("Phat hanh 1.5.0") is the same word
  // as the dictionary key ("Phát hành 1.5.0"). Exact lookup alone left the raw
  // column text on screen, so the reader saw an unaccented label next to a fully
  // accented Vietnamese page. Folding both sides matches it without editing data
  // that was created years ago and may live in a database we do not control.
  const fold = (text) => String(text).toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();
  const foldedRaw = fold(raw);
  for (const [key, translated] of Object.entries(map || {})) {
    if (fold(key) === foldedRaw) return translated;
  }
  return raw;
};

/**
 * The full product page. It is deliberately standalone HTML: no JavaScript is
 * required to read the whole thing, and the only script on the page opens the
 * existing checkout modal on the storefront rather than duplicating it.
 *
 * The same renderer serves both languages. The page was Vietnamese-only on the
 * server even though the English copy had been sitting in the database all along
 * and the browser already used it, which meant an assistant asked in English
 * found a page it could only cite in translation.
 *
 * The price printed here is always the shelf price in the product's own
 * currency. The renderer used to take a converted USD amount for the English
 * page, which made the figure depend on a live exchange rate and on the crawl
 * time — the two things a price must never depend on. Conversion now happens
 * only at checkout, where the buyer sees the exact charge before confirming.
 */
export function renderProductPage(rawProduct, lang = "vi", reviews = [], related = []) {
  const product = localize(rawProduct, lang);
  const url = absolute(productUrl(product.slug, lang));
  const { intro, groups } = sections(product.description);
  const features = product.features || [];
  const copy = getCopy(lang);
  // Prefix for locale-aware chrome links (brand + home). Vietnamese is the root.
  const homePrefix = localePrefix(lang);
  const homeUrl = homePrefix ? `${homePrefix}/` : "/";
  // The shelf price is stated in the product's own currency on the Vietnamese
  // page. For any other language the price is converted to USD so a foreign
  // reader sees the amount in the currency they expect to pay in.
  const usdRate = () => {
    const raw = env.paypal.vndToUsdRate;
    if (raw === "live" || raw === "auto" || raw === "true" || raw === "1") return 26000;
    const n = Number(raw);
    return Number.isFinite(n) && n > 0 ? n : 26000;
  };
  // Non-vi pages render the USD-converted price so a foreign reader sees the
  // amount in the currency they expect to pay in. VND shelf price never moves.
  const priceLabel = lang !== "vi" && product.currency === "VND"
    ? money(Number(product.price) / usdRate(), "USD")
    : money(product.price, product.currency);
  // The headline leads with what someone types into a search box, not with the
  // product's own name, which nobody outside this site has heard of. The two are
  // the same sentence read differently: "bật macro Excel" is the problem, "Excel
  // Trusted Locations Setup" is the thing that solves it.
  //
  // One shape for both languages, and the language enters through productSummary
  // and the copy table below. The ternary that used to sit here had an identical
  // arm on each side — an editor had edited one and not the other, and a page that
  // looked localized was emitting the same title twice.
  // The owner's SEO title is used only when it is safe as product data. A title
  // that carries a price, a discount or a deadline is discarded rather than
  // rewritten, because Merchant Center reads this string as the product name when
  // it cannot find a Product node — and a product name is not a sale banner.
  const title = cleanSeoText(product.seoTitle)
    || `${product.name} v${product.version} — ${product.platform || "Windows"} | ${brand()}`;
  const description = metaDescriptionFor(product, lang);
  const faq = faqSchema(product, lang);
  // The header below closes the brand link before the navigation.
  //
  // It did not, and the cost was not visible in the markup: the HTML parser
  // cannot have a link inside a link, so when it met the navigation's first
  // link it ran the adoption agency algorithm and **re-created the brand link
  // empty inside the nav**. The page ended up with two brand links, one of
  // them empty and with no name at all — which is what axe reported as "Links
  // do not have a discernible name" and what Lighthouse's agentic-browsing check
  // reports as a malformed accessibility tree. A screen reader and an agent
  // both get a nameless link.
  //
  // Nothing about the missing tag looks wrong in the source, which is why it
  // survived every gate until something that reads the rendered DOM looked at
  // it. The product-page test now reads the parsed page.

  return inlineStyles(`<!doctype html>
<html lang="${esc(SCHEMA_LANG[lang] || lang)}">
<head>
${tokenMeta()}
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
${meta({ title, description, url, type: "product", lang, image: productImage(product), alternates: Object.fromEntries(LOCALE_CODES.map((code) => [code, absolute(productUrl(product.slug, code))])) })}
<link rel="preload" as="font" type="font/woff2" href="${assetUrl('/fonts/be-vietnam-pro-latin.woff2')}" crossorigin>
<link rel="preload" as="font" type="font/woff2" href="${assetUrl('/fonts/be-vietnam-pro-vietnamese.woff2')}" crossorigin>
<link rel="preload" as="font" type="font/woff2" href="${assetUrl('/fonts/space-grotesk-latin.woff2')}" crossorigin>
<link rel="preload" as="font" type="font/woff2" href="${assetUrl('/fonts/space-grotesk-vietnamese.woff2')}" crossorigin>
<link rel="stylesheet" href="${assetUrl('/styles.min.css')}">
${brandMeta()}
${analyticsMeta()}
${jsonLd({ "@graph": [organization(), websiteSchema(), productSchema(product, lang), merchantProductSchema(product, lang), techArticleSchema(product, lang), breadcrumbSchema(product, lang), faq] })}
</head>
<body class="product-page">
<header class="site-header"><a class="brand" href="${homeUrl}">${brandWordmark()}</a>${headerNav("", copy, homePrefix)}<a class="header-cta" href="${homePrefix}/#products"><span>${esc(copy.buyNow)}</span> <span>↗</span></a></header>
<main class="wrap">
<nav class="crumbs" aria-label="${esc(copy.breadcrumbLabel)}"><a href="${homeUrl}">${esc(copy.home)}</a> <span>/</span> <a href="${homePrefix}/#products">${esc(copy.products)}</a> <span>/</span> <span aria-current="page">${esc(product.name)}</span></nav>
<article class="product-detail">
<header class="product-hero">
<div>
<p class="eyebrow">${esc(localised(normaliseCategory(product.category), copy.categories, copy.software))} · ${esc(product.platform || "Windows")}${product.badge ? ` · ${esc(localised(product.badge, copy.badges))}` : ""}</p>
<h1>${esc(product.name)} <em>v${esc(product.version)}</em></h1>
<p class="product-lede">${esc(product.shortDescription || "")}</p>
</div>
<div class="buy-card" id="mua">
<!--
  A div, not an aside.

  A complementary landmark nested inside the banner landmark is two regions
  overlapping, which is what axe's "landmark-complementary-is-top-level"
  reports and what an agent walking the page's landmarks has to untangle. The
  buy card is a purchase panel inside the header, not a region of its own.
-->
<div class="buy-price">${esc(priceLabel)}</div>
<p class="buy-note">${esc(copy.buyNote)}</p>
<a class="button button-primary button-wide buy-btn" href="${homePrefix}/?buy=${encodeURIComponent(product.id)}#products" rel="nofollow" data-buy-id="${esc(product.id)}">${esc(copy.buyNow)} <span>→</span></a>
<ul class="buy-points"><li>${esc(copy.pointDownload)}</li><li>${esc(copy.pointLookup)}</li><li>${esc(copy.pointRefund)}</li></ul>
</div>
</header>
${aiSummaryBlock(product, lang, copy)}
${features.length ? `<section class="detail-block"><h2>${esc(copy.features)}</h2><ul class="feature-grid">${features.map((item) => `<li>${esc(item)}</li>`).join("")}</ul></section>` : ""}
${product.requirements ? `<section class="detail-block"><h2>${esc(copy.requirements)}</h2><p>${esc(product.requirements).replace(/\n/g, "<br>")}</p></section>` : ""}
${(product.fileSize || product.file_size) ? `<section class="detail-block"><h2>${esc(copy.fileSizeLabel)}</h2><p>${esc(formatBytes(product.fileSize || product.file_size))}</p></section>` : ""}
${trustBlock(product, copy)}
${product.disclaimer ? `<section class="detail-block disclaimer"><h2>${esc(copy.disclaimerHeading || 'Thông báo pháp lý')}</h2><p>${esc(product.disclaimer)}</p><p class="trademark-note">${esc(copy.trademarkNote)}</p></section>` : `<section class="detail-block disclaimer"><h2>${esc(copy.disclaimerHeading || 'Thông báo pháp lý')}</h2><p class="trademark-note">${esc(copy.trademarkNote)}</p></section>`}
${intro ? `<section class="detail-block prose">${paragraphBlocks(intro)}</section>` : ""}
${groups.map((group) => `<section class="detail-block prose">${paragraphBlocks(group)}</section>`).join("")}
<section class="detail-block">
<h2>${esc(copy.faqHeading)}</h2>
<dl class="faq-mini">
${faq.mainEntity.map((entry) => `<dt>${esc(entry.name)}</dt><dd>${esc(entry.acceptedAnswer.text)}</dd>`).join("\n")}
</dl>
</section>
${reviews.length ? `<section class="detail-block reviews"><h2>${esc(copy.reviewsHeading)}</h2><ul class="review-list">${reviews.map((review) => `<li><p>${esc(review.body)}</p><small>${esc(review.authorName || copy.anonymous)}</small></li>`).join("")}</ul></section>` : ""}
</article>
${related && related.length ? `<section class="related"><h2>${esc(copy.related)}</h2><div id="related" class="related-grid">${related.map((entry) => `<a class="related-card" href="${esc(absolute(productUrl(entry.slug, lang)))}"><b>${esc(entry.name)}</b><span>v${esc(entry.version)} · ${esc(entry.platform || "Windows")}</span><span>${esc(money(entry.price, entry.currency))}</span></a>`).join("")}</div></section>` : `<section class="related"><h2>${esc(copy.related)}</h2><div id="related" class="related-grid">${esc(copy.loading)}</div></section>`}
</main>
${footerBar("", copy, homePrefix)}
<!-- related-loader: client fallback only; the server renders real cards above -->
<script src="${assetUrl('/format.js')}"></script>
<script src="${assetUrl('/related.js')}" data-self="${esc(product.id)}" data-lang="${esc(lang)}" data-prefix="${esc(homePrefix)}"></script>
<script defer src="${assetUrl('/quality.js')}"></script>
</body>
</html>`);
}

/**
 * A link-preview card. SVG is used because it renders crisply and needs no build
 * step, but it is not what og:image points at: Facebook, Zalo, Telegram, Slack,
 * LinkedIn and most AI answer engines refuse SVG and show nothing. og:image
 * points at the committed raster card instead, and this stays available for the
 * crawlers that do handle SVG.
 *
 * The footer sentence is language-aware for the same reason the page is: the
 * Vietnamese sentence used to be written straight into the template, which made
 * the card the one place on an English page that still spoke Vietnamese.
 *
 * The price line is only drawn when a price is actually known. The shop-wide
 * card passes no price, and money(0) renders "0 ₫" — an invented number, on the
 * card that exists to introduce the shop.
 */
 export function renderOgImage(product, lang = "vi") {
  const name = String(product.name || "");
  const lines = name.length > 34 ? [name.slice(0, 34), name.slice(34, 68)] : [name];
  const copy = getCopy(lang);
  const price = product.price === undefined || product.price === null || product.price === ""
    ? ""
    : `<text x="90" y="556" fill="#ffffff" font-family="Helvetica, Arial, sans-serif" font-size="44" font-weight="600">${esc(money(product.price, product.currency))}</text>`;
  // The platform and version line exists because a product has both. The
  // shop-wide card has neither, and the fallbacks this replaces printed
  // "Windows · v1.0" — an invented platform and an invented version, on the one
  // card that is not about a release at all. A missing line is honest.
  const meta = [product.platform, product.version && `v${product.version}`].filter(Boolean).join(" · ");
  const metaLine = meta
    ? `<text x="90" y="${270 + lines.length * 74 + 26}" fill="#8fd3b2" font-family="Helvetica, Arial, sans-serif" font-size="34">${esc(meta)}</text>`
    : "";
  return `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630" viewBox="0 0 1200 630" role="img" aria-label="${esc(name)}">
<defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#0f2a22"/><stop offset="1" stop-color="#163a2f"/></linearGradient></defs>
<rect width="1200" height="630" fill="url(#bg)"/>
<circle cx="1080" cy="90" r="220" fill="#1d4a3c" opacity="0.55"/>
<text x="90" y="150" fill="#4fbf8b" font-family="Helvetica, Arial, sans-serif" font-size="30" font-weight="600" letter-spacing="5">${esc(brand().toUpperCase())}</text>
 ${lines.map((line, index) => `<text x="90" y="${270 + index * 74}" fill="#ffffff" font-family="Helvetica, Arial, sans-serif" font-size="62" font-weight="700">${esc(line)}</text>`).join("")}
${metaLine}
${price}
<text x="90" y="596" fill="#7fb39c" font-family="Helvetica, Arial, sans-serif" font-size="24">${esc(copy.ogFooter)}</text>
</svg>`;
}

/**
 * /llms.txt — a plain-text index for text agents.
 *
 * The convention is new and optional, so it is cheap: one route, no crawling, no
 * markup. What it buys is that an agent that has been told to prefer machine
 * summaries gets told what this site actually sells and where each thing lives,
 * instead of inferring it from a hero image and a sitemap.
 */
export function renderLlmsTxt(products) {
  const sellable = (products || []).filter(isSellable);
  // Machine-readable endpoints are read by search engines and LLM agents that
  // do not negotiate a language, so the tagline and prices here must be English
  // and currency-neutral. The site-facing copy stays in the user's language.
  const plainPrice = (amount, currency) =>
    currency === "VND" ? `${Number(amount) || 0} VND` : money(amount, currency);
  const lines = [
    `# ${brand()}`,
    "",
    `> Software tools and utilities for businesses and individuals.`,
    "",
    sellable.length
      ? sellable.map((product) => {
          const facts = [
            `${product.platform || "Windows"}`,
            product.version ? `v${product.version}` : "",
            plainPrice(product.price, product.currency),
          ].filter(Boolean).join(" · ");
          return `- [${product.name}](${absolute(productUrl(product.slug))}): ${stripPromotionalSentences(productSummary(product, 120))} (${facts})`;
        }).join("\n")
      : "- The catalogue is empty at the moment.",
    "",
    "## Blog",
    ...(loadBlogPosts().length
      ? loadBlogPosts().map((post) => {
          const title = post.titleEn || post.titleVi || "Untitled";
          const desc = (post.descriptionEn || post.descriptionVi || "").replace(/\s+/g, " ").trim();
          return `- [${title}](/blog/${encodeURIComponent(post.slug)}): ${desc.slice(0, 120)}`;
        })
      : ["- No blog posts yet."]),
    "",
    "## About",
    `- Who: ${env.brand.founderName ? `${env.brand.founderName}${env.brand.legalEntity ? ` (${env.brand.legalEntity})` : ""}` : brand()}`,
    `- Contact: ${env.email.supportEmail}`,
    `- Payments: bank transfer (VietQR, MoMo, ZaloPay) and PayPal, both confirmed automatically`,
    `- Terms: an unpaid order is cancelled after ${env.orders.paymentWindowHours} hours`,
    "",
    "## Pages",
    `- [Homepage](${absolute("/")}) — overview and the full catalogue`,
    `- [Feed (JSON)](${absolute("/feed.json")}) — every product with price, platform and version`,
    `- [Blog (JSON)](${absolute("/blog.json")}) — blog posts`,
    ...(env.brand.socialLinks.length ? [`- [Elsewhere](${env.brand.socialLinks.join(", ")})`] : []),
    "",
  ];
  return lines.join("\n");
}

/**
 * /feed.json — the catalogue as data.
 *
 * An assistant asked "what Windows tools do you sell and what do they cost"
 * would otherwise have to read three product pages to answer it. This is one
 * fetch, it is built from the live catalogue rather than a maintained list, and
 * it costs nothing beyond the route.
 */
export function renderFeed(products) {
  const sellable = (products || []).filter(isSellable);
  const blogPosts = loadBlogPosts();
  const productItems = sellable.map((product, index) => ({
    "@type": "ListItem",
    position: index + 1,
    item: {
      "@type": "SoftwareApplication",
      "@id": absolute(`${productUrl(product.slug)}#software`),
      name: product.name,
      description: stripPromotionalSentences(productSummary(product, 300)) || derivedDescription(product, 300),
      url: absolute(productUrl(product.slug)),
      image: productImage(product),
      brand: { "@type": "Brand", name: brand() },
      ...(cleanSeoText(product.seoTitle) ? { alternateName: cleanSeoText(product.seoTitle) } : {}),
      applicationCategory: product.category || "UtilitiesApplication",
      operatingSystem: product.platform || "Windows",
      softwareVersion: product.version || undefined,
      ...(product.requirements ? { softwareRequirements: product.requirements } : {}),
      sku: String(product.id || product.slug),
      mpn: String(product.id || product.slug),
      category: "Software > Computer Software",
      itemCondition: "https://schema.org/NewCondition",
      offers: productOffer(product),
    },
  }));
  const blogItems = blogPosts.map((post, index) => {
    const title = post.titleEn || post.titleVi || "Untitled";
    const desc = (post.descriptionEn || post.descriptionVi || "").replace(/\s+/g, " ").trim();
    return {
      "@type": "ListItem",
      position: sellable.length + index + 1,
      item: {
        "@type": "WebPage",
        "@id": absolute(`/blog/${encodeURIComponent(post.slug)}#blog`),
        name: title,
        description: desc,
        url: absolute(`/blog/${encodeURIComponent(post.slug)}`),
        image: absolute("/og.png"),
        isPartOf: { "@id": `${site()}/#website` },
        datePublished: new Date(post.published || post.modified || Date.now()).toISOString(),
        dateModified: new Date(post.modified || post.published || Date.now()).toISOString(),
        inLanguage: "vi",
        genre: post.section || "Blog",
      },
    };
  });
  return {
    "@context": "https://schema.org",
    "@type": "ItemList",
    name: `${brand()} catalogue and blog`,
    url: absolute("/feed.json"),
    numberOfItems: sellable.length + blogPosts.length,
    dateModified: new Date().toISOString().slice(0, 10),
    itemListElement: [...productItems, ...blogItems],
  };
}

/**
 * Google Merchant Center feed as TSV.
 *
 * This exists so GMC can ingest the live catalogue without a third-party
 * tool. The file is served at /merchant-feed.tsv and can also be written
 * to disk by scripts/generate-merchant-feed.mjs for manual upload.
 */
export function renderMerchantFeed(products) {
  const sellable = (products || []).filter(isSellable);
  if (!sellable.length) {
    return "id\ttitle\tdescription\tlink\timage_link\tprice\tavailability\tcondition\tbrand\tmpn\tproduct_type\n";
  }

  const escape = (value) => String(value ?? "").replace(/[\t\n\r]/g, " ").trim();

  const rows = sellable.map((product) => {
    const title = escape(product.name + (product.version ? ` v${product.version}` : ""));
    // The description is the product's own factual prose. Promotional sentences
    // (price, discount, deadline) are stripped the same way the Product schema
    // strips them: a feed description is a product description, not a sale notice.
    const rawDescription = String(product.shortDescriptionEn || product.shortDescription || product.description || "").replace(/\s+/g, " ").trim();
    const keptDescription = rawDescription.split(/(?<=[.!?])\s+/).filter((sentence) => !PROMO_IN_TEXT.test(sentence)).join(" ").trim();
    const description = escape(keptDescription || derivedDescription(product));
    const link = absolute(productUrl(product.slug));
    const image = product.imageUrl
      ? product.imageUrl
      : absolute(`/og/${product.slug}.png`);
    // The feed price is the product's own shelf price, in the product's own
    // currency. This is the number the JSON-LD Offer and the Vietnamese landing
    // page publish; converting it to a second currency here is what made the feed
    // disagree with the page (GMC: price mismatch / dishonest pricing). Google
    // accepts the product's currency as long as the account supports it, and a
    // number that never moves is a number Merchant Center can match on the next
    // crawl.
    const currency = String(product.currency || "VND").toUpperCase();
    const price = `${(Number(product.price) || 0).toFixed(2)} ${currency}`;
    const mpn = String(product.id || product.slug);

    return [
      escape(product.slug || mpn),
      title,
      description,
      link,
      image,
      price,
      "in stock",
      "new",
      escape(env.brand.name),
      mpn,
      escape(product.category || "Software"),
      // No shipping_* columns. Every product is a digital download, and the four
      // zeroes that used to sit here told Merchant Center the opposite: an item
      // with shipping dimensions is a physical item, so GMC demanded a shipping
      // service and then failed every product on "shipping currency does not
      // match the price currency". A digital feed carries no shipping data at
      // all, which is also what Google's feed spec asks for.
    ].join("\t");
  });

  const header = [
    "id",
    "title",
    "description",
    "link",
    "image_link",
    "price",
    "availability",
    "condition",
    "brand",
    "mpn",
    "product_type",
  ].join("\t");

  return [header, ...rows].join("\n") + "\n";
}

// `esc` is re-exported because app.js builds its own markup with it — one
// implementation, two consumers, rather than a second copy of the escape rules.
// The other three that used to sit here had no caller at all, which meant each had
// two homes and neither could be removed.
export { esc };

/**
 * The structured data every indexable page shares.
 *
 * The homepage used to carry its own hand-written copy of these same two nodes,
 * and the copies had drifted: the product pages read the brand name, `sameAs` and
 * `founder` from configuration, the homepage had them typed in. A crawler was
 * therefore told two different things about who the shop is, and the homepage's
 * answer was the one missing the profile links that tie the shop to the rest of
 * the web.
 *
 * FAQPage is included because the homepage's own questions are the most-asked
 * ones on the site, and they are asked in the wording people actually use.
 */
function jsonLdGraph(products = []) {
  return JSON.stringify({
    "@context": "https://schema.org",
    "@graph": [
      organization(),
      websiteSchema(),
      ...(products.length ? [{
        "@type": "ItemList",
        name: `${brand()} — sản phẩm`,
        numberOfItems: products.length,
        itemListElement: products.map((product, index) => ({
          "@type": "ListItem",
          position: index + 1,
          name: product.name,
          url: absolute(productUrl(product.slug)),
        })),
      }] : []),
    ],
  });
}
