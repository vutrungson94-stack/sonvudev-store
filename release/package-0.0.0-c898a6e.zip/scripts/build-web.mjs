import { access, cp, mkdir, readdir, readFile, rm, writeFile } from 'node:fs/promises';
import { constants } from 'node:fs';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { walkProjectFiles, JS_EXTENSIONS } from './lib/files.mjs';
import {
  ARTIFACT_DIRECTORIES,
  ARTIFACT_EXCLUDE_DIRS,
  ARTIFACT_EXCLUDE_SUFFIXES,
  ARTIFACT_FILES,
  ARTIFACT_PATH,
  ARTIFACT_ROOT,
  ARTIFACT_SUBDIR,
} from './lib/artifact.mjs';
import { commitHash, gitCommand } from '../src/lib/git.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
// The commit this artifact was built from. It is recorded in the build report so
// a shipped artifact can be traced back to the source tree it came from.
//
// It is not the cache-busting version any more. That used to be the commit,
// which meant a deploy could not invalidate an asset unless the commit changed,
// and the packaged HTML and the rendered pages had to agree on it. Both now
// carry the hash of the file's own bytes, so the version changes exactly when
// the file changes.
const commit = commitHash(root);
// The wall-clock time the build ran made every artifact different even for the
// same commit — exactly what prevents proving that what shipped is what was
// tested. The commit date is deterministic per source revision and equally
// traceable against public history, so the artifact is now byte-stable.
const commitDate = gitCommand(['log', '-1', '--format=%cI'], root).trim();
// The build refuses to package without each of these. Every one was added because
// the site worked but something on it was quietly broken: og.png because every
// platform that renders a link preview refuses SVG, related.js because the strict
// Content-Security-Policy refuses to run an inline script, about.html because a
// page that exists only in someone's head is not a page.
// Everything a deploy is not allowed to be missing.
//
// The list is explicit on purpose. A file referenced by a page but absent from
// disk breaks that one page, in production only, and nothing in the test suite
// would notice — so the file's existence is checked before packaging rather than
// discovered by a buyer. public/order-client.js is here for the same reason as
// the rest: four pages load it, and it holds the access token and the download
// handshake they all share.
//
// The fonts are here for the same reason as the stylesheet: a page whose font
// files are missing falls back to a system face, which is a visual change that
// no gate would otherwise notice.
const required = ['package.json', 'src/server.js', 'src/app.js', 'src/store.js', 'src/r2.js', 'src/paypal.js', 'src/paypal-environment.js', 'src/payments.js', 'src/rates.js', 'src/geo.js', 'src/indexnow.js', 'src/pages.js', 'src/reviews.js', 'src/format.js', 'src/config.js', 'src/notify.js', 'src/supabase-http.js', 'src/refuse.js', 'src/robots.js', 'src/rate-limit.js', 'src/admin-auth.js', 'public/index.html', 'public/i18n.js', 'public/styles.css', 'public/styles.min.css', 'public/blog.min.css', 'public/format.js', 'public/order-client.js', 'public/app.js', 'public/admin.html', 'public/admin.js', 'public/paypal-return.html', 'public/paypal-return.js', 'public/lookup.html', 'public/lookup.js', 'public/order.html', 'public/order.js', 'public/terms.html', 'public/privacy.html', 'public/refund.html', 'public/404.html', 'public/about.html', 'public/css-ready.js', 'public/related.js', 'public/lang-detect.js', 'public/favicon.svg', 'public/favicon.ico', 'public/mask-icon.png', 'public/apple-touch-icon.png', 'public/logo-1024.png', 'public/logo-ink-64.png', 'public/logo-mint-512.png', 'public/screenshots/desktop-1280x800.png', 'public/screenshots/mobile-390x844.png', 'public/icon-16.png', 'public/icon-32.png', 'public/icon-192.png', 'public/icon-512.png', 'public/img/sonvudev.logo.png', 'public/fonts/be-vietnam-pro-latin.woff2', 'public/fonts/be-vietnam-pro-vietnamese.woff2', 'public/fonts/OFL-Be-Vietnam-Pro.txt', 'public/fonts/space-grotesk-latin.woff2', 'public/fonts/space-grotesk-vietnamese.woff2', 'public/fonts/OFL-Space-Grotesk.txt', 'public/og.png', 'scripts/production-check.mjs', 'scripts/audit-web.mjs', 'scripts/case-check.mjs', 'scripts/seo-check.mjs', 'scripts/r2-cors.mjs', 'scripts/run-tests.mjs', 'scripts/provenance.mjs', 'scripts/prune-logs.mjs', 'scripts/backup.mjs', 'scripts/minify-js.mjs', 'scripts/make-pwa-screenshots.mjs', 'scripts/lib/artifact.mjs', 'scripts/lib/cors.mjs', 'scripts/lib/files.mjs', 'cloudflare/r2-cors.json', 'Dockerfile', 'render.yaml'];
// One walk, shared with lint and metrics, so all three measure the same source.
// This used to keep a private copy of the directory list that did not exclude
// publish-output, which meant the build re-checked the artifact it had just
// written and reported 122 JavaScript files where the project has 81.
const jsFiles = await walkProjectFiles(root, { extensions: JS_EXTENSIONS });
// Generate the minified stylesheet before the required-file gate so the
// artifact always ships a fresh public/styles.min.css. The source stays
// public/styles.css (checked by tests and the audit), the browser loads the
// minified copy.
const minify = spawnSync(process.execPath, [path.join(root, 'scripts', 'minify-css.mjs')], { encoding: 'utf8' });
if (minify.status !== 0) throw new Error(`CSS minify failed:\n${minify.stdout}${minify.stderr}`);
// Blog pages ship a filtered copy of the same stylesheet (see the script's
// header): the full sheet is ~70 KB and a blog page matches a fifth of it.
const blogCss = spawnSync(process.execPath, [path.join(root, 'scripts', 'subset-blog-css.mjs')], { encoding: 'utf8' });
if (blogCss.status !== 0) throw new Error(`Blog CSS subset failed:\n${blogCss.stdout}${blogCss.stderr}`);
for (const file of required) await access(path.join(root, file), constants.R_OK);
const manifest = JSON.parse(await readFile(path.join(root, 'package.json'), 'utf8'));
if (manifest.type !== 'module') throw new Error('package.json must use type=module');
if (!manifest.scripts?.build) throw new Error('Missing npm build script');
if (!manifest.scripts?.lint) throw new Error('Missing npm lint script');
for (const file of jsFiles) { const result = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' }); if (result.status !== 0) throw new Error(`Syntax check failed: ${path.relative(root, file)}\n${result.stderr}`); }
// A syntax check only proves the file parses. The audit is what stops a broken
// internal link, a duplicated route or a value written into two places from
// reaching a deploy, so it runs here rather than being a step somebody remembers.
const audit = spawnSync(process.execPath, [path.join(root, 'scripts', 'audit-web.mjs')], { encoding: 'utf8' });
if (audit.status !== 0) throw new Error(`Audit failed:\n${audit.stdout}${audit.stderr}`);
const auditSummary = (audit.stdout.match(/\[audit\] .*/g) || []).pop() || '';

// Uppercase/lowercase imports only break on Linux, where the deploy runs; Windows
// cannot see it. It runs here rather than being left to CI because a bad import
// that reaches the artifact breaks every route that touches it.
const caseCheck = spawnSync(process.execPath, [path.join(root, 'scripts', 'case-check.mjs')], { encoding: 'utf8' });
if (caseCheck.status !== 0) throw new Error(`Case check failed:\n${caseCheck.stdout}${caseCheck.stderr}`);
const caseSummary = (caseCheck.stdout.match(/\[case\].*/g) || []).pop() || '';

// A pass or a fail at a point in time. The metrics step is what answers whether
// this week was better than last week: it compares test count, route count,
// dependency count and duplicate-helper count against a committed baseline and
// fails if one moved the wrong way. Cheap, and it is the difference between a
// project that is measured and one that is only verified.
const metrics = spawnSync(process.execPath, [path.join(root, 'scripts', 'metrics.mjs')], { encoding: 'utf8' });
if (metrics.status !== 0) throw new Error(`Metrics regressed:\n${metrics.stdout}${metrics.stderr}`);
const metricsSummary = (metrics.stdout.match(/\[metrics\].*/g) || []).pop() || '';
// Provenance + SBOM, generated locally: who built what, with what. It runs before
// packaging so build-reports/provenance.json describes the same source tree that
// just passed the audit and the metrics gate.
const provenance = spawnSync(process.execPath, [path.join(root, 'scripts', 'provenance.mjs')], { encoding: 'utf8' });
if (provenance.status !== 0) throw new Error(`Provenance failed:\n${provenance.stdout}${provenance.stderr}`);
const provenanceSummary = (provenance.stdout.match(/\[provenance\].*/g) || []).pop() || '';

// The transparency document, written into public/ before the publish copy so it
// ships with the artifact and is served at /build-report.json.
//
// What this is: what the shop selling the software was built from — commit,
// branch, Node version, every file that shipped with a content hash, and every
// dependency the server runs. A buyer can check the number they are given against
// the number in this file instead of taking the download button's word for it.
//
// What this deliberately is not: a claim about the product. The SBOM describes
// this server, not RamCleaner.exe, and calling it anything else would be the same
// overclaiming the product copy was fixed for. Product-level verification is the
// antivirus scan and the source, and those live on the product page.
//
// The two inputs carry no hostname, username, path or secret, and this writer does
// nothing but select, so nothing local to the build machine travels with it.
const transparencyPath = path.join(root, 'public', 'build-report.json');
try {
  const [provenanceDoc, sbomDoc] = await Promise.all([
    readFile(path.join(root, 'build-reports', 'provenance.json'), 'utf8').then(JSON.parse),
    readFile(path.join(root, 'build-reports', 'sbom.json'), 'utf8').then(JSON.parse),
  ]);
  const transparency = {
    application: provenanceDoc.application,
    version: provenanceDoc.version,
    builtAt: commitDate || provenanceDoc.generatedAt,
    git: { commit: provenanceDoc.gitCommit, branch: provenanceDoc.gitBranch },
    runtime: provenanceDoc.node,
    integrity: { files: (provenanceDoc.files || []).length, filesSha256: provenanceDoc.filesSha256 },
    // Two writers have used this filename: provenance.mjs writes
    // `{packages: [{package, version, license}]}`, and an external CycloneDX tool
    // wrote `{components: [{name, version}]}`. Read both rather than assuming which
    // one ran last — an empty dependency list reads as "nothing to verify", which
    // is the one thing this file must never say.
    dependencies: [...(sbomDoc.packages || []), ...(sbomDoc.components || [])]
      .map((p) => {
        if (typeof p === "string") return { name: p, version: null };
        const name = p.group ? `${p.group}/${p.name}` : (p.name || p.package);
        return { name, version: p.version || null, ...(p.license ? { license: p.license } : {}) };
      })
      .filter((p) => p.name && p.name !== "--help"),
  };
  await writeFile(transparencyPath, `${JSON.stringify(transparency, null, 2)}\n`, 'utf8');
  console.log(`[transparency] ${transparency.integrity.files} files, ${transparency.dependencies.length} packages -> public/build-report.json`);
} catch (error) {
  // Non-fatal on purpose: a missing report must stop a transparency claim from
  // being made, never stop the shop from deploying.
  console.log(`[transparency] skipped: ${error.message}`);
}

// The artifact is the single definition of what ships, and deploy/deploy.sh
// deploys this directory and nothing else. It used to be written here and then
// ignored: the deploy script copied the entire working tree instead, so the
// existence gate and the audit re-run were certifying a directory no release
// path consumed, while the directory that was actually deployed was never
// checked at all — and it carried .env.backup-*, the build tool's secret cache
// and the full .git history with it.
//
// What is copied is read from scripts/lib/artifact.mjs, the same module
// test/artifact.test.js checks package.json "files" against.
const publishRoot = path.join(root, ARTIFACT_ROOT, ARTIFACT_SUBDIR);

await rm(publishRoot, { recursive: true, force: true });
await mkdir(publishRoot, { recursive: true });
for (const directory of ARTIFACT_DIRECTORIES) {
  await cp(path.join(root, directory), path.join(publishRoot, directory), { recursive: true, force: true });
}
for (const file of ARTIFACT_FILES) {
  await cp(path.join(root, file), path.join(publishRoot, file), { force: true });
}
// Prune tool scratch that lives inside artifact directories (notably
// cloudflare/keep-awake/.wrangler). cp is recursive over whole directories, so
// without this a local `wrangler deploy` or a gbuild run ships its cache.
//
// Walked rather than named, and that is the fix rather than a tidy-up: the previous
// version pruned one hardcoded path (cloudflare/keep-awake) plus one level under each
// top directory, so a cache two levels down — or in any directory added later —
// shipped. The suffix gate below then had to exist as a second answer to the same
// question. One walk over the artifact prunes every excluded name wherever it sits.
const pruneScratch = async (dir) => {
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    if (!entry.isDirectory()) continue;
    const target = path.join(dir, entry.name);
    if (ARTIFACT_EXCLUDE_DIRS.includes(entry.name)) await rm(target, { recursive: true, force: true });
    else await pruneScratch(target);
  }
};
await pruneScratch(publishRoot);

// The browser scripts are minified in the artifact, not in the source tree. The
// source of public/app.js and public/i18n.js is read as text by the audit, the
// metrics and the tests, so the readable file has to stay readable; what ships
// is the minified copy. Lighthouse charged the site for the difference:
// /app.js was 45.9 KB raw and public/i18n.js was 127.2 KB raw.
const minifyJs = spawnSync(process.execPath, [path.join(root, 'scripts', 'minify-js.mjs'), '--dir', path.join(publishRoot, 'public')], { encoding: 'utf8' });
if (minifyJs.status !== 0) throw new Error(`JS minify failed:\n${minifyJs.stdout}${minifyJs.stderr}`);
process.stdout.write(minifyJs.stdout);

await mkdir(path.join(root, 'build-reports'), { recursive: true });
const artifactFiles = (await walkProjectFiles(publishRoot)).map((file) => path.relative(root, file).replaceAll('\\', '/'));

// Every asset the pages load is versioned by the hash of its own bytes.
//
// The reason this exists: the server answers /app.js and /styles.min.css with
// `max-age=31536000`, and the pages that link them did not say which version
// they meant. A browser that visited before a deploy kept the old file for a
// year, so a deploy that fixed a bug was invisible to the visitors the bug was
// hurting.
//
// The version is written twice on purpose, in two places that must agree: the
// packaged HTML is rewritten here, and src/lib/assets.mjs reads the same
// manifest when it renders the pages the server builds at request time. A
// manifest in one place and a rewrite in the other would be two answers to
// "which file does this page mean", and the second one to be written is the one
// that ships.
//
// This block used to rewrite /styles.css — a file no page loads — and nothing
// else, which is why the real stylesheet and the real scripts were cached for a
// year with nothing to invalidate them.
const publicRoot = path.join(publishRoot, 'public');
const hashFile = async (file) => createHash('sha256').update(await readFile(file)).digest('hex').slice(0, 12);

// The fonts first, and the stylesheet second, because the stylesheet names the
// fonts.
//
// A font referenced from the stylesheet and preloaded from the HTML has to be
// the SAME url, or the preload is wasted: the browser fetches the preloaded
// bytes, cannot use them for a face whose src is a different url, and starts
// the file again from the stylesheet. The font then arrives after the first
// paint, Chrome applies it late, and the page shifts — 0.272 of layout shift
// on the homepage, measured, on a site whose own no-regress list says the font
// must not move the text.
//
// So the font urls inside the packaged stylesheet carry the font's own hash,
// exactly like the preload in the HTML does, and the browser reuses one
// download for both.
const fontFiles = artifactFiles.filter((f) => f.endsWith('.woff2'));
const fontVersions = new Map();
for (const file of fontFiles) {
  const absolute = path.join(root, file);
  const url = `/${path.relative(publicRoot, absolute).replaceAll('\\', '/')}`;
  fontVersions.set(url, await hashFile(absolute));
}
for (const file of artifactFiles.filter((f) => f.endsWith('.css'))) {
  const absolute = path.join(root, file);
  let css = await readFile(absolute, 'utf8');
  let changed = false;
  for (const [url, version] of fontVersions) {
    const versioned = `${url}?v=${version}`;
    // Strip whatever version was there, then write this one: the result is the
    // same whether the stylesheet came from the source (no version) or from a
    // previous packaging (an older version).
    const updated = css.split(versioned).join(url).replaceAll(url, versioned);
    if (updated === css) continue;
    css = updated;
    changed = true;
  }
  if (changed) await writeFile(absolute, css, 'utf8');
}

const assetManifest = {};
for (const file of artifactFiles) {
  const absolute = path.join(root, file);
  if (!absolute.startsWith(publicRoot)) continue;
  const relative = path.relative(publicRoot, absolute).replaceAll('\\', '/');
  if (!['.css', '.js', '.woff2'].includes(path.extname(relative))) continue;
  assetManifest[`/${relative}`] = await hashFile(absolute);
}
await writeFile(path.join(publicRoot, 'asset-manifest.json'), `${JSON.stringify(assetManifest, null, 2)}\n`, 'utf8');

for (const htmlFile of artifactFiles.filter((f) => f.endsWith('.html'))) {
  const abs = path.join(root, htmlFile);
  let content = await readFile(abs, 'utf8');
  content = content.replace(/(href|src)=(["'])([^"'?#:]+)(?:\?v=[^"']*)?\2/g, (match, attribute, quote, url) => {
    const version = assetManifest[url];
    return version ? `${attribute}=${quote}${url}?v=${version}${quote}` : match;
  });
  await writeFile(abs, content, 'utf8');
}

const shippedScratch = artifactFiles.filter((file) => {
  const base = file.slice(file.lastIndexOf('/') + 1);
  return ARTIFACT_EXCLUDE_DIRS.some((d) => file.includes(`/${d}/`) || base === d)
    || ARTIFACT_EXCLUDE_SUFFIXES.some((s) => base.endsWith(s));
});
if (shippedScratch.length) {
  throw new Error(`Artifact chứa file scratch của tool, không được deploy:\n  ${shippedScratch.join('\n  ')}`);
}

// Nothing that can hold a secret may leave the machine inside the artifact.
//
// The copy above is recursive over whole directories, so a .env, a .env.local or a
// .env.backup-* sitting in src/ or public/ would be deployed without anything
// noticing: the existence gate only checks that required files are *present*, never
// that forbidden ones are absent, and deploy/deploy.sh's refusal runs on the host
// after the secret has already travelled. This scans what was actually written, so
// the answer is about the bytes that ship rather than about a list someone maintains.
//
// .env.example is the one exception, by name rather than by pattern: it is
// documentation the deploy needs and it holds no values.
const shippedEnv = artifactFiles.filter((file) => {
  const name = file.slice(file.lastIndexOf('/') + 1);
  return name === '.env' || (name.startsWith('.env.') && name !== '.env.example');
});
if (shippedEnv.length) {
  throw new Error(`Artifact chứa file biến môi trường, không được deploy:\n  ${shippedEnv.join('\n  ')}\n.env.example là file duy nhất được phép.`);
}
// The application name is read from package.json, the same manifest
// scripts/provenance.mjs writes its report from. It used to be a literal here,
// so the two reports describing one build could name two different shops, and
// neither would have failed a gate.
const report = { application: manifest.name, mode: 'web-node', generatedAt: new Date().toISOString(), commit, javascriptFilesChecked: jsFiles.length, requiredFilesChecked: required.length, audit: auditSummary, caseCheck: caseSummary, metrics: metricsSummary, provenance: provenanceSummary, versionedAssets: Object.keys(assetManifest).length, artifactFiles: artifactFiles.length, artifactPath: ARTIFACT_PATH, status: 'passed' };
await writeFile(path.join(root, 'build-reports', 'web-build.json'), JSON.stringify(report, null, 2));
console.log(`[build] PASS: ${required.length} required files, ${jsFiles.length} JavaScript files checked, ${auditSummary}, ${caseSummary}, ${metricsSummary}, ${provenanceSummary}, ${artifactFiles.length} deploy files packaged into ${ARTIFACT_PATH}.`);
